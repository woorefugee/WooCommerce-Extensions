<?php
/**
 * Plugin Name: WooCommerce Ogone Payment Gateway
 * Plugin URI: http://www.woocommerce.com/products/ogone/
 * Description: Accept payments in WooCommerce with the Ogone gateway
 * Author: SkyVerge
 * Author URI: http://www.woocommerce.com/
 * Version: 1.9.0
 * Text Domain: woocommerce-gateway-ogone
 * Domain Path: /i18n/languages/
 *
 * Copyright: (c) 2011-2017, SkyVerge, Inc. (info@skyverge.com)
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-Ogone
 * @author    SkyVerge
 * @category  Plugin
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), '96ea99828311a452bb5a76ac4ff4b661', '18630' );

// WC active check
if ( ! is_woocommerce_active() ) {
	return;
}

// Required library class
if ( ! class_exists( 'SV_WC_Framework_Bootstrap' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'lib/skyverge/woocommerce/class-sv-wc-framework-bootstrap.php' );
}

SV_WC_Framework_Bootstrap::instance()->register_plugin( '4.6.0', __( 'WooCommerce Ogone Gateway', 'woocommerce-gateway-ogone' ), __FILE__, 'init_woocommerce_gateway_ogone', array(
	'minimum_wc_version'   => '2.5.5',
	'minimum_wp_version'   => '4.1',
	'backwards_compatible' => '4.4',
) );

function init_woocommerce_gateway_ogone() {


/**
 * Ogone extends default WooCommerce Payment Gateway class
 **/
class WC_Ogone extends SV_WC_Plugin {


	/** version number */
	const VERSION = '1.9.0';

	/** @var WC_Ogone single instance of this plugin */
	protected static $instance;

	/** plugin id */
	const PLUGIN_ID = 'ogone';

	/** string class name to load as gateway */
	const GATEWAY_CLASS_NAME = 'WC_Gateway_Ogone';

	/** @var string the gateway ID */
	const GATEWAY_ID = 'ogone';


	/**
	 * Initialize the plugin
	 *
	 * @since 1.2
	 * @see SV_WC_Plugin::__construct()
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			array(
				'text_domain'  => 'woocommerce-gateway-ogone',
				'dependencies' => array( 'hash' ),
			)
		);

		// include required files
		add_action( 'sv_wc_framework_plugins_loaded', array( $this, 'includes' ) );

		// watch for the configure-complus message to be dismissed
		add_action( 'wc_' . $this->get_id(). '_dismiss_message', array( $this, 'message_dismissed' ), 10, 2 );
	}


	/**
	 * Include required files
	 *
	 * @since 1.2
	 */
	public function includes() {

		// load gateway class
		require_once( $this->get_plugin_path() . '/includes/class-wc-gateway-ogone.php' );

		// Add gateway to WC Payment Methods
		add_filter( 'woocommerce_payment_gateways', array( $this, 'load_gateway' ) );
	}


	/**
	 * Adds WePay to the list of available payment gateways
	 *
	 * @since 1.2
	 * @param array $gateways
	 * @return array $gateways
	 */
	public function load_gateway( $gateways ) {

		$gateways[] = self::GATEWAY_CLASS_NAME;

		return $gateways;
	}


	/** Admin methods ******************************************************/


	/**
	 * Checks if the configure-complus message needs to be rendered
	 *
	 * @since 1.3.7
	 * @see SV_WC_Plugin::add_delayed_admin_notices()
	 */
	public function add_delayed_admin_notices() {

		parent::add_delayed_admin_notices();

		if ( ! $this->is_complus_configured() ) {

			/* translators: Placeholders: %1$s - <strong>, %2$s - </strong> */
			$message = sprintf( __( '%1$sWooCommerce Ogone Payment Gateway - Action Required:%2$s to ensure your ability to process payments is not interrupted, please log on to your Ogone Backoffice and go to Configuration &gt; Technical Information &gt; Transaction feedback.  Below "Dynamic e-Commerce parameters" add "COMPLUS" to the Selected list if it is not already there.  Save those settings, then mark this message as "complete".', 'woocommerce-gateway-ogone' ),
				'<strong>', '</strong>' );

			$this->get_admin_notice_handler()->add_admin_notice( $message, 'configure-complus' );
		}
	}


	/** Helper methods ******************************************************/


	/**
	 * Main Ogone Instance, ensures only one instance is/can be loaded
	 *
	 * @since 1.4.0
	 * @see wc_ogone()
	 * @return WC_Ogone
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	/**
	 * Gets the plugin documentation url
	 *
	 * @since 1.3
	 * @see SV_WC_Plugin::get_documentation_url()
	 * @return string documentation URL
	 */
	public function get_documentation_url() {
		return 'http://docs.woocommerce.com/document/ogone/';
	}


	/**
	 * Gets the plugin support URL
	 *
	 * @since 1.6.0
	 * @see SV_WC_Plugin::get_support_url()
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/tickets/';
	}


	/**
	 * Returns true if the COMPLUS parameter has been certified to have
	 * been configured
	 *
	 * @since 1.2
	 * @return boolean true if the COMPLUS parameter has been certified to have been configured
	 */
	public function is_complus_configured() {
		return get_option( 'wc_ogone_complus_configured', false );
	}


	/**
	 * If the Configure COMPLUS message has been cleared, mark the db setting
	 *
	 * @since 1.2
	 */
	public function message_dismissed( $message_id, $user_id ) {

		if ( 'configure-complus' == $message_id ) {
			update_option( 'wc_ogone_complus_configured', true );
		}
	}


	/**
	 * Returns the gateway settings option name for the identified gateway.
	 * Defaults to woocommerce_{gateway id}_settings
	 *
	 * @since 1.2
	 * @param string $gateway_id
	 * @return string the gateway settings option name
	 */
	protected function get_gateway_settings_name( $gateway_id ) {
		return 'woocommerce_' . $gateway_id . '_settings';
	}


	/**
	 * Returns the settings array for the identified gateway
	 *
	 * @since 1.2
	 * @param string $gateway_id gateway identifier
	 * @return array settings array
	 */
	public function get_gateway_settings( $gateway_id ) {
		return get_option( $this->get_gateway_settings_name( $gateway_id ) );
	}


	/**
	 * Gets the gateway configuration URL
	 *
	 * @since 1.3
	 * @see SV_WC_Plugin::get_settings_url()
	 * @param string $plugin_id the plugin identifier.  Note that this can be a
	 *        sub-identifier for plugins with multiple parallel settings pages
	 *        (ie a gateway that supports both credit cards and echecks)
	 * @return string plugin settings URL
	 */
	public function get_settings_url( $plugin_id = null ) {
		return $this->get_payment_gateway_configuration_url();
	}


	/**
	 * Returns true if on the gateway settings page
	 *
	 * @since 1.3
	 * @see SV_WC_Plugin::is_plugin_settings()
	 * @return boolean true if on the admin gateway settings page
	 */
	public function is_plugin_settings() {
		return $this->is_payment_gateway_configuration_page();
	}


	/**
	 * Returns the admin configuration url for the gateway with class name
	 * $gateway_class_name
	 *
	 * @since 2.2.0-1
	 * @return string admin configuration url for the gateway
	 */
	public function get_payment_gateway_configuration_url() {

		return admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $this->get_payment_gateway_configuration_section() );
	}


	/**
	 * Returns true if the current page is the admin configuration page for the
	 * gateway with class name $gateway_class_name
	 *
	 * @since 2.2.0-1
	 * @return boolean true if the current page is the admin configuration page for the gateway
	 */
	public function is_payment_gateway_configuration_page() {

		return isset( $_GET['page'] ) && 'wc-settings' == $_GET['page'] &&
		isset( $_GET['tab'] ) && 'checkout' == $_GET['tab'] &&
		isset( $_GET['section'] ) && $this->get_payment_gateway_configuration_section() == $_GET['section'];
	}


	/**
	 * Get the gateway's settings screen section ID.
	 *
	 * @since 1.8.0
	 * @return string
	 */
	public function get_payment_gateway_configuration_section() {

		// WC 2.6+ uses the gateway ID instead of class name
		if ( SV_WC_Plugin_Compatibility::is_wc_version_lt_2_6() ) {
			$section = self::GATEWAY_CLASS_NAME;
		} else {
			$section = self::GATEWAY_ID;
		}

		return strtolower( $section );
	}


	/**
	 * Returns the plugin name, localized
	 *
	 * @since 1.3
	 * @see SV_WC_Plugin::get_plugin_name()
	 * @return string the plugin name
	 */
	public function get_plugin_name() {
		return __( 'WooCommerce Ogone', 'woocommerce-gateway-ogone' );
	}


	/**
	 * Returns __FILE__
	 *
	 * @since 1.3
	 * @return string the full path and filename of the plugin file
	 */
	protected function get_file() {
		return __FILE__;
	}


	/** Lifecycle methods ******************************************************/


	/**
	 * Plugin install method.  Perform any installation tasks here
	 *
	 * @since 1.2
	 * @see SV_WC_Plugin::install()
	 */
	protected function install() {

		// fresh install, assume COMPLUS has been configured
		update_option( 'wc_ogone_complus_configured', true );
	}


	/**
	 * Plugin upgrade method.  Perform any required upgrades here
	 *
	 * @since 1.2
	 * @see SV_WC_Plugin::upgrade()
	 * @param string $installed_version the currently installed version
	 */
	protected function upgrade( $installed_version ) {

		global $wpdb;

		// update user dismissed messages meta key
		if ( version_compare( $installed_version, '1.3', '<' ) ) {
			$wpdb->query( "UPDATE {$wpdb->usermeta} SET meta_key='_wc_plugin_framework_{$this->get_id()}_dismissed_messages' WHERE meta_key='_wc_payment_gateway_{$this->get_id()}_dismissed_messages'" );
		}
	}


} // end WC_Ogone


/**
 * Returns the One True Instance of Ogone
 *
 * @since 1.4.0
 * @return WC_Ogone
 */
function wc_ogone() {
	return WC_Ogone::instance();
}

// fire it up!
wc_ogone();

} // init_woocommerce_gateway_ogone()
