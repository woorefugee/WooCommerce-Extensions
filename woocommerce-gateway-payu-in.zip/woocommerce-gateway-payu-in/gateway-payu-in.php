<?php
/*
	Plugin Name: WooCommerce PayU India Gateway
	Plugin URI: https://www.woocommerce.com/products/payu/
	Description: Extends WooCommerce. Provides a <a href="http://www.payu.in/">PayU India</a> gateway for WooCommerce.
	Version: 1.8.1
	Author: WooCommerce
	Author URI: https://woocommerce.com/
	Requires at least: 3.8
	Tested up to: 4.2
*/

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '2e56bbe1b8877193b170f472b0451fbd', '18707' );

/**
 * init_payu_in_gateway function.
 *
 * @description Initializes the gateway.
 * @access public
 * @return void
 */
function init_payu_in_gateway() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	// Localization
	load_plugin_textdomain ('woocommerce_payu_in', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	require_once( plugin_basename( 'includes/payu_in.class.php' ) );

	/**
 	 * add_gateway()
 	 *
	 * Register the gateway within WooCommerce.
	 *
	 * @since 1.0.0
	 */
	function add_payu_in_gateway( $methods ) {
		$methods[] = 'WC_Gateway_Payu_In';
		return $methods;
	}
	add_filter( 'woocommerce_payment_gateways', 'add_payu_in_gateway' );
}
add_action( 'plugins_loaded', 'init_payu_in_gateway', 0 );
