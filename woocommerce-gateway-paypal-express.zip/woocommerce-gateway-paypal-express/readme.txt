=== WooCommerce PayPal Express Gateway ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.0
Tested up to: 4.5
Requires WooCommerce at least: 2.3.6
Tested WooCommerce up to: 2.5.0

Accept PayPal and Credit Card payments in your WooCommerce store via PayPal Express

See http://docs.woothemes.com/document/paypal-express-checkout/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-paypal-express' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
