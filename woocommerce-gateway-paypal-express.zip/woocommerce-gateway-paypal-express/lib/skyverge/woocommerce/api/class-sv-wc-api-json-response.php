<?php

// Intentionally blank to prevent fatals in plugins that included this file. TODO: remove in next major version @CW 2016-04-18
