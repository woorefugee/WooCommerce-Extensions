=== WooCommerce Customer/Order CSV Export ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires at least: 4.4
Tested up to: 4.7.5
Requires WooCommerce at least: 2.5.5
Tested WooCommerce up to: 3.0.7

Easily download customers & orders in CSV format and automatically export FTP or HTTP POST on a recurring schedule

See http://docs.woothemes.com/document/ordercustomer-csv-exporter/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-customer-order-csv-export' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
