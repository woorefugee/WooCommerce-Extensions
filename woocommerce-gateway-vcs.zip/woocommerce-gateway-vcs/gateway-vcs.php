<?php
/*
	Plugin Name: WooCommerce Virtual Card Services Gateway
	Plugin URI: http://woothemes.com/products/virtual-card-services/
	Description: A payment gateway for South African payment system, Virtual Card Services.
	Version: 1.1.3
	Author: WooThemes
	Author URI: http://woothemes.com/
	Requires at least: 3.1
	Tested up to: 3.2.1
*/

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) )
	require_once( 'woo-includes/woo-functions.php' );

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), 'aa8080a57d6655320fc1723618551cd4', '18600' );

load_plugin_textdomain( 'wc_vcs', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_vcs_init', 0 );

function woocommerce_vcs_init () {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) { return; }
	require_once( plugin_basename( 'classes/vcs.class.php' ) );
	add_filter( 'woocommerce_payment_gateways', 'woocommerce_vcs_add_gateway' );
} // End woocommerce_vcs_init()

function woocommerce_vcs_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_VCS'; return $methods;
} // End woocommerce_evripay_add_gateway()
?>