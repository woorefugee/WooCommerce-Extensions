=== WooCommerce Product Gallery Slider ===
Contributors: woothemes
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.3.3

Transforms product galleries into a responsive jQuery slider

== Usage ==

1. Upload the plugin to /wp-content/plugins and activate it
2. Specify slider settings at WooCommerce > Settings > Catalog
   * Fade is the recommend transition if your product galleries consist of different sized imagery
3. You can define whether to use the slider or not per product

If you require support please post on our forum.

