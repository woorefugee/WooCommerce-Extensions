=== WooCommerce SnapScan Gateway ===

A payment gateway for SnapScan. A valid SnapScan Api Key and SnapCode are required for this gateway to function.  Contact
help@snapscan.co.za to obtain your free api key.