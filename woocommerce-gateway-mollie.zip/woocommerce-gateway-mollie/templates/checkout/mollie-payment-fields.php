<?php
/**
 * WooCommerce Mollie
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Mollie to newer
 * versions in the future. If you wish to customize WooCommerce Mollie for your
 * needs please refer to http://docs.woocommerce.com/document/mollie-ideal/
 *
 * @package   WC-Mollie/Templates
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

/**
 * Renders the Mollie checkout form
 *
 * @param Mollie_API_Object_List $issuers enumerable of Mollie_API_Object_Method
 *        objects representing the available ideal issuers if this is iDEAL
 * @version 2.8.0
 * @since 2.0
 */

defined( 'ABSPATH' ) or exit;

if ( count( $issuers ) == 1 ) :
	?><input type="hidden" name="wc-mollie-ideal-issuer" id="wc-mollie-ideal-issuer" value="<?php echo esc_attr( $issuers[0]->id ); ?>" /><?php
elseif ( count( $issuers ) > 1 ) :
	?>
	<fieldset>
		<p class="form-row form-row-wide">
			<label for="wc-mollie-ideal-issuer"><?php esc_html_e( "Choose Your Bank", 'woocommerce-gateway-mollie' ); ?> <span class="required">*</span></label>
			<select name="wc-mollie-ideal-issuer" id="wc-mollie-ideal-issuer" style="width:auto;">
				<?php foreach ( $issuers as $issuer ) : ?>
					<?php if ( Mollie_API_Object_Method::IDEAL == $issuer->method ) : ?>
						<option value="<?php echo esc_attr( $issuer->id ); ?>"><?php echo esc_html( $issuer->name ); ?></option>
					<?php endif; ?>
				<?php endforeach; ?>
			</select>
		</p>
		<div class="clear"></div>
	</fieldset>
	<?php
endif;
