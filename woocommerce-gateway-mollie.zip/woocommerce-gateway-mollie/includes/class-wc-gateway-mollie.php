<?php
/**
 * WooCommerce Mollie
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Mollie to newer
 * versions in the future. If you wish to customize WooCommerce Mollie for your
 * needs please refer to http://docs.woocommerce.com/document/mollie-ideal/
 *
 * @package   WC-Mollie/Gateway
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * Mollie Payment Gateway
 *
 * @since 2.0
 */
class WC_Gateway_Mollie extends SV_WC_Payment_Gateway_Hosted {


	/** @var string production API key */
	protected $api_key;

	/** @var string test API key */
	protected $test_api_key;

	/** @var boolean certify that live webhook is added */
	protected $webhook_configured;

	/** @var boolean certify that test webhook is added */
	protected $test_webhook_configured;

	/** @var Mollie_API_Client Mollie API */
	protected $api;

	/** @var string the mollie method (one of ideal, creditcard, mistercash, bitcoin, paypal, paysafecard, banktransfer, sofort, belfius) */
	protected $method;

	/** @var string the mollie method title (one of iDEAL, Credit Card, Mister Cash, Bitcoin, PayPal, Paysafecard, Transfer, SOFORT, Belfius Direct Net) */
	public $method_title;

	/** @var string the hosted pay page URL for Mollie */
	protected $hosted_pay_page_url;

	/** @var array List of available method names, this is populated on the plugin settings page */
	private $available_methods;

	/** @var boolean true is settings have been loaded by SV_WC_Payment_Gateway::load_settings() */
	protected $settings_loaded;


	/**
	 * Initialize the gateway
	 *
	 * @since 2.0
	 * @param string $id optional gateway id, defaults to the plugin id
	 */
	public function __construct( $id = WC_Mollie::PLUGIN_ID ) {

		// initialize and load the settings
		$this->init_settings();

		$this->load_settings();

		parent::__construct(
			$id,
			wc_mollie(),
			array(
				'method_title'       => __( 'Mollie', 'woocommerce-gateway-mollie' ),
				'method_description' => __( 'Allow customers to securely pay using iDEAL, Credit Card, Mister Cash, PayPal, PaySafeCard, SOFORT, and Belfius Direct Net with Mollie.', 'woocommerce-gateway-mollie' ),
				'supports'           => array(
					self::FEATURE_PRODUCTS,
				 ),
				'payment_type'       => self::PAYMENT_TYPE_MULTIPLE,
				'environments' => array(
					self::ENVIRONMENT_PRODUCTION => _x( 'Production', 'Supports environments', 'woocommerce-gateway-mollie' ),
					self::ENVIRONMENT_TEST       => _x( 'Test', 'Supports environments', 'woocommerce-gateway-mollie' )
				),
			)
		);

		if ( is_admin() && ! is_ajax() ) {
			// default title in admin
			$this->title = __( 'Mollie', 'woocommerce-gateway-mollie' );
		}

		add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'thankyou_order_received_text' ), 10, 2 );
	}


	/**
	 * Returns true if the gateway is properly configured to perform transactions.
	 * Mollie requires:
	 *
	 * + api key
	 * + certification that the webhook has been configured
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::is_configured()
	 * @return boolean true if the gateway is properly configured
	 */
	protected function is_configured() {

		$is_configured = parent::is_configured();

		// missing configuration
		if ( ! $this->get_api_key() || ! $this->is_webhook_configured() ) {
			$is_configured = false;
		}

		return $is_configured;
	}


	/** Admin methods ******************************************************/


	/**
	 * Initialise Gateway Settings
	 *
	 * We override this so as to always load the 'mollie' settings regardless
	 * of the current payment method
	 *
	 * @since 2.0
	 * @see WC_Settings_API::init_settings()
	 */
	public function init_settings() {

		// loads the common settings which are shared amongst the payment methods offered by Mollie
		$current_id = $this->get_id();
		$this->id = WC_Mollie::PLUGIN_ID;

		parent::init_settings();

		// restore the id
		$this->id = $current_id;
	}


	/**
	 * Loads the plugin configuration settings
	 *
	 * @since 2.4.3
	 * @see WC_Settings_API::load_settings()
	 */
	protected function load_settings() {

		if ( ! isset( $this->settings_loaded ) || ! $this->settings_loaded ) {
			parent::load_settings();
		}
	}


	/**
	 * Initialize payment gateway settings fields
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::init_form_fields()
	 */
	public function init_form_fields() {
		parent::init_form_fields();

		$this->form_fields['title']['description']       = __( 'The special text <code>{method title}</code> will be substituted for the current Mollie method name, e.g. iDEAL, Credit Card, Mister Cash, etc.', 'woocommerce-gateway-mollie' );
		$this->form_fields['description']['description'] = __( 'The special text <code>{method title}</code> will be substituted for the current Mollie method name, e.g. iDEAL, Credit Card, Mister Cash, etc.', 'woocommerce-gateway-mollie' );
	}


	/**
	 * Returns an array of form fields specific for this method
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_method_form_fields()
	 * @return array of form fields
	 */
	protected function get_method_form_fields() {

		$available_methods = array();

		try {
			$methods = $this->get_methods();

			if ( count( $methods ) > 0 ) {
				foreach ( $methods as $method ) {
					$available_methods[] = $method->description;
				}
			} else {
				$available_methods = array( _x( 'None', 'No Mollie payment methods available', 'woocommerce-gateway-mollie' ) );
			}

		} catch ( Mollie_API_Exception $e ) {
			// communication error
			$available_methods = array( _x( 'Unknown', 'Available Mollie payment methods are unknown', 'woocommerce-gateway-mollie' ) );
		}

		return array(

			'methods' => array(
				'title'    => __( 'Available Methods', 'woocommerce-gateway-mollie' ),
				'type'     => 'list',
				'desc_tip' => __( 'The payment methods available for checkout, these are configured in your Mollie account.', 'woocommerce-gateway-mollie' ),
				'items'    => $available_methods,
			),

			'api_key' => array(
				'title'    => __( 'Live API Key', 'woocommerce-gateway-mollie' ),
				'type'     => 'password',
				'class'    => 'environment-field production-field',
				'desc_tip' => __( 'Your Mollie Website Profile Live API key', 'woocommerce-gateway-mollie' ),
			),

			'test_api_key' => array(
				'title'    => __( 'Test API Key', 'woocommerce-gateway-mollie' ),
				'type'     => 'password',
				'class'    => 'environment-field test-field',
				'desc_tip' => __( 'Your Mollie Website Profile Test API key', 'woocommerce-gateway-mollie' ),
			),

			'webhook_configured' => array(
				'title'       => __( 'Live Webhook Configured', 'woocommerce-gateway-mollie' ),
				'label'       => __( 'I certify that I have configured my Mollie account with the webhook for this gateway', 'woocommerce-gateway-mollie' ),
				'type'        => 'checkbox',
				'class'       => 'environment-field production-field',
				'description' => sprintf( __( 'To properly process transactions you must configure your Mollie account Web Site Profile live webhook: %s', 'woocommerce-gateway-mollie' ),
					'<strong class="nobr">' . $this->get_transaction_response_handler_url() . '</strong>' ),
				'default'     => 'no'
			),

			'test_webhook_configured' => array(
				'title'       => __( 'Test Webhook Configured', 'woocommerce-gateway-mollie' ),
				'label'       => __( 'I certify that I have configured my Mollie account with the webhook for this gateway', 'woocommerce-gateway-mollie' ),
				'type'        => 'checkbox',
				'class'       => 'environment-field test-field',
				'description' => sprintf( __( 'To properly process transactions you must configure your Mollie account Web Site Profile test webhook: %s', 'woocommerce-gateway-mollie' ),
					'<strong class="nobr">' . $this->get_transaction_response_handler_url() . '</strong>' ),
				'default'     => 'no'
			),

		);
	}


	/**
	 * Returns the method description which is based on the mollie method supported
	 * by this plugin displayed to the customer during checkout.
	 *
	 * @since 2.0
	 * @see WC_Payment_Gateway::get_description()
	 * @return string the checkout page description
	 */
	public function get_description() {
		return str_replace( '{method title}', $this->method_title, parent::get_description() );
	}


	/**
	 * Returns the method title which is based on the mollie method supported
	 * by this plugin displayed to the customer during checkout.
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_title()
	 * @return string the checkout page title
	 */
	public function get_title() {
		// replace our token in the configurable message
		return str_replace( '{method title}', $this->method_title, parent::get_title() );
	}


	/**
	 * Get the default payment method title, which is configurable within the
	 * admin and displayed on checkout
	 *
	 * @since 2.1
	 * @return string payment method title to show on checkout
	 */
	protected function get_default_title() {
		return '{method title}';
	}


	/**
	 * Get the default payment method description, which is configurable
	 * within the admin and displayed on checkout
	 *
	 * @since 2.1
	 * @return string payment method description to show on checkout
	 */
	protected function get_default_description() {
		return sprintf( __( 'Pay securely using %s', $this->method_title ), '{method title}' );
	}


	/** Redirect API methods ******************************************************/


	/**
	 * Display the payment fields on the checkout page.  Despite being a hosted
	 * gateway, Mollie has the potential to display fields in the checkout area.
	 *
	 * @since 2.0
	 * @see WC_Payment_Gateway_Hosted::payment_fields()
	 */
	public function payment_fields() {
		woocommerce_mollie_payment_fields( $this );
	}


	/**
	 * Gets the hosted pay page url to redirect to, to allow the customer to
	 * remit payment.  This is the bare URL, without any query params
	 *
	 * @since 2.0.0
	 * @see SV_WC_Payment_Gateway_Hosted::get_hosted_pay_page_params()
	 * @param WC_Order $order the order object
	 * @return string hosted pay page url
	 */
	public function get_hosted_pay_page_url( $order = null ) {

		// pay page URL already determined?
		if ( $this->hosted_pay_page_url ) {
			return $this->hosted_pay_page_url;
		}

		try {

			// load the client
			$this->get_api();

			$request_params = array(
				'amount'       => $order->payment_total,
				'description'  => sprintf( __( 'Order %s', 'woocommerce-gateway-mollie' ), $order->get_order_number() ),
				'redirectUrl'  => add_query_arg( array( 'id' => SV_WC_Order_Compatibility::get_prop( $order, 'id' ), 'key' => SV_WC_Order_Compatibility::get_prop( $order, 'order_key' ) ), $this->get_transaction_response_handler_url() ),
				'method'       => $this->get_method(),
				'metadata'     => array(
					'order_id' => SV_WC_Order_Compatibility::get_prop( $order, 'id' ),
				),
				// iDEAL specific field
				'issuer' => 'ideal' == $this->get_method() && isset( $_REQUEST['wc-mollie-ideal-issuer'] ) ? $_REQUEST['wc-mollie-ideal-issuer'] : '',
			);

			// mollie is picky about these fields
			if ( $billing_city = SV_WC_Order_Compatibility::get_prop( $order, 'billing_city' ) ) {
				$request_params['billingCity'] = $billing_city;
			}
			if ( $billing_state = SV_WC_Order_Compatibility::get_prop( $order, 'billing_state' ) ) {
				$request_params['billingRegion'] = $billing_state;
			}
			if ( $billing_postcode = SV_WC_Order_Compatibility::get_prop( $order, 'billing_postcode' ) ) {
				$request_params['billingPostal'] = $billing_postcode;
			}
			if ( $billing_country = SV_WC_Order_Compatibility::get_prop( $order, 'billing_country' ) ) {
				$request_params['billingCountry'] = $billing_country;
			}
			if ( $shipping_city = SV_WC_Order_Compatibility::get_prop( $order, 'shipping_city' ) ) {
				$request_params['shippingCity'] = $shipping_city;
			}
			if ( $shipping_state = SV_WC_Order_Compatibility::get_prop( $order, 'shipping_state' ) ) {
				$request_params['shippingRegion'] = $shipping_state;
			}
			if ( $shipping_postcode = SV_WC_Order_Compatibility::get_prop( $order, 'shipping_postcode' ) ) {
				$request_params['shippingPostal'] = $shipping_postcode;
			}
			if ( $shipping_country = SV_WC_Order_Compatibility::get_prop( $order, 'shipping_country' ) ) {
				$request_params['shippingCountry'] = $shipping_country;
			}

			$api_method = 'payments';

			// for logging purposes
			$request = array(
				'method' => Mollie_API_Client::HTTP_POST,
				'uri' => Mollie_API_Client::API_ENDPOINT . "/" . Mollie_API_Client::API_VERSION . "/" . $api_method,
				'body' => json_encode( $request_params ),
			);

			// attempt to create the remote payment
			$payment = $this->get_api()->$api_method->create( $request_params );

			// log the request/response
			$this->get_plugin()->log_api_request( $request, $payment );

			// check for payment URL
			if ( ! $payment->getPaymentUrl() ) {
				$this->mark_order_as_failed( $order, 'Mollie payment create request returned no payment URL' );

				// halt payment processing
				return false;
			}

			// save the payment id to the order record (note to self: for some reason I was using the plugin id here originally for the order meta, not sure why)
			$this->update_order_meta( $order, 'trans_id', $payment->id );

			// success: return mollie hosted pay page URL
			return $this->hosted_pay_page_url = $payment->getPaymentUrl();

		} catch ( Mollie_API_Exception $e ) {

			// log the failed request
			$this->get_plugin()->log_api_request( $request );

			$this->mark_order_as_failed( $order, $e->getMessage() );

			// halt payment processing
			return false;
		}
	}


	/**
	 * Returns the WC API URL for this gateway, based on the current protocol
	 *
	 * @since 2.4.5
	 * @see SV_WC_Payment_Gateway_Hosted::get_transaction_response_handler_url()
	 * @return string the WC API URL for this server
	 */
	public function get_transaction_response_handler_url() {

		if ( $this->transaction_response_handler_url ) {
			return $this->transaction_response_handler_url;
		}

		$this->transaction_response_handler_url = add_query_arg( 'wc-api', 'WC_Gateway_Mollie', home_url( '/' ) );

		// make ssl if needed
		if ( ( is_ssl() && ! is_admin() ) || 'yes' == get_option( 'woocommerce_force_ssl_checkout' ) ) {
			$this->transaction_response_handler_url = str_replace( 'http:', 'https:', $this->transaction_response_handler_url );
		}

		return $this->transaction_response_handler_url;
	}


	/**
	 * Handle a payment notification request.
	 *
	 * @since 2.9.0
	 */
	public function handle_transaction_response_request() {

		// If this is a redirect (after successful IPN payment) handle it accordingly
		if ( isset( $_REQUEST['id'] ) && isset( $_REQUEST['key'] ) ) {

			$this->handle_redirect_response_request();

		// Otherwise, handle the IPN as usual
		} else {

			parent::handle_transaction_response_request();
		}
	}


	/**
	 * Handle the payment notification redirect.
	 *
	 * @since 2.9.0
	 */
	protected function handle_redirect_response_request() {

		$order_id  = $_REQUEST['id'];
		$order_key = $_REQUEST['key'];

		$order = wc_get_order( $order_id );

		if ( ! $order || ! SV_WC_Order_Compatibility::get_prop( $order, 'id' ) || SV_WC_Order_Compatibility::get_prop( $order, 'order_key' ) !== $order_key ) {

			$this->add_debug_message( sprintf( "Order %s not found", $order_id ), 'error' );

			// if an order could not be determined, there's not a whole lot
			// we can do besides redirecting back to the home page
			return wp_redirect( get_home_url( null, '' ) );
		}

		// if already paid, redirect to thank you page
		if ( ! $order->needs_payment() ) {
			return wp_redirect( $this->get_return_url( $order ) );
		}

		// cancelled or pending -- pending is common for a method like Bitcoin which
		// can take up to 30 minutes to process
		$notice = $order->has_status( 'cancelled' ) ? __( 'Your order was cancelled.', 'woocommerce-gateway-mollie' ) : __( 'Your order is pending.', 'woocommerce-gateway-mollie' );

		wc_add_notice( $notice, 'notice' );

		return wp_redirect( wc_get_page_permalink( 'cart' ) );
	}


	/**
	 * Change the "thank you" page text to indicate the order was cancelled
	 *
	 * @since 2.4.5
	 * @param string $text the "thank you" text to display on the order received page
	 * @param WC_Order $order the order object
	 * @return string
	 */
	public function thankyou_order_received_text( $text, $order ) {

		if ( 'mollie' == substr( SV_WC_Order_Compatibility::get_prop( $order, 'payment_method' ), 0, 6 ) && $order->has_status( 'cancelled' ) ) {
			$text = __( 'Your order has been cancelled.  The order details follow:', 'woocommerce-gateway-mollie' );
		}

		return $text;
	}


	/**
	 * Adds an order note, along with anything else required after an approved
	 * transaction
	 *
	 * @since 2.0.0
	 * @param \WC_Order $order the order object
	 * @param \WC_Paytrail_API_Payment_Response $response the response object
	 * @param array $note_args Optional. The order note arguments. @see `SV_WC_Payment_Gateway_Hosted::add_transaction_approved_order_note()`
	 */
	protected function do_transaction_approved( WC_Order $order, $response, $note_args = array() ) {

		$note_args = array(
			'method_title'    => 'Mollie ' . $response->get_payment_method(),
			'additional_note' => ' ' . sprintf( __( 'with mode: %s', 'woocommerce-gateway-mollie' ), $response->get_payment_mode() ),
			'transaction_id'  => $response->get_transaction_id(),
		);

		if ( $response->get_payment_consumer_name() && $response->get_account_number() ) {

			$note_args['additional_note'] .= ' ' . sprintf(
				/* translators: Placeholders: %1$s - the consumer name from the payment response, %1$s - the account number from the payment response */
				__( 'Consumer Name: %1$s Consumer Account: %2$s', 'woocommerce-gateway-mollie' ),
				$response->get_payment_consumer_name(),
				$response->get_account_number()
			);
		}

		parent::do_transaction_approved( $order, $response, $note_args );
	}


	/**
	 * Adds the standard transaction data to the order from the IPN response
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway::add_payment_gateway_transaction_data()
	 * @param WC_Order $order the order object
	 * @param SV_WC_Payment_Gateway_API_Response $payment payment object
	 */
	public function add_payment_gateway_transaction_data( $order, $response ) {

		parent::add_payment_gateway_transaction_data( $order, $response );

		$this->update_order_meta( $order, 'method', $response->get_payment_method() );

		if ( $response->get_payment_details() ) {
			$this->update_order_meta( $order, 'details', (array) $response->get_payment_details() );
		}
	}


	/**
	 * Returns an API response object for the current response request
	 *
	 * @since 2.0.0
	 * @see SV_WC_Payment_Gateway_Hosted::get_transaction_response()
	 * @param array $request_response_data the current request response data
	 * @return SV_WC_Payment_Gateway_API_Payment_Notification_Response the response object
	 * @throws Exception if the response request data is invalid
	 */
	protected function get_transaction_response( $request_response_data ) {

		require_once( $this->get_plugin()->get_plugin_path() . '/includes/api/class-wc-mollie-api-webhook-response.php' );

		$response = new WC_Mollie_API_Webhook_Response( $request_response_data, $this->get_api() );

		// when the webhook url is updated in the mollie account
		if ( $response->is_test_webhook() ) {
			if ( $this->debug_log() ) {
				$this->get_plugin()->log( 'Webhook Test Received' );
			}
			status_header( 200 );
			die;
		}

		return $response;
	}


	/** Helper methods ******************************************************/


	/**
	 * Log IPN/redirect-back transaction response request to the log file
	 *
	 * @since 2.0.0
	 * @see SV_WC_Payment_Gateway_Hosted::log_transaction_response_request()
	 * @param array $response the request data
	 * @param string $message optional message string with a %s to hold the
	 *        response data.  Defaults to 'IPN Request %s' or 'Redirect-back
	 *        Request %s' based on the result of `has_ipn()`
	 * $response
	 */
	public function log_transaction_response_request( $response, $message = null ) {
		parent::log_transaction_response_request( $response, 'Webhook Request: %s' );
	}


	/**
	 * Render a list settings item
	 *
	 * @since 2.0
	 * @param string $key the field key
	 * @param array $data the field data
	 * @return string HTML
	 */
	public function generate_list_html( $key, $data ) {

		$defaults = array(
			'title'             => '',
			'type'              => 'list',
			'desc_tip'          => false,
			'description'       => '',
			'items' => array()
		);

		$data = wp_parse_args( $data, $defaults );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label><?php echo wp_kses_post( $data['title'] ); ?></label>
				<?php echo $this->get_tooltip_html( $data ); ?>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>
					<ul style="margin:0;">
						<?php foreach ( $data['items'] as $item ) : ?>
							<li><?php echo esc_html( $item ); ?></li>
						<?php endforeach; ?>
					</ul>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}


	/** Getter methods ******************************************************/


	/**
	 * Gets the API object, loading any required files
	 *
	 * @since 2.0
	 * @param string $api_key optional api to key, otherwise defaults to the one configured for the current environment
	 * @return Mollie_API_Client API instance
	 * @throws Mollie_API_Exception if the API key is invalid
	 */
	public function get_api() {

		global $wp_version;

		if ( isset( $this->api ) ) {
			return $this->api;
		}

		// API class
		if ( ! class_exists( 'Mollie_API_Autoloader' ) ) {
			require_once( $this->get_plugin()->get_plugin_path() . '/lib/Mollie/API/Autoloader.php' );
		}

		$this->api = new Mollie_API_Client();
		$this->api->setApiKey( $this->get_api_key() );
		$this->api->addVersionString( 'WordPress/' . ( isset( $wp_version ) ? $wp_version : 'Unknown' ) );
		$this->api->addVersionString( 'WooCommerce/' . WC_VERSION );
		$this->api->addVersionString( 'WooCommerceMollieGateway/' . WC_Mollie::VERSION );

		return $this->api;
	}


	/**
	 * Returns all available payment methods
	 *
	 * @since 2.0
	 * @param string $api_key optional api to key, otherwise defaults to the one configured for the current environment
	 * @return Mollie_API_Object_List enumerable of Mollie_API_Object_Method
	 *         objects representing the available payment methods for this account
	 * @throws Mollie_API_Exception if the API key is invalid
	 */
	public function get_methods() {

		if ( ! is_null( $this->available_methods ) ) {
			return $this->available_methods;
		}

		return $this->available_methods = $this->get_api()->methods->all();
	}


	/**
	 * Returns the mollie payment method for this gateway
	 *
	 * @since 2.0
	 * @return string the mollie payment method for this gateway (one of ideal, creditcard, mistercash, paypal, paysafecard, sofort, belfius)
	 */
	public function get_method() {
		return $this->method;
	}


	/**
	 * Returns all available ideal issuers
	 *
	 * @since 2.0
	 * @return Mollie_API_Object_List enumerable of Mollie_API_Object_Method
	 *         objects representing the available ideal issuers
	 * @throws Mollie_API_Exception if the API key is invalid
	 */
	public function get_ideal_issuers() {
		return $this->get_api()->issuers->all();
	}


	/**
	 * Returns the api key for the current environment
	 *
	 * @since 2.0
	 * @return string the api key to use
	 */
	public function get_api_key() {
		return $this->is_production_environment() ? $this->api_key : $this->test_api_key;
	}


	/**
	 * Returns true if the webhook is certified to be configured for the current environment
	 *
	 * @since 2.0
	 * @return boolean true if the webhook is certified to be configured, false otherwise
	 */
	public function is_webhook_configured() {
		return $this->is_production_environment() ? $this->webhook_configured : $this->test_webhook_configured;
	}


	/**
	 * Overridden because this gateway doesn't use a customer id
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_customer_id_user_meta_name()
	 * @param $environment_id
	 * @return bool false
	 */
	public function get_customer_id_user_meta_name( $environment_id = null ) {
		return false;
	}


	/**
	 * Overridden because this gateway doesn't use a customer id
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_guest_customer_id()
	 * @param WC_Order $order
	 * @return bool false
	 */
	public function get_guest_customer_id( WC_Order $order ) {
		return false;
	}


	/**
	 * Overridden because this gateway doesn't use a customer id
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_customer_id()
	 * @param int $user_id
	 * @param array $args
	 * @return bool false
	 */
	public function get_customer_id( $user_id, $args = array() ) {
		return false;
	}


}
