<?php
/**
 * WooCommerce Mollie
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Mollie to newer
 * versions in the future. If you wish to customize WooCommerce Mollie for your
 * needs please refer to http://docs.woocommerce.com/document/mollie-ideal/
 *
 * @package   WC-Mollie/Templates
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

/**
 * Template Function Overrides
 *
 * @since 2.0
 * @version 2.0
 */

defined( 'ABSPATH' ) or exit;


if ( ! function_exists( 'woocommerce_mollie_payment_fields' ) ) {

	/**
	 * Pluggable function to render the checkout page iframe
	 *
	 * @since 2.0
	 * @param WC_Gateway_Mollie $gateway gateway object
	 */
	function woocommerce_mollie_payment_fields( $gateway ) {

		// safely display the description, if there is one
		if ( $gateway->get_description() ) {
			echo '<p>' . wp_kses_post( $gateway->get_description() ) . '</p>';
		}

		// for the demo environment, display a notice
		if ( $gateway->is_environment( 'test' ) ) {
			echo '<p>' . __( 'TEST MODE ENABLED', 'woocommerce-gateway-mollie' ) . '</p>';
		}

		// load the payment fields template file
		wc_get_template(
			'checkout/mollie-payment-fields.php',
			array(
				'issuers' => Mollie_API_Object_Method::IDEAL == $gateway->get_method() ? $gateway->get_ideal_issuers() : array(),
			),
			'',
			$gateway->get_plugin()->get_plugin_path() . '/templates/'
		);

	}
}
