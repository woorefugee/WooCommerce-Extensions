<?php
/**
 * WooCommerce Mollie
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Mollie to newer
 * versions in the future. If you wish to customize WooCommerce Mollie for your
 * needs please refer to http://docs.woocommerce.com/document/mollie-ideal/
 *
 * @package   WC-Mollie/Gateway
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * Mollie Bitcoin Payment Gateway
 *
 * @since 2.2
 */
class WC_Gateway_Mollie_Bitcoin extends WC_Gateway_Mollie {


	/**
	 * Initialize the gateway
	 *
	 * @since 2.2
	 * @param string $id optional gateway id, defaults to the plugin id
	 */
	public function __construct( $id = WC_Mollie::PLUGIN_ID ) {
		parent::__construct( WC_Mollie::PLUGIN_ID . '_bitcoin' );

		// Gateway title on checkout
		$this->method_title = 'Bitcoin';

		// Mollie payment method type
		$this->method = 'bitcoin';

		if ( ! $this->icon ) {
			$this->icon = $this->get_plugin()->get_plugin_url() . '/assets/images/card-bitcoin.png';
		}
	}


}
