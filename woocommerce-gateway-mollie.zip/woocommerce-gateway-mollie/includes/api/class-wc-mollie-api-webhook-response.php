<?php
/**
 * WooCommerce Mollie
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Mollie to newer
 * versions in the future. If you wish to customize WooCommerce Mollie for your
 * needs please refer to http://docs.woocommerce.com/document/mollie-ideal/
 *
 * @package   WC-Gateway-Mollie/API
 * @author    SkyVerge
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;


/**
 * Mollie API Webhook Response Class
 *
 * This class represents technically both the Webhook response request, as well
 * as the direct API payments get request response, which could be somewhat of a
 * misuse of the class, however the two responses are really both required to
 * do anything useful.
 *
 * @since 2.1
 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response
 */
class WC_Mollie_API_Webhook_Response implements SV_WC_Payment_Gateway_API_Payment_Notification_Response {


	/** @var array the response data */
	protected $response;

	/** @var Mollie_API_Client the mollie direct API object */
	protected $mollie_api;

	/** @var Mollie_API_Object_Payment the mollie API payment response object  */
	protected $payment;


	/**
	 * Build a response object from the raw Webhook response request
	 *
	 * @since 2.1
	 * @param array $response the Webhook response request
	 * @param Mollie_API_Client $mollie_api the mollie direct API object
	 */
	public function __construct( $response, $mollie_api ) {

		$this->response   = $response;
		$this->mollie_api = $mollie_api;
	}


	/**
	 * Returns the order id associated with this response
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response::get_order_id()
	 * @return int the order id associated with this response, or null if it could not be determined
	 * @throws SV_WC_Payment_Gateway_Exception if the response request data is invalid or Mollie_API_Exception on API error
	 */
	public function get_order_id() {

		// bail if no payment id was passed
		if ( ! isset( $this->response['id'] ) || ! $this->response['id'] ) {
			throw new SV_WC_Payment_Gateway_Exception( 'No payment id' );
		}

		// already retrieved the payment
		if ( $this->payment ) {
			return $this->payment->metadata->order_id;
		}

		$api_method = 'payments';

		// for logging purposes
		$request = array(
			'method' => Mollie_API_Client::HTTP_GET,
			'uri'    => Mollie_API_Client::API_ENDPOINT . '/' . Mollie_API_Client::API_VERSION . '/' . $api_method . '/' . $this->response['id'],
			'body'   => '',
		);

		try {

			$this->payment = $this->mollie_api->$api_method->get( $this->response['id'] );

		} catch ( Mollie_API_Exception $e ) {

			// logging hook
			do_action( 'wc_mollie_api_request_performed', $request, null );

			// re-throw
			throw new SV_WC_Payment_Gateway_Exception( $e->getMessage() );
		}

		// logging hook
		do_action( 'wc_mollie_api_request_performed', $request, $this->payment );

		return $this->payment->metadata->order_id;
	}


	/**
	 * Returns the order associated with this response, if any
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response::get_order()
	 * @return WC_Order the order associated with this response, or null if it could not be determined
	 * @throws Mollie_API_Exception on API error
	 */
	public function get_order() {

		$order_id = $this->get_order_id();

		if ( ! $order_id ) {
			return null;
		} else {
			return wc_get_order( $order_id );
		}
	}


	/**
	 * Checks if the transaction was successful
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::transaction_approved()
	 * @return bool true if approved, false otherwise
	 */
	public function transaction_approved() {
		return $this->payment && $this->payment->isPaid();
	}


	/**
	 * Returns true if the transaction was held, false otherwise
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::transaction_held()
	 * @return bool true if held, false otherwise
	 */
	public function transaction_held() {
		// transaction will never be held for Mollie Webhook requests
		return false;
	}


	/**
	 * Returns true if the transaction was cancelled, false otherwise
	 *
	 * @since 2.0.0
	 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response::transaction_cancelled()
	 * @return bool true if cancelled, false otherwise
	 */
	public function transaction_cancelled() {
		return ! $this->transaction_approved() && ! $this->payment->isOpen() && Mollie_API_Object_Payment::STATUS_CANCELLED === $this->payment->status;
	}


	/**
	 * Gets the response transaction id, or null if there is no transaction id
	 * associated with this transaction.
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::get_transaction_id()
	 * @return string transaction id
	 */
	public function get_transaction_id() {
		if ( $this->payment ) {
			return $this->payment->id;
		}

		return null;
	}


	/**
	 * Gets the transaction status message.  This is intended for the merchant.
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::get_status_message()
	 * @return string status message
	 */
	public function get_status_message() {
		if ( $this->transaction_approved() ) {
			return __( 'Mollie transaction approved', 'woocommerce-gateway-mollie' );
		} elseif ( $this->transaction_cancelled() ) {
			return sprintf( _x( 'Mollie transaction ID %s was aborted with status %s.', 'Cancelled order note', 'woocommerce-gateway-mollie' ), $this->get_transaction_id(), $this->payment->status );
		} else {
			return sprintf( _x( 'Mollie transaction ID %s', 'Failed order note', 'woocommerce-gateway-mollie' ), $this->get_transaction_id() );
		}
	}


	/**
	 * Gets the response status code, or null if there is no status code
	 * associated with this transaction.
	 *
	 * @since 2.1
	 * @return string status code
	 */
	public function get_status_code() {
		// no status code for mollie Webhook requests
		return null;
	}


	/**
	 * Returns a message appropriate for a frontend user.  This should be used
	 * to provide enough information to a user to allow them to resolve an
	 * issue on their own, but not enough to help nefarious folks fishing for
	 * info.
	 *
	 * @since 2.2.1-1
	 * @see SV_WC_Payment_Gateway_API_Response_Message_Helper
	 * @see SV_WC_Payment_Gateway_API_Response::get_user_message()
	 * @return string user message, if there is one
	 */
	public function get_user_message() {
		return null;
	}


	/**
	 * Returns the string representation of this response
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::to_string()
	 * @return string response
	 */
	public function to_string() {
		return print_r( $this->response, true );
	}


	/**
	 * Returns the string representation of this response with any and all
	 * sensitive elements masked or removed
	 *
	 * @since 2.1
	 * @see SV_WC_Payment_Gateway_API_Response::to_string_safe()
	 * @return string response safe for logging/displaying
	 */
	public function to_string_safe() {

		// no sensitive data to mask
		return $this->to_string();
	}


	/**
	 * Returns any details the specific payment method provided after
	 * completing the payment. In case of iDEAL this will contain the
	 * bank account number (IBAN).
	 *
	 * @since 2.1
	 * @return string payment details, or null
	 */
	public function get_payment_details() {

		if ( $this->payment ) {
			return $this->payment->details;
		}

		return null;
	}


	/**
	 * Returns the payment method, one of 'ideal', 'creditcard', 'mistercash',
	 * 'sofort', 'banktransfer', 'bitcoin', 'paypal', 'paysafecard', 'belfius'
	 *
	 * @since 2.1
	 * @return string payment method, or null
	 */
	public function get_payment_method() {

		if ( $this->payment ) {
			return $this->payment->method;
		}

		return null;
	}


	/**
	 * Returns the payment mode, one of 'live' or 'test'
	 *
	 * @since 2.1
	 * @return string payment mode, or null
	 */
	public function get_payment_mode() {

		if ( $this->payment ) {
			return $this->payment->mode;
		}

		return null;
	}


	/**
	 * Returns the payment consumer name, if any
	 *
	 * @since 2.1
	 * @return string payment consumer name, or null
	 */
	public function get_payment_consumer_name() {

		if ( isset( $this->payment->details->consumerName ) ) {
			return $this->payment->details->consumerName;
		}

		return null;
	}


	/**
	 * Returns true if this was a test webhook request response
	 *
	 * @since 2.1
	 * @return boolean true if this is a test webhook request response
	 */
	public function is_test_webhook() {
		return isset( $this->response['testByMollie'] );
	}


	/**
	 * Returns the payment type: 'credit-card', 'echeck', etc
	 *
	 * @since 2.2.1-1
	 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response::get_payment_type()
	 * @return string payment type or null if not available
	 */
	public function get_payment_type() {
		// consider doing something here with the various gateway types?  Use in place of get_payment_method()?
		return 'multiple';
	}


	/**
	 * Returns the card PAN or checking account number, if available
	 *
	 * @since 2.2.1-1
	 * @see SV_WC_Payment_Gateway_API_Payment_Notification_Response::get_account_number()
	 * @return string PAN or account number or null if not available
	 */
	public function get_account_number() {

		if ( isset( $this->payment->details->consumerAccount ) ) {
			return $this->payment->details->consumerAccount;
		}

		return null;
	}


	/**
	 * Determine if this is an IPN or redirect response.
	 *
	 * @since 2.9.0
	 * @return bool
	 */
	public function is_ipn() {

		if ( isset( $this->response['id'] ) && isset( $this->response['key'] ) ) {
			return false;
		} else {
			return true;
		}
	}


}
