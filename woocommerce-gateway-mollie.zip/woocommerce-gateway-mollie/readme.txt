=== WooCommerce Mollie Gateway ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.7.3
Requires WooCommerce at least: 2.5.5
Tested WooCommerce up to: 3.0.0

Accept payment in WooCommerce with Mollie iDEAL, Credit Card, Mister Cash, Bank Transfer, PayPal, PaySafeCard, and SOFORT

See http://docs.woothemes.com/document/mollie-ideal/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-mollie' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
