<?php
/**
 * Plugin Name: WooCommerce Mollie Gateway
 * Plugin URI: http://www.woocommerce.com/products/ideal-mollie/
 * Description: Accept payment in WooCommerce with Mollie iDEAL, Credit Card, Mister Cash, Bank Transfer, PayPal, PaySafeCard, SOFORT, and Belfius Direct Net
 * Author: SkyVerge
 * Author URI: http://www.woocommerce.com/
 * Version: 2.11.0
 * Text Domain: woocommerce-gateway-mollie
 * Domain Path: /i18n/languages/
 *
 * Copyright: (c) 2011-2017, SkyVerge, Inc. (info@skyverge.com)
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-Mollie
 * @author    SkyVerge
 * @category  Payment-Gateways
 * @copyright Copyright (c) 2011-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), '7ad972886e772fd51f17f1c8d6ace285', '18612' );

// Check if WooCommerce is active
if ( ! is_woocommerce_active() ) {
	return;
}

// Required library class
if ( ! class_exists( 'SV_WC_Framework_Bootstrap' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'lib/skyverge/woocommerce/class-sv-wc-framework-bootstrap.php' );
}

SV_WC_Framework_Bootstrap::instance()->register_plugin( '4.6.0', __( 'WooCommerce Mollie Gateway', 'woocommerce-gateway-mollie' ), __FILE__, 'init_woocommerce_gateway_mollie', array(
	'is_payment_gateway'   => true,
	'minimum_wc_version'   => '2.5.5',
	'minimum_wp_version'   => '4.1',
	'backwards_compatible' => '4.4',
) );

function init_woocommerce_gateway_mollie() {

/**
 * # WooCommerce Mollie Gateway Main Plugin Class
 *
 * ## Plugin Overview
 *
 * This plugin adds Mollie Hosted Payment as a payment gateway.  This class handles all the
 * non-gateway tasks such as verifying dependencies are met, loading the text
 * domain, etc.
 *
 * ## Features
 *
 * Supported payment methods:
 *
 * + iDEAL
 * + Credit Card
 * + Mister Cash
 * + PayPal
 * + PaySafeCard
 * + SOFORT
 * + Belfius Direct Net
 *
 * ## Frontend Considerations
 *
 * The pay form on checkout (and checkout->pay) is quite simple and uses a
 * template file for easy customization.
 *
 * Individual checkout options are created for each of the Mollie methods
 * available for the account.
 *
 * ## Payment Flow
 *
 * 1. Customer chooses to check out with one of the Mollie methods and clicks
 *    "Place Order" from the checkout page
 * 2. A direct API request is made to the Mollie API.  Returned in the response
 *    is a payment url to the hosted payment page
 * 3. Client browser is redirected to the payment URL, where they choose to
 *    approve or decline payment
 * 4. The client browser is redirected back to the WooCommerce site "Thank You"
 *    page
 * 5. A webhook (IPN) request with the results is made to the configured
 *    webhook URL
 *
 * ## Database
 *
 * ### Global Settings
 *
 * + `woocommerce_mollie_settings` - the serialized gateway settings array
 *
 * ### Options table
 *
 * + `wc_mollie_version` - the current plugin version, set on install/upgrade
 *
 * ### Order Meta
 *
 * + `_wc_mollie_trans_date` - the datetime of the transaction completion
 * + `_wc_mollie_trans_id` - the payment ID returned by Mollie
 * + `_wc_mollie_environment` - the environment the transaction was created in, one of 'test' or 'production'
 * + `_wc_mollie_method` - the payment method used (ideal, creditcard, mistercash, bitcoin, paypal, paysafecard, sofort, belfius)
 *
 * @since 2.0
 */
class WC_Mollie extends SV_WC_Payment_Gateway_Plugin {


	/** version number */
	const VERSION = '2.11.0';

	/** @var WC_Mollie single instance of this plugin */
	protected static $instance;

	/** the plugin id */
	const PLUGIN_ID = 'mollie';

	/** the gateway class name */
	const GATEWAY_CLASS_NAME = 'WC_Gateway_Mollie';

	/** @var array array of child gateways */
	protected $gateways;


	/**
	 * Setup main plugin class
	 *
	 * @since 2.0
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			array(
				'text_domain' => 'woocommerce-gateway-mollie',
				'gateways'    => array(
					self::PLUGIN_ID => self::GATEWAY_CLASS_NAME,
				),
				'dependencies' => array( 'curl' ),
				'currencies'   => array( 'EUR' ),
			)
		);

		$this->gateways = array(
			'ideal'        => 'WC_Gateway_Mollie_iDEAL',
			'creditcard'   => 'WC_Gateway_Mollie_CreditCard',
			'mistercash'   => 'WC_Gateway_Mollie_MisterCash',
			'banktransfer' => 'WC_Gateway_Mollie_BankTransfer',
			'bitcoin'      => 'WC_Gateway_Mollie_Bitcoin',
			'paypal'       => 'WC_Gateway_Mollie_PayPal',
			'paysafecard'  => 'WC_Gateway_Mollie_Paysafecard',
			'sofort'       => 'WC_Gateway_Mollie_SOFORT',
			'belfius'      => 'WC_Gateway_Mollie_Belfius',
		);

		// Load gateway files
		add_action( 'sv_wc_framework_plugins_loaded', array( $this, 'includes' ), 11 );

		add_action( 'init', array( $this, 'include_template_functions' ), 25 );

		add_filter( 'option_woocommerce_gateway_order', array( $this, 'fix_mollie_gateway_order' ) );
	}


	/**
	 * Loads any required files
	 *
	 * @since 2.0
	 */
	public function includes() {

		$path = $this->get_plugin_path();

		// gateway classes
		require_once( $path . '/includes/class-wc-gateway-mollie.php' );

		foreach ( array_keys( $this->gateways ) as $gateway ) {

			if ( is_readable( $path . "/includes/class-wc-gateway-mollie-{$gateway}.php" ) ) {
				require_once( $path . "/includes/class-wc-gateway-mollie-{$gateway}.php" );
			}
		}
	}


	/**
	 * Function used to init any gateway template functions,
	 * making them pluggable by plugins and themes.
	 *
	 * @since 2.0
	 */
	public function include_template_functions() {
		require_once( $this->get_plugin_path() . '/includes/wc-gateway-mollie-template.php' );
	}


	/**
	 * Adds any gateways supported by this plugin to the list of available payment gateways
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway_Plugin::load_gateways()
	 * @param array $gateways
	 * @return array $gateways
	 */
	public function load_gateways( $gateways ) {

		// if we're in the admin or on the callback, use the normal behavior
		if ( ( is_admin() && ! is_ajax() ) || $this->is_wc_api() ) {
			return parent::load_gateways( $gateways );
		}

		// need to instantiate a gateway instance so we can pull the available methods
		$gateway = $this->get_gateway();

		try {

			foreach ( $gateway->get_methods() as $method ) {

				$gateway_class = isset( $this->gateways[ $method->id ] ) ? $this->gateways[ $method->id ] : null;

				if ( $gateway_class ) {
					$gateways[] = $gateway_class;
				}
			}
		} catch( Mollie_API_Exception $e ) {
			if ( $gateway->debug_log() ) {
				$this->log( sprintf( 'Error getting methods: %s', $e->getMessage() ), $this->get_id() );
			}
		}

		/**
		 * Filter the Mollie gatways allowing plugins to reorder or remove gateways
		 *
		 * @since 2.4.4
		 * @param array $gateways An array of Mollie gateway classes to add as available gatways.
		 */
		return apply_filters( 'wc_gateway_mollie_gateways', $gateways );
	}


	/**
	 * Returns true if the current request is for the woocommerce api endpoint
	 *
	 * @since 2.0
	 * @return boolean true if the current request is for the woocommerce api endpoint
	 */
	protected function is_wc_api() {
		return isset( $_REQUEST['wc-api'] ) && self::GATEWAY_CLASS_NAME == $_REQUEST['wc-api'];
	}


	/**
	 * Fix the Mollie child gateways ordering.  Since Mollie is a special
	 * gateway which creates 5 "child" gateways each with their own id, we need
	 * to filter on the gateway ordering set by the admin to expand the single
	 * 'mollie' entry into the five possible options.  This means you can't
	 * specify the ordering of each individually, but probably good enough to
	 * move them around as a block
	 *
	 * @since 2.1
	 * @param array $ordering associative array of gateway id to numerical order
	 * @return array associative array of gateway id to to numerical order
	 */
	public function fix_mollie_gateway_order( $ordering ) {

		if ( is_admin() && ! is_ajax() ) {
			return $ordering;
		}

		$new_ordering = array();
		$offset = 0;

		foreach ( $ordering as $gateway_id => $order ) {

			if ( self::PLUGIN_ID == $gateway_id ) {

				foreach ( array_keys( $this->gateways ) as $gateway ) {
					$new_ordering[ 'mollie_' . $gateway ] = $order++;
				}

				$offset = count( $this->gateways ) - 1;
			} else {
				$new_ordering[ $gateway_id ] = $order + $offset;
			}
		}

		return $new_ordering;
	}


	/** Admin methods ******************************************************/


	/**
	 * This is called after the gateway settings are saved.  Display any admin
	 * notices that might depend on the plugin settings
	 *
	 * @since 2.4.0
	 * @see SV_WC_Payment_Gateway_Plugin::add_delayed_admin_notices()
	 */
	public function add_delayed_admin_notices() {

		parent::add_delayed_admin_notices();

		// look for sign of a legacy-API install, and instruct the admin to update their mollie account settings
		$settings = $this->get_gateway_settings( $this->get_id() );

		// legacy settings?
		if ( isset( $settings['partner_id'] ) ) {
			$this->get_admin_notice_handler()->add_admin_notice(
				sprintf(
					__( 'This plugin now uses the updated Mollie API, in order to accept payments you will need to log onto your Mollie account and create an API Key, and set the Webhook URL given in the %ssettings page%s, then update the plugin settings with that API Key.', 'woocommerce-gateway-mollie' ),
					'<a href="' . $this->get_settings_url( $this->get_id() ) . '">',
					'</a>' ),
				'update-account-settings',
				array( 'notice_class' => 'error' )
			);
		}

		if ( $this->is_plugin_settings() && $this->get_gateway()->get_api_key() ) {
			// test the API key

			try {
				$methods = $this->get_gateway()->get_methods();
			} catch ( Mollie_API_Exception $e ) {
				// communication error
				$this->get_admin_notice_handler()->add_admin_notice( __( 'Error connecting to Mollie with the supplied API Key, please verify and update the plugin settings', 'woocommerce-gateway-mollie' ), 'invalid-api-key', array( 'notice_class' => 'error' ) );

				$gateway = $this->get_gateway();
				if ( $gateway->debug_log() ) {
					$this->log( sprintf( 'Error retrieving methods: %s', $e->getMessage() ), $this->get_id() );
				}
			}
		}

	}


	/** Helper methods ******************************************************/


	/**
	 * Saves errors or messages to WooCommerce Log (woocommerce/logs/plugin-id-xxx.txt)
	 *
	 * @since 2.1
	 * @see SV_WC_Plugin::log()
	 * @param string $message error or message to save to log
	 * @param string $log_id optional log id to segment the files by, defaults to plugin id
	 */
	public function log( $message, $log_id = null ) {

		// the Mollie payment gateway is implemented by multiple individual
		// payment methods, each with their own id, but not really truly
		// independent methods.  Therefore, when logging, always use the plugin
		// id, so we have a single consolidated logfile
		parent::log( $message, $this->get_id() );
	}


	/** Helper methods ******************************************************/


	/**
	 * Main Mollie Instance, ensures only one instance is/can be loaded
	 *
	 * @since 2.5.0
	 * @see wc_mollie()
	 * @return WC_Mollie
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	/**
	 * Gets the plugin support URL
	 *
	 * @since 2.6.0
	 * @see SV_WC_Plugin::get_support_url()
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/tickets/';
	}


	/**
	 * Gets the plugin documentation url
	 *
	 * @since 2.0
	 * @return string documentation URL
	 */
	public function get_documentation_url() {
		return 'http://docs.woocommerce.com/document/mollie-ideal/';
	}


	/**
	 * Returns the plugin name, localized
	 *
	 * @since 2.0
	 * @see SV_WC_Payment_Gateway::get_plugin_name()
	 * @return string the plugin name
	 */
	public function get_plugin_name() {
		return __( 'WooCommerce Mollie', 'woocommerce-gateway-mollie' );
	}


	/**
	 * Returns __FILE__
	 *
	 * @since 2.0
	 * @return string the full path and filename of the plugin file
	 */
	protected function get_file() {
		return __FILE__;
	}


	/**
	 * Transform the API request/response data into a string suitable for logging
	 *
	 * @since 2.3.2
	 * @see SV_WC_Plugin::get_api_log_message()
	 * @param mixed $data request/response data
	 * @return string
	 */
	public function get_api_log_message( $data ) {

		$messages = array();

		if ( is_object( $data ) && 'Mollie_API_Object_Payment' == get_class( $data ) ) {
			$data = array(
				'id'              => $data->id,
				'mode'            => $data->mode,
				'createdDatetime' => $data->createdDatetime,
				'status'          => $data->status,
				'amount'          => $data->amount,
				'description'     => $data->description,
				'method'          => $data->method,
				'metadata'        => $data->metadata,
				'details'         => $data->details,
				'links'           => $data->links,
			);
		}

		if ( is_array( $data ) ) {
			$messages[] = isset( $data['uri'] ) && $data['uri'] ? 'Request' : 'Response';

			foreach ( (array) $data as $key => $value ) {
				$messages[] = sprintf( '%s: %s', $key, is_array( $value ) || ( is_object( $value ) && 'stdClass' == get_class( $value ) ) ? print_r( (array) $value, true ) : $value );
			}
		}

		return implode( "\n", $messages );
	}


	/**
	 * Payment gateway install method.
	 *
	 * @since 2.0
	 * @see SV_WC_Plugin::install()
	 */
	protected function install() {

		// there was no database version prior to 2.0, so if we have settings on install then it means we're updating from 1.7
		if ( $this->get_gateway_settings( $this->get_id() ) ) {
			return $this->upgrade( '1.7' );
		}

		// normal install

		// for a fresh install, mark the update-account-settings message as
		//  dismissed because it will never be shown to the admin anyways
		$this->get_admin_notice_handler()->dismiss_notice( 'update-account-settings' );
	}


	/**
	 * Payment gateway update method
	 *
	 * @since 2.0
	 * @see SV_WC_Plugin::upgrade()
	 * @param string $installed_version the currently installed version of the plugin
	 */
	protected function upgrade( $installed_version ) {

		if ( version_compare( $installed_version, '2.0', '<' ) ) {

			$settings = $this->get_gateway_settings( $this->get_id() );

			// base the current environment on the old testmode setting
			$settings['environment'] = 'yes' == $settings['testmode'] ? 'test' : 'production';
			unset( $settings['testmode'] );

			update_option( $this->get_gateway_settings_name( $this->get_id() ), $settings );
		}

		if ( version_compare( $installed_version, '2.2.1', '<' ) ) {

			$settings = $this->get_gateway_settings( $this->get_id() );

			if ( ! isset( $settings['title'] ) ) {
				$settings['title'] = '{method title}';
			}

			if ( ! isset( $settings['description'] ) ) {
				$settings['description'] = 'Pay securely using {method title}';
			}

			update_option( $this->get_gateway_settings_name( $this->get_id() ), $settings );
		}
	}


} // end WC_Mollie


/**
 * Returns the One True Instance of Mollie
 *
 * @since 2.5.0
 * @return WC_Mollie
 */
function wc_mollie() {
	return WC_Mollie::instance();
}

// fire it up!
wc_mollie();

} // init_woocommerce_gateway_mollie()
