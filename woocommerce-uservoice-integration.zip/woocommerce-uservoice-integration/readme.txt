=== WooCommerce UserVoice Extension ===
Contributors: woothemes
Requires at least: 3.0
Tested up to: 3.7.1
Stable tag: 1.1.3

== Description ==

Adds functionality for UserVoice (http://www.uservoice.com) to your WooCommerce powered website.

== Installation ==

Enable the plugin the go to WooCommerce > Settings > Integration and select UserVoice from the list of integrations. Change the plugin settings as you need them to be.