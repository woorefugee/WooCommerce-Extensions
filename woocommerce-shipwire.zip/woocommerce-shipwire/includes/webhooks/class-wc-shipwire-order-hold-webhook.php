<?php
/**
 * WooCommerce Shipwire
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Shipwire to newer
 * versions in the future. If you wish to customize WooCommerce Shipwire for your
 * needs please refer to http://docs.woocommerce.com/document/shipwire/ for more information.
 *
 * @package     WC-Shipwire/Webhooks
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * The order webhook class.
 *
 * @since 2.1.0
 */
class WC_Shipwire_Order_Hold_Webhook extends WC_Shipwire_Order_Webhook {


	/**
	 * Constructs the class.
	 *
	 * @since 2.1.0
	 */
	public function __construct() {

		parent::__construct();

		$this->topics = array(
			'order.hold.added',
			'order.hold.cleared',
		);
	}


	/**
	 * Process the request after validation.
	 *
	 * @since 2.1.0
	 */
	protected function process_request() {

		$data = $this->get_request_body();

		$resource_url  = parse_url( $data->resourceLocation );
		$resource_path = explode( '/', $resource_url['path'] );

		$order = $this->get_order( $resource_path[4] );

		$order->update_tracking();
	}


}
