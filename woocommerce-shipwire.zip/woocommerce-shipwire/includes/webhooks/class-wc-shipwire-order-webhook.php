<?php
/**
 * WooCommerce Shipwire
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Shipwire to newer
 * versions in the future. If you wish to customize WooCommerce Shipwire for your
 * needs please refer to http://docs.woocommerce.com/document/shipwire/ for more information.
 *
 * @package     WC-Shipwire/Webhooks
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * The order webhook class.
 *
 * @since 2.1.0
 */
class WC_Shipwire_Order_Webhook extends WC_Shipwire_Webhook {


	/**
	 * Constructs the class.
	 *
	 * @since 2.1.0
	 */
	public function __construct() {

		parent::__construct();

		$this->topics = array(
			'order.updated',
			'order.canceled',
			'order.completed',
			'tracking.created',
			'tracking.delivered',
			'tracking.updated',
		);
	}


	/**
	 * Determine if this webhook is enabled.
	 *
	 * @since 2.1.0
	 * @return bool
	 */
	protected function enabled() {

		/**
		 * Filters whether WooCommerce order data should be automatically
		 * updated by Shipwire.
		 *
		 * @since 2.1.0
		 * @param bool $enabled
		 */
		return (bool) apply_filters( 'wc_shipwire_auto_update_orders', 'yes' === get_option( 'wc_shipwire_auto_update_tracking' ) );
	}


	/**
	 * Process the request after validation.
	 *
	 * @since 2.1.0
	 */
	protected function process_request() {

		$data = $this->get_request_body()->resource;

		$shipwire_order = null;

		if ( isset( $data->orderNo ) ) {

			$shipwire_id = $data->id;

			$shipwire_order = new WC_Shipwire_API_Order( $data );

		} else {

			$shipwire_id = $data->orderId;
		}

		$order = $this->get_order( $shipwire_id );

		$order->update_tracking( $shipwire_order );
	}


	/**
	 * Gets a WC order based on a Shipwire ID.
	 *
	 * @since 2.1.0
	 * @param string $shipwire_id the Shipwire order ID
	 * @return \WC_Shipwire_Order
	 * @throws \SV_WC_Plugin_Exception
	 */
	protected function get_order( $shipwire_id ) {
		global $wpdb;

		$shipwire_id = trim( $shipwire_id );

		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_value=%d", $shipwire_id ) );

		// get the WC order object
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			throw new SV_WC_Plugin_Exception( sprintf( 'Order %s not found.', $shipwire_id ) );
		}

		$order = new WC_Shipwire_Order( $order_id );

		if ( $shipwire_id !== SV_WC_Order_Compatibility::get_meta( $order, '_wc_shipwire_order_id' ) ) {
			throw new SV_WC_Plugin_Exception( 'Invalid order. Shipwire ID ' . $shipwire_id . ' not found.' );
		}

		return $order;
	}


}
