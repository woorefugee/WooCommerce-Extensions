<?php
/**
 * WooCommerce Shipwire
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Shipwire to newer
 * versions in the future. If you wish to customize WooCommerce Shipwire for your
 * needs please refer to http://docs.woocommerce.com/document/shipwire/ for more information.
 *
 * @package     WC-Shipwire/Webhooks
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * The base webhook class.
 *
 * @since 2.1.0
 */
abstract class WC_Shipwire_Webhook {


	/** @var array the webhook topics **/
	protected $topics = array();

	/** @var string raw request data **/
	protected $raw_request_data;

	/** @var string request data, decoded **/
	protected $request_data;

	/** @var string the hash used to validate the request */
	protected $request_hash;

	/** @var string the request secret used to generate the signature hash */
	protected $request_secret;


	/**
	 * Construct the class.
	 *
	 * @since 2.1.0
	 */
	public function __construct() {

		add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'handle_request' ) );
	}


	/**
	 * Determine if this webhook is enabled.
	 *
	 * @since 2.1.0
	 * @return bool
	 */
	protected function enabled() {
		return true;
	}


	/**
	 * Handle the request.
	 *
	 * @since 2.1.0
	 */
	public function handle_request() {

		// The Shipwire API performs HEAD requests when verifying the webhook
		// payload URL, so just return 200 in this case
		if ( ! $this->enabled() || 'HEAD' === $this->get_request_method() ) {
			status_header( 200 );
			die();
		}

		try {

			// log the request data
			$this->log_request();

			$this->validate_request();

			$this->process_request();

			$status_code = 200;

		} catch ( SV_WC_Plugin_Exception $e ) {

			wc_shipwire()->log( '[Webhook Error] ' . $e->getMessage() );

			$status_code = 400;
		}

		status_header( $status_code );
		die();
	}


	/**
	 * Validate the webhook request.
	 *
	 * @since 2.1.0
	 * @throws \SV_WC_Plugin_Exception
	 * @return bool
	 */
	protected function validate_request() {

		if ( 'POST' !== $this->get_request_method() ) {
			throw new SV_WC_Plugin_Exception( 'Invalid request method.' );
		}

		if ( ! $this->get_request_signature() ) {
			throw new SV_WC_Plugin_Exception( 'Missing signature.' );
		}

		$this->parse_signature();

		$hash = hash_hmac( 'sha256', $this->get_raw_request_data(), pack( 'H*', $this->get_request_secret() ) );

		if ( $hash !== $this->get_request_hash() ) {
			throw new SV_WC_Plugin_Exception( 'Invalid hash.' );
		}

		// If not a request of this topic, bail
		if ( ! in_array( $this->get_request_topic(), $this->get_topics() ) ) {
			throw new SV_WC_Plugin_Exception( 'Invalid topic.' );
		}

		if ( ! $this->get_request_body() ) {
			throw new SV_WC_Plugin_Exception( 'Invalid data.' );
		}
	}


	/**
	 * Process the request after validation.
	 *
	 * @since 2.1.0
	 */
	protected function process_request() {}


	/**
	 * Get the request method.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_method() {

		return $_SERVER['REQUEST_METHOD'];
	}


	/**
	 * Get the request signature.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_signature() {

		return isset( $_SERVER['HTTP_X_SHIPWIRE_SIGNATURE'] ) ? $_SERVER['HTTP_X_SHIPWIRE_SIGNATURE'] : '';
	}


	/**
	 * Get the request hash.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_hash() {

		return $this->request_hash;
	}


	/**
	 * Get the request secret.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_secret() {

		return $this->request_secret;
	}


	/**
	 * Parse out the request hash and secret ID from the signature.
	 *
	 * @since 2.1.0
	 * @throws \SV_WC_Plugin_Exception when the signatures could not be parsed
	 */
	protected function parse_signature() {

		if ( ! $this->get_request_signature() ) {
			throw new SV_WC_Plugin_Exception( 'No signature available.' );
		}

		// signature starts as `abc123;secret-id=2, abc123;secret-id=2`
		// will include as many signatures as have been created by the plugin
		$raw_signatures = explode( ', ', $this->get_request_signature() );
		$signatures     = array();

		foreach ( $raw_signatures as $signature_string ) {

			list( $hash, $secret_string ) = explode( ';', $signature_string );

			$secret = wp_parse_args( $secret_string, array(
				'secret-id' => 0,
			) );

			// if a matching secret is found, use it and bail
			if ( $secret = $this->get_stored_secret( $secret['secret-id'] ) ) {

				$this->request_hash   = $hash;
				$this->request_secret = $secret;

				return;
			}
		}

		throw new SV_WC_Plugin_Exception( 'No valid hash secret could be found. Please reset your webhooks.' );
	}


	/**
	 * Get the raw request body.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_raw_request_data() {

		if ( is_null( $this->raw_request_data ) ) {
			$this->raw_request_data = file_get_contents( 'php://input' );
		}

		return $this->raw_request_data;
	}


	/**
	 * Get the request data, decoded.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_data() {

		return json_decode( $this->get_raw_request_data() );
	}


	/**
	 * Get the request topic.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_topic() {

		$data = $this->get_request_data();

		return isset( $data->topic ) ? $data->topic : '';
	}


	/**
	 * Get the request body.
	 *
	 * @since 2.1.0
	 * @return string
	 */
	protected function get_request_body() {

		$data = $this->get_request_data();

		return isset( $data->body ) ? $data->body : '';
	}


	/**
	 * Get the stored secret for hash validation.
	 *
	 * @since 2.1.0
	 * @param int $id the secret ID
	 * @return string
	 */
	protected function get_stored_secret( $id ) {

		$secrets = get_option( 'wc_shipwire_secrets', array() );

		return isset( $secrets[ $id ] ) ? $secrets[ $id ] : '';
	}


	/**
	 * Log the webhook request.
	 *
	 * @since 2.1.0
	 */
	protected function log_request() {

		wc_shipwire()->log( "Webhook Request\ntopic: " . $this->get_request_topic() . "\nbody: " . $this->get_raw_request_data() . "\n" );
	}


	/**
	 * Gets the topics handled by this webhook.
	 *
	 * @since 2.1.0
	 * @return array
	 */
	public function get_topics() {

		return $this->topics;
	}


}
