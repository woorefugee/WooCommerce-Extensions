<?php
/**
 * WooCommerce Shipwire
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Shipwire to newer
 * versions in the future. If you wish to customize WooCommerce Shipwire for your
 * needs please refer to http://docs.woocommerce.com/document/shipwire/ for more information.
 *
 * @package     WC-Shipwire/API
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * Handle a Shipwire API shipping rate request.
 *
 * @since 2.0.0
 */
class WC_Shipwire_API_Rate_Request extends WC_Shipwire_API_Request {


	/**
	 * Process a WooCommerce package for the API.
	 *
	 * @since 2.0.0
	 * @param array $package
	 * @return
	 */
	public function process_package( $package ) {

		$data = array(
			'options' => array(
				/**
				 * Filters the shipping rate API request currency.
				 *
				 * @since 2.1.0
				 * @param array $package the shipping package
				 */
				'currency' => apply_filters( 'wc_shipwire_shipping_rate_request_currency', get_woocommerce_currency(), $package ),
			),
			'order' => array(
				'shipTo' => array(),
				'items'  => array(),
			),
		);

		$data['order']['shipTo'] = array(
			'address1'   => $package['destination']['address'],
			'address2'   => $package['destination']['address_2'],
			'city'       => $package['destination']['city'],
			'postalCode' => $package['destination']['postcode'],
			'region'     => $package['destination']['state'],
			'country'    => $package['destination']['country'],
		);

		foreach( $package['contents'] as $item ) {

			// skip virtual products
			if ( ! $item['data']->needs_shipping() ) {
				continue;
			}

			$data['order']['items'][] = array(
				'sku'      => $item['data']->get_sku(),
				'quantity' => $item['quantity']
			);
		}

		// TODO: back compat only - remove in a future version {CW 2016-06-14}
		$data['order'] = (array) apply_filters( 'wc_shipwire_shipping_method_shipment', (object) $data['order'], $package );

		/**
		 * Filter the Shipwire API rate package.
		 *
		 * @since 2.0.0
		 * @param array $package
		 * @param array $wc_package
		 */
		$data['order'] = apply_filters( 'wc_shipwire_shipping_rate_request_order', $data['order'], $package );

		$this->path   = '/rate';
		$this->data = $data;
	}


}
