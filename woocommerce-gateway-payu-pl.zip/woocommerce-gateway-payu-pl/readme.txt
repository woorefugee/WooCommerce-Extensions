=== WOOCOMMERCE PAYU PL GATEWAY ===
By Daniel Dudzic - http://danieldudzic.com/
Based on PayPal Standard Gateway by WooCommerce

== Docs on WooThemes.com ==

You can view the official extension docs here: http://docs.woothemes.com/document/payu-poland-payment-gateway/


== POLSKI ==
== OPIS ==

Bramka płatności PayU PL rozszerza WooCommerce, umożliwiając pobieranie opłat przez serwis PayU. PayU współpracuje z VISA, MasterCard, Diners Club i wieloma polskimi Bankami (kompletna lista partnerów: http://www.payu.pl/dla-sklepow/szeroki-wachlarz-uslug).

Po wyborze płatności użytkownik jest przekierowywany do serwisu PayU, aby dokonać płatności. Na Twojej stronie nie jest wymagany certyfikat SSL. Po dokonaniu płatności użytkownik jest przekierowywany z powrotem do sklepu na stronę z podziękowaniem.


== WAŻNE INFORMACJE ==

Aby używać tej bramki musisz mieć konto w PayU.

Ta bramka płatności działa tylko jeśli waluta jest ustawiona na Polski Złoty.


## Ustawienia adresów w PayU

#### Adres powrotu błędnego

http://twojastrona.pl/slug_strony_zamówień/endpoint_odebranego_zamówienia/%orderId%/?key=%sessionId%&order_id=%orderId%&gateway_error=%error%

Przykład używający domyślnych wartości:

Endpoint odebranego zamówienia: order-received
Slug strony zamówienia: checkout

Przykładowy adres powrotu błędnego:
http://twojastrona.pl/checkout/order-received/%orderId%/?key=%sessionId%&order_id=%orderId%&gateway_error=%error%


#### Adres powrotu pozytywnego

http://twojastrona.pl/slug_strony_zamówień/endpoint_odebranego_zamówienia/%orderId%/?key=%sessionId%

Przykład używający domyślnych wartości:

Endpoint odebranego zamówienia: order-received
Slug strony zamówienia: checkout

Przykładowy adres powrotu pozytywnego:
http://twojastrona.pl/checkout/order-received/%orderId%/?key=%sessionId%


#### Adres raportów

http://twojastrona.pl/?wc-api=wc_gateway_payu_pl


#### Kodowanie przesyłanych danych

UTF-8


== INSTALACJA ==

Możesz zainstalować tę bramkę płatności tak jak każdy plugin do WordPressa.

1. Ściągnij i rozpakuj plik z wtyczką.
2. Wgraj cały katalog wtyczki do katalogu /wp-content/plugins/ na serwerze.
3. Aktywuj wtyczkę w menu Wtyczki w panelu administracyjnym WordPressa.
4. Przejdź do ustawień WooCommerce a następnie Bramek płatności i skonfiguruj wtyczkę.

Możesz również użyć wysyłania wtyczki w pliku zip w panelu administracyjnym WordPressa w menu Wtyczki --> Wyślij na serwer. W takim przypadku przejdź bezpośrednio do punktu 3.



== ENGLISH ==
== DESCRIPTION ==

PayU PL is a gateway plugin that extends WooCommerce, allowing you to take payments via PayU. PayU cooperates with VISA, MasterCard, Diners Club and the Polish online banks and bank services (for complete list visit: http://www.payu.pl/dla-sklepow/szeroki-wachlarz-uslug). This means that you easily can take credit card payments as well as direct payments via any of the associated banks.

When the order goes through, the user is taken to PayU to make a secure payment. No SSL certificate is required on your site. After payment the order is confirmed and the user is taken to the thank you page.


== IMPORTANT NOTE ==

In order to use the PayU gateway you need a PayU merchant account. 

Note that the plugin only works if the currency is set to Polish Złoty.


## PayU Merchant Account Setup

#### Invalid return URL

http://yourwebsite.pl/slug_of_the_checkout/order_received_endpoint/%orderId%/?key=%sessionId%&order_id=%orderId%&gateway_error=%error%

Example using default values:

Order Received endpoint: order-received
Checkout page: checkout

Example invalid return URL:
http://yourwebsite.pl/checkout/order-received/%orderId%/?key=%sessionId%&order_id=%orderId%&gateway_error=%error%


#### Success return URL

http://yourwebsite.pl/slug_of_the_checkout/order_received_endpoint/%orderId%/?key=%sessionId%

Example using default values:
Order Received endpoint: order-received
Checkout page: checkout

Example success return URL:
http://yourwebsite.pl/checkout/order-received/%orderId%/?key=%sessionId%


#### Reports URL

http://yourwebsite.pl/?wc-api=wc_gateway_payu_pl


#### Encoding of transmitted data

UTF-8


== INSTALLATION	 ==

1. Download and unzip the latest release zip file.
2. If you use the WordPress plugin uploader to install this plugin skip to step 4.
3. Upload the entire plugin directory to your /wp-content/plugins/ directory.
4. Activate the plugin through the 'Plugins' menu in WordPress Administration.
5. Go WooCommerce Settings --> Payment Gateways and configure your PayU settings.