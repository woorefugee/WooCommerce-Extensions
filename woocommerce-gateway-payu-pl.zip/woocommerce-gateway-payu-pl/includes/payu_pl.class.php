<?php
/**
* PayU PL Payment Gateway
*
* Provides a PayU PL Payment Gateway.
*
* @class WC_Gateway_PayU_PL
* @package WooCommerce
* @category Payment Gateways
* @author Daniel Dudzic
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Gateway_PayU_PL extends WC_Payment_Gateway {

	/**
	 * Constructor
	 */
	public function __construct() {
        $this->id				  = 'payu_pl';
        $this->method_title       = __( 'PayU PL', 'woocommerce_payu_pl' );
		$this->method_description = __( 'PayU works by sending the user to <a href="http://www.payu.pl/">PayU</a> to enter their payment information. Note that PayU will only take payments in Polish Złoty.', 'woocommerce_payu_pl' );
        $this->icon 			  = WP_PLUGIN_URL . '/' . plugin_basename( dirname( dirname( __FILE__ ) ) ) . '/assets/images/icon.png';
        $this->has_fields 		  = false;
        $this->liveurl			  = 'https://secure.payu.com/paygw/UTF/NewPayment';

      	// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

      	// Check if the currency is set to PLN. If not we disable the plugin here.
		if ( get_woocommerce_currency() == 'PLN' ) {
			$payu_pl_enabled = $this->settings['enabled'];
		} else {
			$payu_pl_enabled = 'no';
		}

      	$this->enabled			= $payu_pl_enabled;
		$this->title 			= $this->get_option( 'title' );
		$this->description  	= $this->get_option( 'description' );
		$this->pos_id   		= $this->get_option( 'pos_id' );
		$this->first_md5   		= $this->get_option( 'first_md5' );
		$this->second_md5   	= $this->get_option( 'second_md5' );
		$this->pos_auth_key		= $this->get_option( 'pos_auth_key' );
		$this->validate_sig		= $this->get_option( 'validate_sig' );
		$this->testmode			= $this->get_option( 'testmode' );
		$this->callback_url     = str_replace( 'https:', 'http:', add_query_arg( 'wc-api', 'WC_Gateway_PayU_PL', trailingslashit( home_url() ) ) );

		// Actions
		add_action( 'valid-' . $this->id . '-request', array( $this, 'successful_request' ) );
		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );

		// Save options
		add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );

		// Payment listener/API hook
		add_action( 'woocommerce_api_wc_gateway_' . $this->id, array( $this, 'check_payu_pl_response' ) );

		/* 2.0.0 */
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		/* Change the status message on the Thank You page */
		add_filter( 'woocommerce_thankyou_order_received_text',  array( $this, 'change_order_text' ) );

		/* Cancel the order if customer resignes from making a payment */
		add_action( 'woocommerce_thankyou', array( $this, 'cancel_order' ) );
    }

	/**
	 * Initialise Gateway Settings Form Fields
	 *
	 * @since 1.0.0
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'woocommerce_payu_pl' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable PayU', 'woocommerce_payu_pl' ),
				'default' => 'yes'
			),
			'title' => array(
				'title'       => __( 'Title', 'woocommerce_payu_pl' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce_payu_pl' ),
				'default'     => __( 'PayU', 'woocommerce_payu_pl' )
			),
			'description' => array(
				'title'       => __( 'Description', 'woocommerce_payu_pl' ),
				'type'        => 'textarea',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce_payu_pl' ),
				'default'     => __( 'Direct payment via PayU. PayU cooperates with VISA, MasterCard, Diners Club and the Polish online banks and bank services.', 'woocommerce_payu_pl' ),
			),
			'pos_id' => array(
				'title'       => __( 'Service Point ID', 'woocommerce_payu_pl' ),
				'type'        => 'text',
				'description' => __( 'Please enter your pos_id number; this is needed in order to take payment!', 'woocommerce_payu_pl' ),
				'default'     => ''
			),
			'first_md5' => array(
				'title'       => __( 'First MD5', 'woocommerce_payu_pl' ),
				'type'        => 'text',
				'description' => __( 'Please enter your first MD5-Hash; this is needed in order to take payment!', 'woocommerce_payu_pl' ),
				'default'     => ''
			),
			'second_md5' => array(
				'title'       => __( 'Second MD5', 'woocommerce_payu_pl' ),
				'type'        => 'text',
				'description' => __( 'Please enter your second MD5-Hash; this is needed in order to take payment!', 'woocommerce_payu_pl' ),
				'default'     => ''
			),
			'pos_auth_key' => array(
				'title'       => __( 'Authorization Key', 'woocommerce_payu_pl' ),
				'type'        => 'text',
				'description' => __( 'Please enter your pos_auth_key; this is needed in order to take payment!', 'woocommerce_payu_pl' ),
				'default'     => ''
			),
			'validate_sig' => array(
				'title'   => __( 'Validate sig', 'woocommerce_payu_pl' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable this option, if you want to validate the sig.', 'woocommerce_payu_pl' ),
				'default' => 'no'
			),
			'testmode' => array(
				'title'   => __( 'Test Mode', 'woocommerce_payu_pl' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable PayU Test Mode. This is just to test your PayU account information. No payment will be made.', 'woocommerce_payu_pl' ),
				'default' => 'no'
			)
		);
	}

	/**
	 * Admin Panel Options
	 * - Options for bits like 'title' and availability on a country-by-country basis
	 *
	 * @since 1.0.0
	 */
	public function admin_options() {
		if ( get_woocommerce_currency() === 'PLN' ) {
			parent::admin_options();
		} else {
			?>
			<h3><?php _e( 'PayU', 'woocommerce_payu_pl' ); ?></h3>
			<div class="inline error"><p><strong><?php _e( 'Gateway Disabled', 'woocommerce_payu_pl' ); ?></strong> <?php echo sprintf( __( 'Choose Polish Złoty as your store currency in <a href="%s">Pricing Options</a> to enable the PayU Gateway.', 'woocommerce_payu_pl' ), admin_url( '?page=woocommerce&tab=general' ) ); ?></p></div>
			<?php
		}
	}

    /**
	 * There are no payment fields for PayU PL, but we want to show the description if set.
	 *
	 * @since 1.0.0
	 */
    public function payment_fields() {
    	if ( $this->description ) echo wpautop( wptexturize( $this->description ) );
    }

	/**
	 * Generate the PayU PL button link.
	 *
	 * @since 1.0.0
	 */
    public function generate_payu_pl_form( $order_id ) {
		$order       = wc_get_order( $order_id );
		$payu_pl_adr = $this->liveurl;
		$first_md5   = $this->first_md5;
		$second_md5  = $this->second_md5;

		// Merchant details
		$merchant = array(
			'pos_id'				=> $this->pos_id,
			'pos_auth_key'			=> $this->pos_auth_key
		);

		$pre_wc_30 = version_compare( WC_VERSION, '3.0', '<' );

		$order_key = $pre_wc_30 ? $order->order_key : $order->get_order_key();

		// Customer details
		$customer = array(
			'first_name' => $pre_wc_30 ? $order->billing_first_name : $order->get_billing_first_name(),
			'last_name'  => $pre_wc_30 ? $order->billing_last_name : $order->get_billing_last_name(),
			'email'      => $pre_wc_30 ? $order->billing_last_name : $order->get_billing_email(),
			'street'     => $pre_wc_30 ? $order->billing_address_1 : $order->get_billing_address_1(),
			'street_hn'  => $pre_wc_30 ? $order->billing_address_2 : $order->get_billing_address_2(),
			'city'       => $pre_wc_30 ? $order->billing_city : $order->get_billing_city(),
			'state'      => $pre_wc_30 ? $order->billing_state : $order->get_billing_state(),
			'post_code'  => $pre_wc_30 ? $order->billing_postcode : $order->get_billing_postcode(),
			'country'    => $pre_wc_30 ? $order->billing_country : $order->get_billing_country(),
			'phone'      => $pre_wc_30 ? $order->billing_phone : $order->get_billing_phone(),
			'client_ip'  => $_SERVER['REMOTE_ADDR']
		);

		// Item details
		$item = array(
			'desc'			        => sprintf( __( 'Order #%s from ', 'woocommerce_payu_pl' ), $order_id ) . get_bloginfo( 'name' ),
			'amount'				=> $order->get_total() * 100
		);

		$payuform = '';

		foreach( $merchant as $key => $value ) {
   			if ( $value ) {
	   			$payuform .= '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />' . "\n";
   			}
		}
		foreach( $customer as $key => $value ) {
   			if ( $value ) {
	   			$payuform .= '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />' . "\n";
   			}
		}
		foreach( $item as $key => $value ) {
   			if ( $value ) {
	   			$payuform .= '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />' . "\n";
   			}
		}

		$payuform .= '<input type="hidden" name="session_id" value="' . esc_attr( $order_key ) . '" />' . "\n";
		$payuform .= '<input type="hidden" name="order_id" value="' . esc_attr( $order_id ) . '" />' . "\n";
		$payuform .= '<input type="hidden" name="js" value="0" id="js_value" />' . "\n";

		if ( $this->testmode == 'yes' ) { $payuform .= '<input type="hidden" name="pay_type" value="t" />' . "\n"; }


		// Validate sig if necessary
		if ( $this->validate_sig == 'yes' ) {
			// Generate timestamp and add to the form
			$ts = time();
			$payuform .= '<input type="hidden" name="ts" value="' . esc_attr( $ts ) . '" />' . "\n";

			$additional_data = array(
				'session_id' => $order_key,
				'order_id'   => $order_id,
				'ts'         => $ts
			);

			if ( $this->testmode == 'yes' ) { $additional_data['pay_type'] = "t"; }

			$sig_data = array_merge($merchant, $customer, $item, $additional_data);

			$sig = $this->calculate_sig($sig_data);

			$payuform .= '<input type="hidden" name="sig" value="' . esc_attr( $sig ) . '" />' . "\n";
		}

		// Generate form
		$payuform .= '<script type="text/javascript">
			<!--
			document.getElementById("js_value").value=1;
			-->
			</script>';

		// The form
		return '<form action="' . esc_url( $payu_pl_adr ) . '" method="POST" name="payform" id="payform">
				' . $payuform . '
				<input type="submit" class="button" id="submit_payu_pl_payment_form" value="' . __( 'Pay via PayU', 'woocommerce_payu_pl' ) . '" /> <a class="button cancel" href="' . $order->get_cancel_order_url() . '">'.__( 'Cancel order &amp; restore cart', 'woocommerce_payu_pl' ) . '</a>
				<script type="text/javascript">
					jQuery(function(){
						jQuery("body").block(
							{
								message: "' . __( 'Thank you for your order. We are now redirecting you to PayU to make payment.', 'woocommerce_payu_pl' ) . '",
								overlayCSS:
								{
									background: "#fff",
									opacity: 0.6
								},
								css: {
							        padding:        20,
							        textAlign:      "center",
							        color:          "#555",
							        border:         "3px solid #aaa",
							        backgroundColor:"#fff",
							        cursor:         "wait",
							        lineHeight:		"32px"
							    }
							});
						jQuery("#submit_payu_pl_payment_form").click();
					});
				</script>
			</form>';
	}

	/**
	 * Process the payment and return the result.
	 *
	 * @since 1.0.0
	 */
	function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		return array(
			'result' 	=> 'success',
			'redirect'	=> $order->get_checkout_payment_url( true )
		);
	}

	/**
	 * Receipt page.
	 *
	 * Display text and a button to direct the user to the payment screen.
	 *
	 * @since 1.0.0
	 */
	function receipt_page( $order ) {
		echo '<p>' . __( 'Thank you for your order, please click the button below to pay with PayU.', 'woocommerce_payu_pl' ) . '</p>';
		echo $this->generate_payu_pl_form( $order );
	}

	/**
	 * Check for PayU PL response and verify validity.
	 *
	 * @since 1.0.0
	 */
	function check_payu_pl_response() {
		$second_md5 = $this->second_md5;
		$ts         = $_POST['ts'];
		$session_id = $_POST['session_id'];
		$sig        = $_POST['sig'];
		$pos_id     = $_POST['pos_id'];
		$sig_unhash = $pos_id . $session_id . $ts . $second_md5;

		// Put the variables returned from PayU PL in an array so we can pass them on
		// to the successful_request function.
		$return_values = array(
			'session_id' => $session_id,
			'sig'        => $sig
		);

		if ( $sig == md5( $sig_unhash ) ) {
			// Transaction was valid!
			do_action( 'valid-payu_pl-request', $return_values );
		}
	}

	/**
	 * Server callback was valid, process callback (update order as passed/failed etc).
	 *
	 * @since 1.0.0
	 */
	function successful_request( $return_values ) {
		$first_md5                   = $this->first_md5;
		$second_md5                  = $this->second_md5;
		$pos_id                      = $this->pos_id;
		$session_id	                 = $return_values['session_id'];
		$sig	                     = $return_values['sig'];
	    $timestamp                   = time();
		$sig                         = md5( $pos_id . $session_id . $timestamp . $first_md5 );
		$callback_data['pos_id']     = $pos_id;
		$callback_data['session_id'] = $session_id;
		$callback_data['ts']         = $timestamp;
		$callback_data['sig']        = $sig;

		// Call the PayU
		$response  = $this->send_request('https://secure.payu.com/paygw/UTF/Payment/get/txt', $callback_data);
		$temp_data = explode("\n", $response);

		foreach( $temp_data as $v ) {
			$t = explode(": ", $v);
			$data[ $t[0] ] = trim($t[1]);
		}

		$sig = md5( $data['trans_pos_id'] . $data['trans_session_id'] . $data['trans_order_id'] . $data['trans_status'] . $data['trans_amount'] . $data['trans_desc'] . $data['trans_ts'] . $second_md5 );

		if ( $data['trans_sig'] == $sig ) {
			switch ( $data['trans_status'] ) {
				case 1:  // New
					$transstatus = 'pending';
					$transmsg = __( 'New', 'woocommerce_payu_pl' );
				break;

				case 2:  // Cancelled
					$transstatus = 'cancelled';
					$transmsg = __( 'Cancelled', 'woocommerce_payu_pl' );
				break;

				case 3:  // Rejected
					$transstatus = 'failed';
					$transmsg = __( 'Rejected', 'woocommerce_payu_pl' );
				break;

				case 4:  // Started
					$transstatus = 'pending';
					$transmsg = __( 'Started', 'woocommerce_payu_pl' );
				break;

				case 5:  // Awaits for receiving
					$transstatus = 'processing';
					$transmsg = __( 'Awaits for receiving', 'woocommerce_payu_pl' );
				break;

				case 6:  // Negative authorization
					$transstatus = 'failed';
					$transmsg = __( 'Negative authorization', 'woocommerce_payu_pl' );
				break;

				case 7:  // Payment declined
					$transstatus = 'failed';
					$transmsg = __( 'Declined', 'woocommerce_payu_pl' );
				break;

				case 99:  // Payment recived - completed
					$transstatus = 'processing';
					$transmsg = __( 'Received', 'woocommerce_payu_pl' );
				break;

				case 888:  // Wrong status - we ask user to contact us
					$transstatus = 'on-hold';
					$transmsg = __( 'Wrong status - we ask user to contact us', 'woocommerce_payu_pl' );
				break;

				default:
					die( 'OK' );
				break;
			} // End SWITCH Statement

			if ( $transstatus ) {

				$order_id 	  	= $data['trans_order_id'];
				$order 			= new WC_Order( (int) $order_id );

				if ( $order->get_status() !== 'completed') {
					// put code here to update/store the order with the a result

					switch ( $transstatus ) {

						case 'pending': // New or Stated
							$order->update_status( 'pending', sprintf( __( 'PayU Payment: %s', 'woocommerce_payu_pl' ), $transmsg ) );
						break;

						case 'cancelled': // Cancelled
							$order->update_status('cancelled', __( 'PayU Payment: Cancelled', 'woocommerce_payu_pl' ) );
						break;

						case 'failed': // Rejected, Negative authorization or Declined
							$order->update_status( 'failed', sprintf( __( 'PayU Payment: %s', 'woocommerce_payu_pl' ), $transmsg ) );
						break;


						case 'on-hold': // Wrong status - we ask user to contact us
							$order->update_status( 'on-hold', sprintf( __( 'PayU Payment: %s', 'woocommerce_payu_pl' ), $transmsg ) );
						break;

						case 'processing': // Awaits for receiving or Payment recived - completed
							if ( $order->get_status() !== 'processing') {
								$order->payment_complete();
								//Add admin order note
								$order->add_order_note(sprintf( __( 'PayU Payment: %s', 'woocommerce_payu_pl' ), $transmsg ) );
								//Add customer order note
								$order->add_order_note(sprintf( __( 'Payment: %s', 'woocommerce_payu_pl' ), $transmsg ) );
								// Empty the Cart
								$woocommerce->cart->empty_cart();
							}
						break;

						default:
						//Nothing
						break;
					}

					//Let's print the info to PayU PL that everything is cool
					echo 'OK';
				} else {
					die( 'ERROR: Status variable is set to: ' . $order->get_status() );
				}
			}
			die();
		}
	}

	/**
	 * @since 2.1
	 */
	public function send_request( $host, $data ) {
		$response = wp_remote_post( $host, array(
            'body'    => $data,
            'timeout' => 70
        ) );

        if ( is_wp_error( $response ) ) {
            throw new Exception( __( 'There was a problem connecting to the payment gateway.', 'woocommerce_payu_pl' ) );
		}

        if (empty($response['body'] ) ) {
            throw new Exception( __( 'Empty PayU response.', 'woocommerce_payu_pl' ) );
		}

        return $response['body'];
	}

	/**
	 * @since 2.1
	 */
	public function calculate_sig( $data ) {
		$sig_data = '';
		if ( isset( $data['pos_id'] ) ) { $sig_data .= $data['pos_id']; } else { $sig_data .= ''; }
		if ( isset( $data['pay_type'] ) ) { $sig_data .= $data['pay_type']; } else { $sig_data .= ''; }
		if ( isset( $data['session_id'] ) ) { $sig_data .= $data['session_id']; } else { $sig_data .= ''; }
		if ( isset( $data['pos_auth_key'] ) ) { $sig_data .= $data['pos_auth_key']; } else { $sig_data .= ''; }
		if ( isset( $data['amount'] ) ) { $sig_data .= $data['amount']; } else { $sig_data .= ''; }
		if ( isset( $data['desc'] ) ) { $sig_data .= $data['desc']; } else { $sig_data .= ''; }
		if ( isset( $data['desc2'] ) ) { $sig_data .= $data['desc2']; } else { $sig_data .= ''; }
		if ( isset( $data['trsDesc'] ) ) { $sig_data .= $data['trsDesc']; } else { $sig_data .= ''; }
		if ( isset( $data['order_id'] ) ) { $sig_data .= $data['order_id']; } else { $sig_data .= ''; }
		if ( isset( $data['first_name'] ) ) { $sig_data .= $data['first_name']; } else { $sig_data .= ''; }
		if ( isset( $data['last_name'] ) ) { $sig_data .= $data['last_name']; } else { $sig_data .= ''; }
		if ( isset( $data['payback_login'] ) ) { $sig_data .= $data['payback_login']; } else { $sig_data .= ''; }
		if ( isset( $data['street'] ) ) { $sig_data .= $data['street']; } else { $sig_data .= ''; }
		if ( isset( $data['street_hn'] ) ) { $sig_data .= $data['street_hn']; } else { $sig_data .= ''; }
		if ( isset( $data['street_an'] ) ) { $sig_data .= $data['street_an']; } else { $sig_data .= ''; }
		if ( isset( $data['city'] ) ) { $sig_data .= $data['city']; } else { $sig_data .= ''; }
		if ( isset( $data['post_code'] ) ) { $sig_data .= $data['post_code']; } else { $sig_data .= ''; }
		if ( isset( $data['country'] ) ) { $sig_data .= $data['country']; } else { $sig_data .= ''; }
		if ( isset( $data['email'] ) ) { $sig_data .= $data['email']; } else { $sig_data .= ''; }
		if ( isset( $data['phone'] ) ) { $sig_data .= $data['phone']; } else { $sig_data .= ''; }
		if ( isset( $data['language'] ) ) { $sig_data .= $data['language']; } else { $sig_data .= ''; }
		if ( isset( $data['client_ip'] ) ) { $sig_data .= $data['client_ip']; } else { $sig_data .= ''; }
		if ( isset( $data['ts'] ) ) { $sig_data .= $data['ts']; } else { $sig_data .= ''; }
		$sig_data .= $this->first_md5;
		return md5( $sig_data );
	}

	/**
	 * Change the status message on the Thank You page.
	 *
	 * @since 2.3
	 */
	public function change_order_text( $text ) {
		if ( isset( $_GET['key'] ) && isset( $_GET['gateway_error'] ) ) {
			if ( $_GET['gateway_error'] == '501' ) {
				$text = __( 'Negative authorization. Your order has been cancelled.', 'woocommerce_payu_pl' );
			}
			if ( $_GET['gateway_error'] == '508' ) {
				$text = __( 'Your order has been cancelled.', 'woocommerce_payu_pl' );
			}
		}
		return $text;
	}

	/**
	 * Cancel the order if customer resignes from making a payment.
	 *
	 * @since 2.3
	 */
	public function cancel_order() {
		if ( isset( $_GET['key'] ) && isset( $_GET['order_id'] ) && isset( $_GET['gateway_error'] ) && $_GET['gateway_error'] == '508' ) {
			$order = wc_get_order( absint( $_GET['order_id'] ) );
			$order->update_status('cancelled', __( 'PayU Payment: Cancelled', 'woocommerce_payu_pl' ) );
		}
	}
}
