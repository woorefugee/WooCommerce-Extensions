<?php
/*
	Plugin Name: WooCommerce PayU PL Gateway
	Plugin URI: https://www.woocommerce.com/products/payu/
	Description: Provides a <a href="http://www.payu.pl/">PayU PL</a> gateway for WooCommerce.
	Version: 2.4.1
	Author: WooCommerce
	Author URI: https://woocommerce.com/
	Requires at least: 3.8
	Tested up to: 4.2
*/

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '2bcd3e766850b26469390434994a1f46', '18610' );

/**
 * Initializes the gateway.
 */
function init_payu_pl_gateway() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	// Localization
	load_plugin_textdomain('woocommerce_payu_pl', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');
	require_once( plugin_basename( 'includes/payu_pl.class.php' ) );

    /**
	 * add_gateway()
	 *
	 * Register the gateway within WooCommerce.
	 *
	 * @since 1.0.0
	 */
	function add_payu_pl_gateway( $methods ) {
		$methods[] = 'WC_Gateway_PayU_PL';
		return $methods;
	}
	add_filter( 'woocommerce_payment_gateways', 'add_payu_pl_gateway' );
}
add_action( 'plugins_loaded', 'init_payu_pl_gateway', 0 );
