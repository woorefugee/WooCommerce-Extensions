<?php
/**
 * Plugin Name: WooCommerce Skrill Payment Gateway
 * Plugin URI: http://www.woocommerce.com/products/skrill/
 * Description: Adds the Skrill payment gateway to your WooCommerce website.
 * Author: SkyVerge
 * Author URI: http://www.woocommerce.com/
 * Version: 1.7.0
 * Text Domain: woocommerce-gateway-skrill
 * Domain Path: /i18n/languages/
 *
 * Copyright: (c) 2013-2017, SkyVerge, Inc.
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-Gateway-Skrill
 * @author    SkyVerge
 * @category  Gateways
 * @copyright Copyright (c) 2012-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), 'd24c5163063b4b576ba5f79a4b08b7ed', '18644' );

add_action ( 'plugins_loaded', 'woocommerce_skrill_init', 0);

function woocommerce_skrill_init() {

	if ( !class_exists( 'WC_Payment_Gateway' ) )
		return;

	load_plugin_textdomain( 'woocommerce-gateway-skrill', false, dirname( plugin_basename( __FILE__ ) ) . '/i18n/languages' );

	class WC_Gateway_Skrill extends WC_Payment_Gateway {

		/** Debug mode log to file */
		const DEBUG_MODE_LOG = 'log';

		/** Debug mode disabled */
		const DEBUG_MODE_OFF = 'off';

		/** @var string configuration option: 4 options for debug mode - off, checkout, log, both */
		private $debug_mode;

		/** @var WC_Logger instance */
		private $logger;

		function __construct() {
			$this->method_title = 'Skrill';
			$this->id           = 'skrill';
			$this->icon         = apply_filters( 'woocommerce_skrill_logo', plugins_url( basename( dirname(__FILE__) ) . '/assets/images/skrill-logo.gif' ) );

			// Load the form fields.
			$this->init_form_fields();

			// Load the settings.
			$this->init_settings();

			// Define user set variables
			$this->title                = $this->settings['title'];
			$this->description          = $this->settings['description'];
			$this->endpoint             = $this->settings['sandbox'] == 'yes' ? 'https://www.moneybookers.com/app/test_payment.pl' : 'https://www.moneybookers.com/app/payment.pl';
			$this->merchant_id          = $this->settings['merchant_id'];
			$this->pay_to_email         = $this->settings['pay_to_email'];
			$this->secret_word          = $this->settings['secret_word'];
			$this->skrill_description   = $this->settings['skrill_description'];
			$this->instructions         = $this->settings['instructions'];
			$this->status_url2          = $this->settings['status_url2'];
			$this->logo_url             = $this->settings['logo_url'];
			$this->iframe               = $this->settings['iframe'] == 'yes' ? true : false;
			$this->dynamic_descriptor   = substr( $this->settings['dynamic_descriptor'], 0, 100 );
			$this->debug_mode           = isset( $this->settings['debug_mode'] ) ? $this->settings['debug_mode'] : self::DEBUG_MODE_OFF;

			$this->status_url           = trailingslashit( home_url() ) . '?wc-api=wc_gateway_skrill';

			add_action( 'woocommerce_receipt_skrill', array( $this, 'receipt' ) );
			add_action( 'woocommerce_api_wc_gateway_skrill', array( $this, 'ipn' ) );

			if ( is_admin() ) {
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options'));
			}
		}

		function init_form_fields() {
			$this->form_fields 	= array(
				'enabled' => array(
					'title'       => __( 'Enable Skrill', 'woocommerce-gateway-skrill' ),
					'label'       => __( 'Turn on Skrill for WooCommerce', 'woocommerce-gateway-skrill' ),
					'type'        => 'checkbox',
					'description' => '',
					'default'     => 'no'
				),
				'sandbox' => array(
					'title'       => __( 'Use Sandbox', 'woocommerce-gateway-skrill' ),
					'label'       => __( 'Use the sandbox for development', 'woocommerce-gateway-skrill' ),
					'type'        => 'checkbox',
					'description' => '',
					'default'     => 'no'
				),
				'merchant_id' => array(
					'title'       => __( 'Skrill Merchant ID', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Your Skrill merchant ID.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'pay_to_email' => array(
					'title'       => __( 'Skrill Email', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Your Skrill account email address.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'secret_word' => array(
					'title'       => __( 'Secret Word', 'woocommerce-gateway-skrill' ),
					'type'        => 'password',
					'description' => __( 'Secret word set on the merchant tools page of your account.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'status_url2' => array(
					'title'       => __( 'Status Emails', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Enter an email to receive status updates via email. Leave blank to disable.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'title' => array(
					'title'       => __( 'Title', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Payment method title that the customer will see on your website.', 'woocommerce-gateway-skrill' ),
					'default'     => __( 'Skrill', 'woocommerce-gateway-skrill' )
				),
				'description' => array(
					'title'       => __( 'Description', 'woocommerce-gateway-skrill' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your website.', 'woocommerce-gateway-skrill' ),
					'default'     => 'Pay with Skrill.'
				),
				'skrill_description' => array(
					'title'       => __( 'Description of Payment', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Description of the Merchant that will be passed to Skrill with the order information.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'iframe' => array(
					'title'       => __( 'IFrame', 'woocommerce-gateway-skrill' ),
					'label'       => __( 'Integrate Skrill using an iframe on the pay page istead of a form.', 'woocommerce-gateway-skrill' ),
					'type'        => 'checkbox',
					'description' => '',
					'default'     => 'no'
				),
				'dynamic_descriptor' => array(
					'title'       => __( 'Dynamic Descriptor', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Merchant name that shows up on your customers statement, up to 100 characters.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'instructions' => array(
					'title'       => __( 'Instructions', 'woocommerce-gateway-skrill' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions visitors will see on the receipt page to make payment.', 'woocommerce-gateway-skrill' ),
					'default'     => 'Click the button below to pay with Skrill.'
				),
				'logo_url' => array(
					'title'       => __( 'Logo URL', 'woocommerce-gateway-skrill' ),
					'type'        => 'text',
					'description' => __( 'Pass a logo URL to Skrill for use during the checkout process, 200px by 50px max. Leave blank to disable.', 'woocommerce-gateway-skrill' ),
					'default'     => ''
				),
				'debug_mode' => array(
					'title'       => __( 'Debug Mode', 'woocommerce-gateway-skrill' ),
					'type'        => 'select',
					'description' => sprintf( __( 'Show Detailed Error Messages and API requests/responses on the checkout page and/or save them to the debug log: %s', 'woocommerce-gateway-skrill' ), '<strong class="nobr">' . wc_get_log_file_path( $this->get_id() ) . '</strong>' ),
					'default'     => self::DEBUG_MODE_OFF,
					'options'     => array(
						self::DEBUG_MODE_OFF      => _x( 'Off', 'Debug mode off', 'woocommerce-gateway-skrill' ),
						self::DEBUG_MODE_LOG      => __( 'Save to Log', 'woocommerce-gateway-skrill' ),
					),
				),
			);
		}

		function payment_fields() { // Fields for the payment form
			if ( $this->description) { echo wpautop( $this->description); }
		}

		function receipt( $order) { // Receipt Page

			$order = wc_get_order( $order);
			echo wpautop( $this->instructions);

			if( ! $this->iframe ) {
				wc_enqueue_js( '
				jQuery("body").block({
						message: "<img src=\"' . esc_url( plugins_url( basename( dirname(__FILE__) ) . '/assets/images/ajax-loader.gif' ) ) . '\" alt=\"Redirecting…\" style=\"float:left; margin-right: 10px;\" />' . __( 'Thank you for your order. We are now redirecting you to Skrill to make payment.', 'woocommerce-gateway-skrill' ) . '",
						overlayCSS:
						{
							background: "#fff",
							opacity: 0.6
						},
						css: {
							padding:        20,
							textAlign:      "center",
							color:          "#555",
							border:         "3px solid #aaa",
							backgroundColor:"#fff",
							cursor:         "wait",
							lineHeight:     "32px"
						}
					});
				window.location = jQuery("#skrill_payment .button").attr( "href" );
				' );
			}

			echo '<div id="skrill_payment">';
				$this->form( $this->get_order_prop( $order, 'id' ), number_format( $order->get_total(), 2, '.', '' ), $this->get_order_prop( $order, 'billing_email' ) );
			echo '</div>';
		}

		// Process the payment
		function process_payment( $order_id ) {

			$order = wc_get_order( $order_id );

			WC()->cart->empty_cart(); // Dump the cart

			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( true ),
			);
		}


		function form( $order_id, $total, $from ) {

			$order = wc_get_order( $order_id );

			// keep track of the number of retries so we can generate unique order numbers for failed transactions as needed
			$retry_count = get_post_meta( $this->get_order_prop( $order, 'id' ), '_skrill_retry_count', true );

			if ( is_numeric( $retry_count ) ) {
				$retry_count++;
			} else {
				$retry_count = 0;
			}

			$args = array(
				'prepare_only'          => 1,                          // allows payment details to be first programmatically posted to the skrill server and a token returned (sid), which is included in the query string redirect
				'pay_to_email'          => $this->pay_to_email,
				'pay_from_email'        => $from,
				'firstname'             => $this->get_order_prop( $order, 'billing_first_name' ),
				'lastname'              => $this->get_order_prop( $order, 'billing_last_name' ),
				'address'               => $this->get_order_prop( $order, 'billing_address_1' ),
				'address2'              => $this->get_order_prop( $order, 'billing_address_2' ),
				'phone_number'          => preg_replace( '/\D/', '', $this->get_order_prop( $order, 'billing_phone' ) ),  // digits only, no spaces or dashes allowed
				'postal_code'           => $this->get_order_prop( $order, 'billing_postcode' ),
				'city'                  => $this->get_order_prop( $order, 'billing_city' ),
				'state'                 => $this->get_order_prop( $order, 'billing_state' ),
				'transaction_id'        => $this->get_order_number( $order, $retry_count ),
				'status_url'            => $this->status_url,    // IPN
				'status_url2'           => $this->status_url2,   // Email address to receive payment results
				'amount'                => $total,
				'currency'              => $this->get_order_prop( $order, 'currency' ),
				'recipient_description' => $this->skrill_description,
				'return_url'            => $this->get_return_url( $order ),
				'cancel_url'            => get_permalink( wc_get_page_id( 'myaccount' ) ),
				'merchant_fields'       => 'x_order_id,x_sha1hash',
				'x_order_id'            => $this->get_order_prop( $order, 'id' ),
			);

			$args['x_sha1hash'] = $this->get_sha1_hash( $args['x_order_id'] );

			if ( $this->debug_log() ) {
				$this->log( "Payment Request: " . print_r( $args, true ) );
			}

			update_post_meta( $this->get_order_prop( $order, 'id' ), '_skrill_retry_count', $retry_count );

			$response = wp_safe_remote_post( 'https://www.moneybookers.com/app/payment.pl', array( 'body' => $args, 'redirection' => 0 ) );

			$sid = wp_remote_retrieve_body( $response );

			// if the response body isn't an md5 hash then it's html error content (ie transaction id has already been processed)
			// Note that there's also a header 'x-skrill-status' which we might be able to use.  For a success request it looks like: :::::: for a failed: error::::ALREADY_PAID_FOR_GW::
			if ( strlen( $sid ) > 33 ) {
				if ( $this->debug_log() ) {
					$this->log( "Error Response: " . $sid );
				}

				return;
			}

			$endpoint = add_query_arg( 'sid', $sid, $this->endpoint );

			if( $this->iframe ) { ?>
				<iframe id="skrillpayframe" style="width:100%; min-width:600px; min-height:600px;" src="<?php echo esc_url( $endpoint ); ?>"></iframe>
			<?php } else { ?>
				<a class="button" href="<?php echo esc_url( $endpoint ); ?>"><?php _e( 'Pay with Skrill','woocommerce-gateway-skrill' ); ?></a>
			<?php }

		}

		function ipn() {

			if ( $this->debug_log() ) {
				$this->log( "IPN received: " . print_r( $_POST, true ) );
			}

			// first can we find the order?
			$order = wc_get_order( $_POST['x_order_id'] );

			if ( ! $order ) {
				if ( $this->debug_log() ) {
					$this->log( "[{$_POST['transaction_id']}] Order with id {$_POST['x_order_id']} not found" );
				}
				return;
			}

			// next validate the skrill signature
			$md5check = strtoupper( md5( $this->merchant_id . $_POST['transaction_id'] . strtoupper( md5( $this->secret_word ) ) . $_POST['mb_amount'] . $_POST['mb_currency'] . $_POST['status'] ) );

			if ( $md5check != $_POST['md5sig'] ) {
				$order->update_status( 'failed' );
				$order->add_order_note( __( 'Fraudulent MD5 Hash from Skrill', 'woocommerce-gateway-skrill' ) );

				if ( $this->debug_log() ) {
					$this->log( "[{$_POST['transaction_id']}] Fraudulent MD5 Hash from Skrill" );
				}

				return;
			}

			// finally validate our custom hash to verify the order id
			if ( empty( $_POST['x_sha1hash'] ) ) {
				if ( $this->debug_log() ) {
					$this->log( "[{$_POST['transaction_id']}] IPN error: missing required x_sha1hash" );
				}
				return;
			}

			if ( $_POST['x_sha1hash'] != $this->get_sha1_hash( $_POST['x_order_id'] ) ) {
				$order->update_status( 'failed' );
				$order->add_order_note( sprintf( __( "Order ID security check failed, possible fraudulent order attempt with Skrill transaction id %s", 'woocommerce-gateway-skrill' ), $_POST['transaction_id'] ) );

				if ( $this->debug_log() ) {
					$this->log( "[{$_POST['transaction_id']}] IPN error: x_sha1hash mismatch, potential fraudulent order attempt?" );
				}

				return;
			}

			if ( ! $order->has_status( array( 'pending', 'on-hold' ) ) ) {
				return;
			}

			if ( $_POST['status'] == '2' ) {
				$order->add_order_note( $this->title . ' ' . __( 'payment received.', 'woocommerce-gateway-skrill' ) , 1 );
				$order->add_order_note( sprintf( __( 'Skrill Payor Email: %s', 'woocommerce-gateway-skrill' ), $_POST['pay_from_email'] ) );
				$order->add_order_note( sprintf( __( 'Skrill Transaction ID: %s', 'woocommerce-gateway-skrill' ), $_POST['mb_transaction_id'] ) );
				$order->payment_complete();
			} elseif ( $_POST['status'] == '0' ) {
				$order->update_status( 'on-hold' );
				$order->add_order_note( sprintf( __( '%s payment pending.', 'woocommerce-gateway-skrill' ), $this->title ) );
			} elseif ( $_POST['status'] == '-1' ) {
				$order->update_status( 'cancelled' );
				$order->add_order_note( sprintf( __( '%s payment cancelled.', 'woocommerce-gateway-skrill' ), $this->title ) );
			} elseif ( $_POST['status'] == '-2' ) {
				$order->update_status( 'failed' );
				$order->add_order_note( sprintf( __( '%s payment failed.', 'woocommerce-gateway-skrill' ), $this->title ) );
			} elseif ( $_POST['status'] == '-3' ) {
				$order->update_status( 'refunded' );
				$order->add_order_note( sprintf( __( '%s chargeback received.', 'woocommerce-gateway-skrill' ), $this->title ) );
			} else {
				$order->add_order_note( sprintf( __( 'Unrecognized Skrill IPN status received: %s', 'woocommerce-gateway-skrill' ), $_POST['status'] ) );
				$order->add_order_note( sprintf( __( 'Skrill Payor Email: %s', 'woocommerce-gateway-skrill' ), $_POST['pay_from_email'] ) );
				$order->add_order_note( sprintf( __( 'Skrill Transaction ID: %s', 'woocommerce-gateway-skrill' ), $_POST['mb_transaction_id'] ) );
			}
		}


		/**
		 * Get the skrill order number for the given order.  This will be the
		 * order number (without leading hash) and any retry suffix, to ensure
		 * the order number is unique when handling failed transactions
		 *
		 * @since 1.2
		 * @param WC_Order $order the order object
		 * @param int $retry_count optional retry count value
		 * @return string
		 */
		private function get_order_number( $order, $retry_count = null ) {

			// get the existing retry count (if any)
			if ( is_null( $retry_count ) ) {
				$retry_count = get_post_meta( $this->get_order_prop( $order, 'id' ), '_skrill_retry_count', true );
			}
			$retry_order_number_suffix = '';

			if ( $retry_count ) {
				$retry_order_number_suffix = apply_filters( 'wc_skrill_order_number_suffix', '-' . $retry_count, $this->get_order_prop( $order, 'id' ) );
			}

			return preg_replace( '/[^0-9]/', '', $order->get_order_number() ) . $retry_order_number_suffix;
		}


		/**
		 * Gets an order property.
		 *
		 * This method exists for WC 3.0+ compatibility.
		 *
		 * @since 1.7.0
		 * @param \WC_Order $order the order object
		 * @param string $prop the property to get
		 * @return mixed the property value
		 */
		private function get_order_prop( WC_Order $order, $prop ) {

			$wc_version = defined( 'WC_VERSION' ) && WC_VERSION ? WC_VERSION : null;

			if ( $wc_version && version_compare( $wc_version, '3.0', '>=' ) && is_callable( array( $order, "get_{$prop}" ) ) ) {

				$value = $order->{"get_{$prop}"}( 'edit' );

			} else {

				if ( 'currency' === $prop ) {
					$value = $order->get_order_currency();
				} else {
					$value = $order->$prop;
				}
			}

			return $value;
		}


		/**
		 * Returns the plugin gateway id
		 *
		 * @since 1.2.2
		 * @return string plugin gateway id
		 */
		public function get_id() {
			return $this->id;
		}


		/**
		 * Returns true if all debugging is disabled
		 *
		 * @since 1.2.2
		 * @return boolean if all debuging is disabled
		 */
		public function debug_off() {
			return self::DEBUG_MODE_OFF === $this->debug_mode;
		}


		/**
		 * Returns true if debug logging is enabled
		 *
		 * @since 1.2.2
		 * @return boolean if debug logging is enabled
		 */
		public function debug_log() {
			return self::DEBUG_MODE_LOG === $this->debug_mode;
		}


		/**
		 * Saves errors or messages to WooCommerce Log (woocommerce/logs/plugin-id-xxx.txt)
		 *
		 * @since 1.2.2
		 * @param string $message error or message to save to log
		 * @param string $log_id optional log id to segment the files by, defaults to plugin id
		 */
		public function log( $message, $log_id = null ) {

			if ( is_null( $log_id ) ) {
				$log_id = $this->get_id();
			}

			if ( ! is_object( $this->logger ) ) {
				$this->logger = new WC_Logger();
			}

			$this->logger->add( $log_id, $message );

		}


		/**
		 * Returns the sha1 hash for the provided arguments.  This function takes
		 * a variable list of arguments and returns the hash of them
		 *
		 * @since 1.2.2
		 * @param mixed ...
		 * @return string sha1 hash
		 */
		private function get_sha1_hash() {
			$args = func_get_args();  // assign func_get_args() to avoid a Fatal error in some instances
			return sha1( sha1( implode( '.', $args ) ) . '.' . $this->secret_word );
		}

	}

	// Adding Gateway to WooCommerce Gateways
	function woocommerce_skrill_add_gateway( $methods ) {
		$methods[] = 'WC_Gateway_Skrill';
		return $methods;
	}
	add_filter ( 'woocommerce_payment_gateways', 'woocommerce_skrill_add_gateway' );

}
