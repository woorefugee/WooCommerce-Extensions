=== WooCommerce Photography ===
Author: WooThemes
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.0.10

== Description ==

This WooCommerce extension gets you set up to sell photos in the blink of an eye and makes creating products your fans and clients can buy as simple as dragging & dropping images!

See http://docs.woothemes.com/documentation/woocommerce-extensions/photography/ for full documentation.
