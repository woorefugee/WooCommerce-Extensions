<?php
/**
 * Plugin Name: WooCommerce Mad Mimi integration
 * Description: WooCommerce Integration with the Mad Mimi email marketing service
 * Version: 1.2.1
 * Author: WooThemes
 * Author URI: http://www.woothemes.com
 * Requires at least: 3.3
 * Tested up to: 3.9.1
 *
 * Copyright: © 2009-2011 WooThemes.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), 'ba202c810b3e8066a35394a809b84c6a', '127483' );

if ( ! class_exists( 'WC_Mad_Mimi' ) ) :

/**
 * main class.
 *
 * @package  WC_Mad_Mimi
 */
class WooCommerce_Mad_Mimi {
	/**
	 * init
	 *
	 * @access public
	 * @since 1.2.0
	 * @return bool
	 */
	function __construct() {

		include_once( 'classes/MadMimi.class.php' );

		$mimi_settings = get_option( 'woocommerce_madmimi_settings' );

		if ( $mimi_settings ) {
			$username = $mimi_settings[ 'mimi_username' ];
			$apikey = $mimi_settings[ 'mimi_apikey' ];
			$debug = false;

			$mimi = new MadMimi( $username, $apikey, $debug );

			include( 'classes/class-wc-mad-mimi-function.php' );

			new WC_Mad_Mimi_Function( $mimi, $mimi_settings );
		}

		if ( is_admin() ) {
			add_filter( 'woocommerce_integrations', array( $this, 'madmimi_add_integration' ) );
		}

		return true;
	}

	/**
	 * add Mad Mimi integration.
	 *
	 * @since 1.2.0
	 * @return array $integrations
	 */
	public function madmimi_add_integration() {
		include( 'classes/class-wc-mad-mimi-admin.php' );

		$integrations[] = 'WC_Mad_Mimi_Admin';

		return $integrations;
	}

	/**
	 * load the plugin text domain for translation.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	public function load_plugin_textdomain() {
		$locale = apply_filters( 'wc_mad_mimi_plugin_locale', get_locale(), 'woocommerce-mad-mimi' );

		load_textdomain( 'woocommerce-mad-mimi', trailingslashit( WP_LANG_DIR ) . 'woocommerce-mad-mimi' . '/' . 'woocommerce-mad-mimi' . '-' . $locale . '.mo' );

		load_plugin_textdomain( 'woocommerce-mad-mimi', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

		return true;
	}

	/**
	 * WooCommerce fallback notice.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public function woocommerce_missing_notice() {
		echo '<div class="error"><p>' . sprintf( __( 'WooCommerce Mad Mimi Plugin requires WooCommerce to be installed and active.', 'woocommerce-mad-mimi' ), '<a href="http://www.woothemes.com/woocommerce/" target="_blank">WooCommerce</a>' ) . '</p></div>';

		return true;
	}
}

add_action( 'plugins_loaded', 'woocommerce_mad_mimi_init', 0 );

/**
 * init function
 *
 * @package  WooCommerce_Mad_Mimi
 * @since 1.2.0
 * @return bool
 */
function woocommerce_mad_mimi_init() {
	new WooCommerce_Mad_Mimi();

	return true;
}

endif;
