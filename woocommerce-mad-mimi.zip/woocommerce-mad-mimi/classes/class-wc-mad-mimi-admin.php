<?php
/**
 * Mad Mimi integration class
 *
 * @version 1.2.0
 * @category Plugins
 * @package WordPress
 * @subpackage WooFramework
 * @author WooThemes
 * @since 1.0.0
 *
 * TABLE OF CONTENTS
 *
 * - var $plugin_id
 * - var $settings
 * - var $form_fields
 * - var $errors
 * - var $sanitized_fields
 * - var $id
 * - var $method_title
 * - var $method_description
 *
 * - Constructor()
 * - init_form_fields()
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WC_Mad_Mimi_Admin' ) ) :

class WC_Mad_Mimi_Admin extends WC_Integration {

	var $plugin_id = 'woocommerce_';
	var $settings = array();
	var $form_fields = array();
	var $errors = array();
	var $sanitized_fields = array();
	var $id;
	var $method_title;
	var $method_description;

	public function __construct() {
        $this->id                   = 'madmimi';
        $this->method_title         = __( 'Mad Mimi', 'woocommerce-mad-mimi' );
        $this->method_description   = __( 'Mad Mimi is an email newsletter service.', 'woocommerce-mad-mimi' );
		
		// Load the form fields.
		$this->init_form_fields();
		
		// Load the settings.
		$this->init_settings();

		// Define user set variables
		$this->mimi_enable         = $this->settings['mimi_enable'];
		$this->mimi_username       = $this->settings['mimi_username'];
		$this->mimi_apikey         = $this->settings['mimi_apikey'];
		$this->mimi_purchase_promo = $this->settings['mimi_purchase_promo'];
		
		// Actions
		add_action( 'woocommerce_update_options_integration_madmimi', array( &$this, 'process_admin_options' ) );
    }

    /**
     * Initialise Settings Form Fields
     */
    function init_form_fields() {
    
    	$this->form_fields = array(
    		'mimi_enable' => array(  
				'title'         => __( 'Enable/Disable:', 'woocommerce-mad-mimi' ),
				'label'         => __( 'Enable Mad Mimi integration', 'woocommerce-mad-mimi' ),
				'type'          => 'checkbox',
				'checkboxgroup' => 'enable',
				'default'       => get_option( 'woocommerce_mimi_enable' ) ? get_option( 'woocommerce_mimi_enable' ) : 'no'  // Backwards compat
			),
    		'mimi_username' => array(  
				'title'       => __( 'Mad Mimi Username:', 'woocommerce-mad-mimi' ),
				'description' => __( 'Your Mad Mimi account username.', 'woocommerce-mad-mimi' ),
				'type'        => 'text',
				'default'     => '' // Backwards compat
			),
			'mimi_apikey' => array(  
				'title'       => __( 'Mad Mimi API Key:', 'woocommerce-mad-mimi' ),
				'description' => __( 'Log into your Mad Mimi account to find your API key.', 'woocommerce-mad-mimi' ),
				'type'        => 'text',
				'default'     => '' // Backwards compat
			),
			'mimi_purchase_promo' => array(  
				'title'       => __( 'Order promotion:', 'woocommerce-mad-mimi' ),
				'description' => __( 'The full name of the promotion email that you would like to send to your users when they make a purchase through your store (leave blank to disable).', 'woocommerce-mad-mimi' ),
				'type'        => 'text',
				'default'     => '' // Backwards compat
			),
			'mimi_purchase_promo_new_users' => array(  
				'title'         => __( 'Only send promotion to new users:', 'woocommerce-mad-mimi' ),
				'label'         => __( 'Check this box to only send the promotion email to users who are not already signed up for any of your mailing lists (will only be sent if the "Order promotion" option has a value).', 'woocommerce-mad-mimi' ),
				'type'          => 'checkbox',
				'checkboxgroup' => 'promo_new_send',
				'default'       => get_option( 'woocommerce_mimi_purchase_promo_new_users' ) ? get_option( 'woocommerce_mimi_purchase_promo_new_users' ) : 'no'  // Backwards compat
			),
			'mimi_customer_list' => array(  
				'title'       => __( 'Customer mailing list:', 'woocommerce-mad-mimi' ),
				'description' => __( 'Enter the mailing list name you want customers to be subscribed to by default. Separate each mailing list name by a comma. Leave the field blank to disable.', 'woocommerce-mad-mimi' ),
				'type'        => 'text',
				'default'     => ''
			),
			'mimi_add_on_purchase' => array(  
				'title'         => __( 'Add new users to product mailing lists on purchase:', 'woocommerce-mad-mimi' ),
				'label'         => __( 'This will create a mailing list for each of your products - it will add users to the maililng lists for the products that they purchase. If a list does not exist when a user is added to it then the list will be created.', 'woocommerce-mad-mimi' ),
				'type'          => 'checkbox',
				'checkboxgroup' => 'add_on_purchase',
				'default'       => get_option( 'woocommerce_mimi_add_on_purchase' ) ? get_option( 'woocommerce_mimi_add_on_purchase' ) : 'no'  // Backwards compat
			),
			'mimi_allow_optout' => array(  
				'title'         => __( 'Allow users to opt-out of list sign up on checkout:', 'woocommerce-mad-mimi' ),
				'label'         => __( 'This will allow users to select whether or not they will be automatically signed up for your mailing lists or not as they check out - this applies to the customer mailing list specified above as well as the individual product mailing lists.', 'woocommerce-mad-mimi' ),
				'type'          => 'checkbox',
				'checkboxgroup' => 'allow_optout',
				'default'       => get_option( 'woocommerce_mimi_allow_optout' ) ? get_option( 'woocommerce_mimi_allow_optout' ) : 'no'  // Backwards compat
			),
		);
		
    } // End init_form_fields()	    
}
endif;