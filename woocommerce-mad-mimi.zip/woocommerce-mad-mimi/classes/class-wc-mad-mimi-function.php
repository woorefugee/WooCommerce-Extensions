<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * WooCommerce Mad Mimi class
 * Functions to handle Mad Mimi functionality inside WooCommerce
 */
class WC_Mad_Mimi_Function {
	protected $mimi;
	protected $mimi_settings;

	/**
	 * init
	 *
	 * @access public
	 * @since 1.2.0
	 * @return bool
	 */
	function __construct( $mimi = '', $mimi_settings = array() ) {
		$this->mimi = $mimi;
		$this->mimi_settings = $mimi_settings;

		// Add hooks if extension is enabled
		if ( $mimi_settings['mimi_enable'] && $mimi_settings['mimi_enable'] === 'yes' ) {

			// Add newsletter input fields to checkout page
			add_action( 'woocommerce_review_order_before_submit', array( $this, 'order_newsletter_fields' ) );

			// update checkout order field options
			add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'order_newsletter_fields_update' ), 30, 1 );

			// send on different order statuses
			add_action( 'woocommerce_order_status_processing', array( $this, 'order_newsletter_send' ), 30, 1 );
			add_action( 'woocommerce_order_status_completed', array( $this, 'order_newsletter_send' ), 30, 1 );
			add_action( 'woocommerce_order_status_pending_to_on-hold', array( $this, 'order_newsletter_send' ), 30, 1 );

			// Register shortcode for newsletter subsciption options
			add_shortcode( 'mad_mimi_newsletter_subscriptions' , array( $this, 'newsletter_subscriptions_shortcode' ) );
			add_shortcode( 'newsletter_subscriptions' , array( $this, 'newsletter_subscriptions_shortcode' ) );  // deprecated
		}

		return true;
	}

	/**
	 * Add specified user to mailing list
	 * @param int $order_id id of the order
	 * @param str $list    	Full name of mailing list
	 * @return void
	 */
	public function add_user_to_list_from_order( $order_id = false, $list = false ) {

		if ( $order_id && $list ) {

			$email = $this->get_email_from_order( $order_id );
			$first_name = $this->get_first_name_from_order( $order_id );
			$last_name = $this->get_last_name_from_order( $order_id );

			if ( $email ) {

				$data = array(
					'email' => $email,
					'firstName' => $first_name,
					'lastName' => $last_name,
					'add_list' => $list
				);

				$this->mimi->AddUser( $data );

				return true;

			}

		}

		return false;
	}

	/**
	 * Add specified user to mailing list
	 * @param int $user_id id of the current user
	 * @param str $list    	Full name of mailing list
	 * @return void
	 */
	public function add_user_to_list( $user_id = false, $list = false ) {

		if ( $user_id && $list ) {
			$email = get_user_meta( $user_id, 'billing_email', true );
			$first_name = get_user_meta( $user_id, 'billing_first_name', true );
			$last_name = get_user_meta( $user_id, 'billing_last_name', true );

			if ( $email ) {

				$data = array(
					'email' => $email,
					'firstName' => $first_name,
					'lastName' => $last_name,
					'add_list' => $list
				);

				$this->mimi->AddUser( $data );

				return true;

			}

		}

		return false;
	}

	/**
	 * Get user id
	 *
	 * @since 1.2.0
	 * @param int $order_id
	 * @return string $user_id
	 */
	public function get_user_id_from_order( $order_id = 0 ) {
		$user_id = get_post_meta( $order_id, '_customer_user', true );

		// logged in customer
		if ( $user_id ) {
			return absint( $user_id );
		} else {
			return '0';
		}
		
	}

	/**
	 * Get customer email
	 *
	 * @since 1.2.0
	 * @param int $order_id
	 * @return string $email
	 */
	public function get_email_from_order( $order_id = 0 ) {
		if ( 0 === $order_id ) {
			return;
		}

		$user_id = $this->get_user_id_from_order( $order_id );

		// guest checkout
		if ( '0' === $user_id ) {
			$email = get_post_meta( $order_id, '_billing_email', true );
		} else {
			$email = get_user_meta( $user_id, 'billing_email', true );
			
			if ( ! $email || strlen( $email ) === 0 ) {
				$user = get_userdata( $user_id );

				$email = $user->user_email;
			}
		}

		return $email;
	}

	/**
	 * Get customer first name
	 *
	 * @since 1.2.0
	 * @param int $order_id
	 * @return string $first_name
	 */
	public function get_first_name_from_order( $order_id = 0 ) {
		if ( 0 === $order_id ) {
			return;
		}

		$user_id = $this->get_user_id_from_order( $order_id );

		// guest checkout
		if ( '0' === $user_id ) {
			$first_name = get_post_meta( $order_id, '_billing_first_name', true );
		} else {
			$first_name = get_user_meta( $user_id, 'billing_first_name', true );
			if ( ! $first_name || strlen( $first_name ) == 0  ) {
				$user = get_userdata( $user_id );

				$first_name = $user->first_name;
			}
		}

		return $first_name;
	}

	/**
	 * Get customer last name
	 *
	 * @since 1.2.0
	 * @param int $order_id
	 * @return string $last_name
	 */
	public function get_last_name_from_order( $order_id = 0 ) {
		if ( 0 === $order_id ) {
			return;
		}

		$user_id = $this->get_user_id_from_order( $order_id );

		// guest checkout
		if ( '0' === $user_id ) {
			$last_name = get_post_meta( $order_id, '_billing_last_name', true );
		} else {
			$last_name = get_user_meta( $user_id, 'billing_last_name', true );

			if ( ! $last_name || strlen( $last_name ) === 0  ) {
				$user = get_userdata( $user_id );

				$last_name = $user->last_name;
			}
		}

		return $last_name;
	}

	/**
	 * Remove specified user from list
	 * @param  int $user_id 	ID of user to be removed
	 * @param  str $list    	Full name of mailing list
	 * @return boolean			True on success, false on failure
	 */
	public function remove_user_from_list( $user_id = false, $list = false ) {

		if ( $user_id && $list ) {

			$email = get_user_meta( $user_id, 'billing_email', true );

			if ( ! $email || strlen( $email ) === 0 ) {
				$user = get_userdata( $user_id );
				$email = $user->user_email;
			}

			if ( $email && $email != '' ) {

				$this->mimi->RemoveUser( $email, $list );

				return true;
			}

		}

		return false;

	}

	/**
	 * Remove specified user from all mailing lists
	 * @param  int $user_id 	ID of user to be removed
	 * @return boolean          True on success, false on failure
	 */
	public function remove_user_from_all_lists( $user_id = false ) {

		if ( $user_id ) {

			$email = get_user_meta( $user_id, 'billing_email', true );

			if ( ! $email || strlen( $email ) === 0 ) {
				$user = get_userdata( $user_id );
				$email = $user->user_email;
			}

			if ( $email && $email != '' ) {

				$this->mimi->RemoveUserFromAllLists( $email );

				return true;
			}

		}

		return false;

	}

	/**
	 * Get all lists to which specified user is subscribed
	 * @param  int $user_id 	ID of user
	 * @return mixed          	Array on success, boolean false on failure
	 */
	public function get_user_lists( $user_id ) {

		if ( $user_id ) {

			$email = get_user_meta( $user_id, 'billing_email', true );

			if ( ! $email || strlen( $email ) == 0 ) {
				$user = get_userdata( $user_id );
				$email = $user->user_email;
			}

			$lists = simplexml_load_string( $this->mimi->Memberships( $email ) );

			$result = false;

			foreach ( $lists as $list ) {

				if ( $list->attributes()->name && $list->attributes()->id ) {

					$id = $list->attributes()->id;
					$name = $list->attributes()->name;

					$result[] = array(
						'id' => $id,
						'name' => $name,
					);

				}

			}

			return $result;
		}

		return false;
	}

	/**
	 * Get all mailing lists from Mad Mimi account
	 * @return array Array of mailing lists
	 */
	public function get_all_lists() {

		$lists = simplexml_load_string( $this->mimi->Lists() );

		$result = false;

		foreach ( $lists as $list ) {

			if ( $list->attributes()->name && $list->attributes()->id ) {

				$id = $list->attributes()->id;
				$name = $list->attributes()->name;

				$result[] = array(
					'id' => $id,
					'name' => $name,
				);

			}

		}

		// Sort lists by list name
		usort( $result, array( $this, 'cmp_array' ) );

		return $result;
	}

	/**
	 * Create mailling list in Mad Mimi
	 * @param str $list Name of list to be created
	 * @return mixed 	Array on success, boolean false on failure
	 */
	public function add_list( $list = false ) {

		if ( $list ) {

			$newlist = json_decode( $this->mimi->NewList( $list ) );

			if ( $newlist->success === 1 ) {

				$result = array(
					'id' => $newlist->result->id,
					'name' => $newlist->result->name
				);

				return $result;
			}
		}

		return false;
	}

	/**
	 * Send specified promotion to user
	 * @param  int $order_id   id of the order
	 * @param  str $promotion Full name of promotion
	 * @return void
	 */
	public function send_promotion_to_user( $order_id = false, $promotion = false ) {

		if ( $promotion ) {

			$email = $this->get_email_from_order( $order_id );

			$first_name = $this->get_first_name_from_order( $order_id );

			$last_name = $this->get_last_name_from_order( $order_id );

			if ( $email ) {

				$from_name 		= get_option( 'woocommerce_email_from_name' );
				$from_address	= get_option( 'woocommerce_email_from_address' );

				$data = array(
					'promotion_name' => $promotion,
					'recipients' => $first_name . ' ' . $last_name . ' <' . $email , '>',
					'from' => $from_name . ' <' . $from_address . '>'
				);

				$this->mimi->sendPromotion( $data );

			}

		}

	}

	/**
	 * Check if specified user exists in Mad Mimi database
	 * @param  int $order_id 	ID of the order
	 * @return boolean          True if user exists, false if not
	 */
	public function user_exists( $order_id = 0 ) {
		if ( 0 === $order_id ) {
			return true;
		}

		$email = $this->get_email_from_order( $order_id );

		if ( $email ) {

			$response = $this->mimi->SearchForUser( $email, true );

			$xml = simplexml_load_string( $response );

			if ( $xml === false ) {
				return false;
			} else {
				$user_email = (string) $xml->member->email;
				if ( $user_email && strlen( $user_email ) > 0 ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Provide options for users to manage their mailing list subscriptions
	 * Can be access via shortcode: [mad_mimi_newsletter_subscriptions]
	 * @return void
	 */
	public function newsletter_subscriptions_shortcode() {
		global $current_user;

		// Get current user ID for API calls
		wp_get_current_user();
		$user_id = $current_user->ID;

		// bail if not logged in
		if ( 0 === $user_id ) {
			return;
		}

		$msg = false;

		// Handle submitted form
		if ( isset( $_POST['mad_mimi_manage_subs_nonce'] ) && wp_verify_nonce( $_POST['mad_mimi_manage_subs_nonce'], 'mad_mimi_manage_subs' ) ) {
			$chosen_lists = array();

			// Remove user from all lists before adding to selected ones
			$this->remove_user_from_all_lists( $user_id );

			if ( isset( $_POST['lists'] ) && is_array( $_POST['lists'] ) ) {
				// sanitize
				$lists = array_map( 'sanitize_text_field', $_POST['lists'] );

				// Add user to all selected lists
				foreach ( $lists as $list ) {
					$this->add_user_to_list( $user_id, $list );

					$chosen_lists[] = $list;
				}
			}

			$msg = true;
		} else {

			// Get user subscribed lists
			$user_lists = $this->get_user_lists( $user_id );

			if ( is_array( $user_lists ) && count( $user_lists ) > 0 ) {
				foreach( $user_lists as $list ) {
					$id = (string) $list['id'];
					$name = (string) $list['name'];
					$chosen_lists[ $id ] = $name;
				}
			} else {
				$chosen_lists = array();
			}
		}

		// Get products purchased by user
		$lists = $this->get_all_lists();
				
		// Display user lists as checkboxes
		$html = '';

		$html .= '<h5>' . __( 'Manage My Newsletter Subscriptions', 'woocommerce-mad-mimi' ) . '</h5>' . PHP_EOL;
		$html .= '<form id="mad_mimi_email_subs" name="mad_mimi_email_subs" action="#" method="post">' . PHP_EOL;
		$html .= '<a href="#" class="mad-mimi-select-all">' . __( 'Select All', 'woocommerce-mad-mimi' ) . '</a>' . PHP_EOL;
		$html .= '<ul class="mad_mimi_newsletter_options">' . PHP_EOL;

		foreach ( $lists as $list ) {

			$name = $list['name'];
			$id = $list['id'];

			$checked = '';

			if ( in_array( $name, $chosen_lists ) ) {
				$checked = 'checked="checked"';
			}

			$html .= '<li>' . PHP_EOL;
			
			$html .= '<input type="checkbox" name="lists[' . esc_attr( $id ) . ']" id="list_' . esc_attr( $id ) . '" value="' . esc_attr( $name ) . '" ' . $checked . ' />' . PHP_EOL;
			$html .= '<label for="list_' . esc_attr( $id ) . '">' . $name . '</label>' . PHP_EOL;
			
			$html .= '</li>' . PHP_EOL;

		}

		$html .= '</ul>' . PHP_EOL;
		
		$html .= wp_nonce_field( 'mad_mimi_manage_subs', 'mad_mimi_manage_subs_nonce', true, false ) . PHP_EOL;

		$html .= '<input type="submit" value="' . esc_attr__( 'Save Settings', 'woocommerce-mad-mimi' ) . '" />' . PHP_EOL;
		
		$html .= '</form>' . PHP_EOL;

		// show saved message
		if ( $msg ) {
			$html .= '<div class="woocommerce-mad-mimi-saved" style="margin:5px 0;padding:5px 10px;border:1px solid #ddd;">' . __( 'Settings Saved', 'woocommerce-mad-mimi' ) . '</div>' . PHP_EOL;
		}

		$html .= "<script>
	  		jQuery( function () {
			    jQuery( 'a.mad-mimi-select-all' ).click( function ( e ) {
			    	e.preventDefault();
			        jQuery( this ).parents( 'form#mad_mimi_email_subs' ).eq( 0 ).find( ':checkbox' ).prop( 'checked', 'checked' );
			    });
			});
			</script>";

		return $html;
	}

	/**
	 * Add hidden input fields to checkout page for each relevant list
	 * @return void
	 */
	public function order_newsletter_fields() {

		$html = '';

		// general mailing list
		if ( $this->mimi_settings['mimi_customer_list'] && strlen( trim( $this->mimi_settings['mimi_customer_list'] ) ) > 0 ) {
			$lists = explode( ',', $this->mimi_settings['mimi_customer_list'] );

			if ( $this->mimi_settings['mimi_allow_optout'] && $this->mimi_settings['mimi_allow_optout'] === 'yes' ) {
				$i = 0;

				$html .= '<strong>' . __( 'Newsletter Sign Up!', 'woocommerce-mad-mimi' ) . '</strong>' . PHP_EOL;

				foreach( $lists as $list ) {
					$html .= '<label for="list_' . esc_attr( $i ) . '"><input style="float:none;" type="checkbox" name="lists[' . esc_attr( $i ) . ']" id="list_' . esc_attr( $i ) . '" value="' . trim( $list ) . '" checked="checked" /> ' . trim( $list ) . '</label>' . PHP_EOL;

					$i++;
				}
			} else {
				$i = 0;

				foreach( $lists as $list ) {
					$html .= '<input type="hidden" name="lists[' . esc_attr( $i ) . ']" id="list_' . esc_attr( $i ) . '" value="' . trim( $list ) . '" />';

					$i++;
				}
			}
		}

		// mailing list for product
		if ( $this->mimi_settings['mimi_add_on_purchase'] && $this->mimi_settings['mimi_add_on_purchase'] === 'yes' ) {

			$cart = WC()->cart->cart_contents;

			foreach ( $cart as $item ) {

				if ( $item['product_id'] ) {
					$id = $item['product_id'];
					$prod_name = get_the_title( $id );
					$products[ $id ] = $prod_name;
				}

			}

			foreach ( $products as $id => $name ) {
				if ( $this->mimi_settings['mimi_allow_optout'] && $this->mimi_settings['mimi_allow_optout'] === 'yes' ) {
					$html .= '<label for="list_' . $id . '"><input style="float:none;" type="checkbox" name="lists[' . $id . ']" id="list_' . $id . '" value="' . $name . '" checked="checked" /> ' . $name . '</label>';
				} else {
					$html .= '<input type="hidden" name="lists[' . $id . ']" id="list_' . $id . '" value="' . $name . '" />';
				}
			}

		}

		echo $html;

		return true;
	}

	/**
	 * Add specified mailing lists to order meta
	 * @param  int $order_id ID of order
	 * @return void
	 */
	public function order_newsletter_fields_update( $order_id ) {

		if ( ! isset( $order_id ) ) {
			return;
		}

		if ( isset( $_POST['lists'] ) && is_array( $_POST['lists'] ) ) {
			// sanitize
			$lists = array_map( 'sanitize_text_field', $_POST['lists'] );

			update_post_meta( $order_id, '_mad_mimi_newsletter_lists', $lists );
		}

		return true;
	}

	/**
	 * Process specified lists using add_user_to_list()
	 * @param  int 	$order_id ID of order
	 * @return void
	 */
	public function order_newsletter_send( $order_id ) {

		$lists = get_post_meta( $order_id, '_mad_mimi_newsletter_lists', true );
		$sent = get_post_meta( $order_id, '_mad_mimi_sent', true );

		// if already sent don't send again
		if ( isset( $sent ) && $sent === 'yes' ) {
			return;
		}

		if ( $lists && is_array( $lists ) && count( $lists ) > 0 ) {

			if ( $order_id ) {

				foreach ( $lists as $id => $name ) {
					if ( $name && $name != '' ) {
						$this->add_user_to_list_from_order( $order_id, $name );
					}
				}

			}

		}

		if ( $this->mimi_settings['mimi_purchase_promo'] && strlen( trim( $this->mimi_settings['mimi_purchase_promo'] ) ) > 0 ) {

			$send_promo = true;

			// only send to new users so check - don't send if user already exists
			if ( $this->mimi_settings['mimi_purchase_promo_new_users'] && $this->mimi_settings['mimi_purchase_promo_new_users'] === 'yes' ) {
				$send_promo = $this->user_exists( $order_id ) ? false : true;
			}

			if ( $send_promo ) {
				$promo = trim( $this->mimi_settings['mimi_purchase_promo'] );

				$this->send_promotion_to_user( $order_id, $promo );

			}

		}

		// flag this order email has been sent
		update_post_meta( $order_id, '_mad_mimi_sent', 'yes' );

		return true;
	}

	/**
	 * Function to sort list by name
	 * @param array $a
	 * @param array $b
	 * @return void
	 */
	public function cmp_array( $a, $b ) {
		if ( isset( $a ) && isset( $b ) ) {
			return strcmp( $a['name'], $b['name'] );
		}

		return '';
	}

}