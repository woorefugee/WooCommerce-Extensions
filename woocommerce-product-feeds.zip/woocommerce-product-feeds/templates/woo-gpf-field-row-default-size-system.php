<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="">{emptytext}</option>
	<option value="US" {US-selected}><?php _e( 'US Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="UK" {UK-selected}><?php _e( 'UK Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="EU" {EU-selected}><?php _e( 'European Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="AU" {AU-selected}><?php _e( 'Australian Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="BR" {BR-selected}><?php _e( 'Brazilian Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="CN" {CN-selected}><?php _e( 'Chinese Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="FR" {FR-selected}><?php _e( 'French Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="DE" {DE-selected}><?php _e( 'German Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="IT" {IT-selected}><?php _e( 'Italian Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="JP" {JP-selected}><?php _e( 'Japanese Sizing', 'woocommerce_gpf' ); ?></option>
	<option value="MEX" {MEX-selected}><?php _e( 'Mexican Sizing', 'woocommerce_gpf' ); ?></option>
</select>