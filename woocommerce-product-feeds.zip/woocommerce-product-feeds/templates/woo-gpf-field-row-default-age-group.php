<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="">{emptytext}</option>
	<option value="newborn" {newborn-selected}><?php _e( 'Newborn', 'woocommerce_gpf' ); ?></option>
	<option value="infant" {infant-selected}><?php _e( 'Infant', 'woocommerce_gpf' ); ?></option>
	<option value="toddler" {toddler-selected}><?php _e( 'Toddler', 'woocommerce_gpf' ); ?></option>
	<option value="kids" {kids-selected}><?php _e( 'Children', 'woocommerce_gpf' ); ?></option>
	<option value="adult" {adult-selected}><?php _e( 'Adults', 'woocommerce_gpf' ); ?></option>
</select>
