	<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
		<option value="">{emptytext}</option>
		<option value="yes" {yes-selected}><?php _e( 'Yes', 'woocommerce_gpf' ); ?></option>
		<option value="no" {no-selected}><?php _e( 'No', 'woocommerce_gpf' ); ?></option>
	</select>
