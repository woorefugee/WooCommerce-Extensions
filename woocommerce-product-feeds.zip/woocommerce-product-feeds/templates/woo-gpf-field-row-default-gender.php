	<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
		<option value="">{emptytext}</option>
		<option value="male" {male-selected}><?php _e( 'Male', 'woocommerce_gpf' ); ?></option>
		<option value="female" {female-selected}><?php _e( 'Female', 'woocommerce_gpf' ); ?></option>
		<option value="unisex" {unisex-selected}><?php _e( 'Unisex', 'woocommerce_gpf' ); ?></option>
	</select>
