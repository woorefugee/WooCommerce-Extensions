WP Conditions is a framework developed by Jeroen Sormani <info@jeroensormani.com>
It is intended to be used on plugins like build by Jeroen such as Advanced Shipping, Advanced Fees etc.

Copyright © 2017 Jeroen Sormani


# Current version: 1.0.2

# Changelog

= 1.0.2 - 28/04/2017 =

- [Add] - Volume condition
- [Add] - Support for 'Guest' users in the 'User role' condition
- [Fix] - Use 9 length IDs for new fields - prevents too big numbers for 32-bits systems.


= 1.0.1 =

- [Add] - WC 3.0 compatibility

= 1.0.0 =

First release