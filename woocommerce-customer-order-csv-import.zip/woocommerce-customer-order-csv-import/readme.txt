=== WooCommerce Customer/Order/Coupon CSV Import ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires at least: 4.4
Tested up to: 4.7.5
Requires WooCommerce at least: 2.5.5
Tested WooCommerce up to: 3.0.7

== Installation ==

1. Upload the entire 'woocommerce-customer-order-csv-import' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
