<?php

			$this->form_fields = array(
				'enabled'           => array(
				    'title'         => __( 'Enable/Disable', 'woocommerce-spusa' ),
				    'label'         => __( 'Enable Sage Payment Solutions API', 'woocommerce-spusa' ),
				    'type'          => 'checkbox',
				    'description'   => '',
				    'default'       => 'no'
				),
				'title'             => array(
				    'title'         => __( 'Title', 'woocommerce-spusa' ),
				    'type'          => 'text',
				    'description'   => __( 'This controls the title which the user sees during checkout.', 'woocommerce-spusa' ),
				    'default'       => __( 'Credit Card via Sage', 'woocommerce-spusa' )
				),
				'description'       => array(
				    'title'         => __( 'Description', 'woocommerce-spusa' ),
				    'type'          => 'textarea',
				    'description'   => __( 'This controls the description which the user sees during checkout.', 'woocommerce-spusa' ),
				    'default'       => 'Pay via Credit / Debit Card with Sage secure card processing.'
				),
				'status'            => array(
				    'title'         => __( 'Status', 'woocommerce-spusa' ),
				    'type'          => 'select',
				    'options'       => array('live'=>'Live','testing'=>'Testing'),
				    'description'   => __( 'Set Sage Bankcard Live/Testing Status.', 'woocommerce-spusa' ),
				    'default'       => 'testing'
				),
				'apiversion'     	=> array(
				    'title'         => __( 'Choose your API version', 'woocommerce-spusa' ),
				    'type'          => 'select',
				    'options'       => array('0'=>'Legacy','1'=>'Version 1'),
				    'label'     	=> __( 'Choose your API version', 'woocommerce-spusa' ),
				    'default'       => '0',
				    'description'   => __( 'If this is a new site with a new Sage account then set this to "Version 1". If you are upgrading and have been using Sage successfully for a while leave this set to "Legacy".', 'woocommerce-spusa' ),
				),
				'M_id_testing'      => array(
				    'title'         => __( 'Testing Merchant Identification Number', 'woocommerce-spusa' ),
				    'type'          => 'text',
				    'description'   => __( '12 Digit Merchant Identification Number (Virtual Terminal ID). This should have been supplied by Sage when you created your account.', 'woocommerce-spusa' ),
				    'default'       => ''
				),
				'M_key_testing'     => array(
				    'title'         => __( 'Testing Merchant Key', 'woocommerce-spusa' ),
				    'type'          => 'text',
				    'description'   => __( '12 Digit Merchant Key Required for Gateway Access. This should have been supplied by Sage when you created your account.', 'woocommerce-spusa' ),
				    'default'       => ''
				),
				'M_id'            	=> array(
				    'title'         => __( 'Live Merchant Identification Number', 'woocommerce-spusa' ),
				    'type'          => 'text',
				    'description'   => __( '12 Digit Merchant Identification Number (Virtual Terminal ID). This should have been supplied by Sage when you created your account.', 'woocommerce-spusa' ),
				    'default'       => ''
				),
				'M_key'            	=> array(
				    'title'         => __( 'Live Merchant Key', 'woocommerce-spusa' ),
				    'type'          => 'text',
				    'description'   => __( '12 Digit Merchant Key Required for Gateway Access. This should have been supplied by Sage when you created your account.', 'woocommerce-spusa' ),
				    'default'       => ''
				),
				'T_code'            => array(
				    'title'         => __( 'Transaction Processing Code', 'woocommerce-spusa' ),
				    'type'          => 'select',
				    'options'       => array( '01'=>'Sale','02'=>'AuthOnly' ),
				    'description'   => __( 'Set the processing code, leave this set to sale unless you know what you are doing.', 'woocommerce-spusa' ),
				    'default'       => '01'
				),
				'cardtypes'			=> array(
					'title' 		=> __( 'Accepted Cards', 'woocommerce-spusa' ), 
					'type' 			=> 'multiselect',
					'class'			=> 'chosen_select',
					'css'         	=> 'width: 350px;', 
					'description' 	=> __( 'Select which card types to accept.', 'woocommerce-spusa' ), 
					'default' 		=> '',
					'options' 		=> array(
							'MasterCard'		=> 'MasterCard', 
							'Visa'				=> 'Visa',
							'Discover'			=> 'Discover',
							'American Express' 	=> 'American Express'
						),
				),		
				'cvv' 				=> array(
					'title' 		=> __( 'CVV', 'woocommerce-spusa' ), 
					'label' 		=> __( 'Require customer to enter credit card CVV code', 'woocommerce-spusa' ), 
					'type' 			=> 'checkbox', 
					'description' 	=> __( '', 'woocommerce-spusa' ), 
					'default' 		=> 'no'
				),
				'order_button_text'	=> array(
					'title' 		=> __( 'Checkout Pay Button Text', 'woocommerce-spusa' ),
					'type' 			=> 'text',
					'description' 	=> __( 'This controls the pay button text shown during checkout.', 'woocommerce-spusa' ),
					'default' 		=> $this->default_order_button_text
				),
				'debug'     		=> array(
				    'title'         => __( 'Debug Mode', 'woocommerce-spusa' ),
				    'type'          => 'checkbox',
				    'options'       => array('no'=>'No','yes'=>'Yes'),
				    'label'     	=> __( 'Enable Debug Mode', 'woocommerce-spusa' ),
				    'default'       => 'no'
				)
			);			
