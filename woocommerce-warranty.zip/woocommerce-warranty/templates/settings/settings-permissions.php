<div id="warranty_settings_permissions">

    <?php WC_Admin_Settings::output_fields( $settings['permissions'] ); ?>

</div>