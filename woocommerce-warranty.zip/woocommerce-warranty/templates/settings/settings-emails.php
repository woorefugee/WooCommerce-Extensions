<div id="warranty_settings_emails">

    <?php WC_Admin_Settings::output_fields( $settings['emails'] ); ?>

</div>