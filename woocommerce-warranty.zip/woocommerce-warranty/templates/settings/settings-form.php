<div id="warranty_settings_form">

    <?php WC_Admin_Settings::output_fields( $settings['form'] ); ?>

</div>