<?php
/**
 * WooCommerce Bulk Downloads
 *
 * @package     WC-Bulk-Downloads/Templates
 * @author      WooThemes
 * @copyright   Copyright (c) 2015, WooThemes
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * My Account - Zip All Downloads Before
 */
?>
<form method="POST" action="" class="wcbd-zip-form">
