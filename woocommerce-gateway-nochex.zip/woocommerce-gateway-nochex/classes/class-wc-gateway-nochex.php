<?php
/**
 * WC_Nochex class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_Gateway_Nochex extends WC_Payment_Gateway {

	/**
	 * Constructor
	 */
	public function __construct() {
		global $woocommerce;

		$this->id					= 'nochex';
		$this->method_title 		= __( 'Nochex', 'wc_nochex' );
		$this->supports 			= array( 'products' );

		// Load the form fields
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Get setting values
		$this->title 				= $this->settings['title'];
		$this->description 			= $this->settings['description'];
		$this->order_description 	= $this->settings['order_description'];
		$this->enabled 				= $this->settings['enabled'];
		$this->logger 				= $this->settings['logger'];
		$this->test_transaction 	= $this->settings['test_transaction'];
		$this->hide_billing_details	= $this->settings['hide_billing_details'];
		$this->merchant_id			= $this->settings['merchant_id'];

		// Custom variables
		$this->paypage_endpoint		= 'https://secure.nochex.com/';
		$this->apc_endpoint			= 'https://www.nochex.com/nochex.dll/apc/apc';
		$this->callback_url			= $woocommerce->api_request_url( 'wc_gateway_nochex' );

		// Hooks
		add_action( 'admin_notices', array( $this, 'check_settings' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_api_wc_gateway_nochex', array( $this, 'nochex_apc' ) );
	}

    /**
     * init_form_fields function.
     */
    public function init_form_fields() {
    	$this->form_fields = array(
			'enabled' => array(
				'title'       => __( 'Enable Nochex', 'wc_nochex' ),
				'label'       => __( 'Turn on Nochex for WooCommerce', 'wc_nochex' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'yes'
			),
			'logger' => array(
				'title'       => __( 'Enable Logging', 'wc_nochex' ),
				'label'       => __( 'Write all APC updates to a log file.', 'wc_nochex' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
			),
			'test_transaction' => array(
				'title'       => __( 'Test Mode', 'wc_nochex' ),
				'label'       => __( 'Turn on test mode for Nochex', 'wc_nochex' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
			),
			'hide_billing_details' => array(
				'title'       => __( 'Hide Billing Details', 'wc_nochex' ),
				'type'        => 'checkbox',
				'description' => __( 'Require billing details entered in WooCommerce to be used for payment.', 'wc_nochex' ),
				'default'     => 'no'
			),
			'merchant_id' => array(
				'title'       => __( 'Merchant ID', 'wc_nochex' ),
				'type'        => 'text',
				'description' => __( 'Your merchant ID with Nochex', 'wc_nochex' )
			),
			'order_description' => array(
				'title'       => __( 'Order Description', 'wc_nochex' ),
				'type'        => 'text',
				'description' => __( 'The description of the order your customers may see during payment.', 'wc_nochex' ),
				'default'     => sprintf( __( 'Order from %s', 'wc_nochex' ), get_bloginfo( 'name' ) )
			),
			'title' => array(
				'title'   => __( 'Title', 'wc_nochex' ),
				'type'    => 'text',
				'default' => 'Nochex'
			),
			'description' => array(
				'title'       => __( 'Payment Gateway Description', 'wc_nochex' ),
				'type'        => 'text',
				'description' => __( 'The description your customers will see during checkout.', 'wc_nochex' ),
				'default'     => __( 'Pay using Nochex', 'wc_nochex' )
			),
			'order_description' => array(
				'title'       => __( 'Order Description', 'wc_nochex' ),
				'type'        => 'text',
				'description' => __( 'The description of the order your customers may see during payment.', 'wc_nochex' ),
				'default'     => sprintf( __( 'Order from %s', 'wc_nochex' ), get_bloginfo( 'name' ) )
			)
		);
	}

	/**
	 * payment_fields function.
	 */
	public function payment_fields() {
		if ( ! empty( $this->description ) ) {
			echo wpautop( $this->description );
		}
    }

	/**
	 * Process the payment
	 * 
	 * @param int $order_id
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = new WC_Order( $order_id );

		$values = array(
			'merchant_id'           => $this->merchant_id,
			'amount'                => $order->get_total(),
			'order_id'              => str_replace( '#', '', $order->get_order_number() ),
			'description'           => $this->order_description,
			'billing_fullname'      => $order->billing_first_name . ' ' . $order->billing_last_name,
			'billing_address'       => $order->billing_address_1,
			'billing_postcode'      => $order->billing_postcode,
			'delivery_fullname'     => $order->shipping_first_name . ' ' . $order->shipping_last_name,
			'delivery_address'      => $order->shipping_address_1,
			'delivery_postcode'     => $order->shipping_postcode,
			'email_address'         => $order->billing_email,
			'customer_phone_number' => $order->billing_phone,
			'optional_1'            => $order->order_key,
			'callback_url'          => urlencode( $this->callback_url ),
			'success_url'           => urlencode( $this->get_return_url( $order ) ),
			'failed_url'            => urlencode( $order->get_checkout_payment_url( true ) ),
		);

		if ( $this->hide_billing_details == 'yes' ) {
			$values['hide_billing_details'] = 'true';
		}

		if ( $this->test_transaction == 'yes' ) {
			$values['test_transaction'] = 100;
			$values['test_success_url'] = $values['success_url'];
		}

		return array(
			'result' 	=> 'success',
			'redirect'	=> add_query_arg( $values, $this->paypage_endpoint ),
		);
	}

	/**
	 * APC
	 */
	public function nochex_apc() {
		global $woocommerce;

		if ( isset( $_POST['order_id'] ) ) {

			$order = new WC_Order ( $_POST['order_id'] );

			if ( $this->logger == 'yes' ) {
				$this->logger = $woocommerce->logger();
				$this->logger->add( 'nochex', sprintf( __( '------ Start Order %s Nochex APC Processing ------', 'wc_nochex' ), $order->get_order_number() ) );
				if ( $order->key_is_valid( $_POST['custom'] ) ) {
					$this->logger->add( 'nochex', __( 'Order key is valid.', 'wc_nochex' ) );
					$status = $_POST['status'];
				} else {
					$this->logger->add( 'nochex', __( 'Order key is inalid.', 'wc_nochex' ) );
					$status = 'order key verification failed';
				}
				$body = array();
				foreach( $_POST as $key => $value ) {
					$this->logger->add( 'nochex', $key . ' => ' . $value );
					$body[] = urlencode( $key ) . '=' . urlencode( $value );
				}
				$body = implode( '&', $body );
				$result = wp_remote_retrieve_body( wp_remote_post( $this->apc_endpoint, array(
					'sslverify'	=> true,
					'headers'	=> array(
						'user-agent'	=> 'WooCommerce-Nochex/1.0.0',
						'Content-Type'	=> 'application/x-www-form-urlencoded',
						'Content-Length'	=> strlen( $body ),
					),
					'body'		=> $body,
				) ) );
				$this->logger->add( 'nochex', $result . ' (' . $body . ')' );
				$this->logger->add( 'nochex', sprintf( __( '------- End Order %s Nochex APC Processing -------', 'wc_nochex' ), $order->get_order_number() ) );
			}


			if ( $result == 'AUTHORISED' ) {
				$order->add_order_note( sprintf( __('Nochex Payment Status: %s', 'wc_nochex' ), $status ) );
				$order->add_order_note( sprintf( __('Nochex Transaction ID: %s', 'wc_nochex' ), $_POST['transaction_id'] ) );
				$order->add_order_note( sprintf( __('Nochex Security Key: %s', 'wc_nochex' ), $_POST['security_key'] ) );
				$order->payment_complete();
				$woocommerce->cart->empty_cart();
			} else {
				$order->add_order_note( sprintf( __('Nochex APC Declined', 'wc_nochex' ), $status ) );
			}
		}
	}

	/**
	 * Check the settings
	 */
	public function check_settings() {
		if ( $this->enabled == 'no' ) { // Are we enabled?
			return;
		} elseif ( empty( $this->merchant_id ) ) { // Do we have a merchant ID?
			echo '<div class="error"><p>' . sprintf( __( '<strong>%s Error</strong>: You have not entered a merchant ID, this is required to process transactions using Nochex.', 'wc_nochex' ), $this->method_title ) . '</p></div>';
			return;
		}
	}
}