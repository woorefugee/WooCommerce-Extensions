<?php
/*
Plugin Name: WooCommerce Nochex Gateway
Plugin URI: http://woothemes.com/woocommerce/
Description: Nochex payment gateway to your WooCommerce website.
Version: 1.1.0
Author: WooThemes
Author URI: http://www.patrickgarman.com/wordpress-plugins/
License: GPLv2
*/

/* Copyright 2014 WooThemes

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) )
	require_once( 'woo-includes/woo-functions.php' );

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '424073c11dbf33bb96e5515d5f892893', '122150' );

/**
 * Start Nochex
 */
function woocommerce_nochex_init() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) )
		return;

	load_plugin_textdomain( 'wc_nochex', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	if ( ! class_exists( 'WC_Nochex' ) )
		require_once( 'classes/class-wc-gateway-nochex.php' );

	add_filter( 'woocommerce_payment_gateways', 'wc_add_nochex' );

}

add_action( 'plugins_loaded', 'woocommerce_nochex_init' );


/**
 * Add Nochex
 */
function wc_add_nochex( $methods ) {
	$methods[] = 'WC_Gateway_Nochex';
	return $methods;
}