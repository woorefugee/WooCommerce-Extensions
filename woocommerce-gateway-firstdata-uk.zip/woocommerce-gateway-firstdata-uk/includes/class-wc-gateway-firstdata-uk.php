<?php
/**
* WC_Gateway_FirstData_UK
*/
class WC_Gateway_FirstData_UK extends WC_Payment_Gateway {

	private $endpoint;
	private $log;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->method_title       = 'FirstData UK';
		$this->method_description = __( 'The Connect solution provides a simple way for connecting an online store to FirstData UK. Connect manages all of your interactions with credit card processors and financial institutions.', 'woocommerce-gateway-firstdata-uk' );
		$this->id                 = 'firstdata_uk';
		$this->has_fields         = false;
		$this->icon               = apply_filters( 'woocommerce_firstdata_uk_logo', plugins_url( basename( dirname( dirname( __FILE__ ) ) ) . '/assets/images/cards.png' ) );

		// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Define user set variables
		$this->title         = $this->get_option( 'title' );
		$this->store_id      = $this->get_option( 'store_id' );
		$this->shared_secret = $this->get_option( 'shared_secret' );
		$this->test_mode     = 'yes' === $this->get_option( 'test_mode' );
		$this->endpoint      = $this->test_mode ? "https://test.ipg-online.com/connect/gateway/processing" : "https://www.ipg-online.com/connect/gateway/processing";
		$this->debug         = 'yes' === $this->get_option( 'debug', 'no' );

		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_api_' . strtolower( __CLASS__ ), array( $this, 'response_handler' ) );
	}

	/**
	 * Logging method
	 * @param  string $message
	 */
	public function log( $message ) {
		if ( $this->debug ) {
			if ( empty( $this->log ) ) {
				$this->log = new WC_Logger();
			}
			$this->log->add( 'firstdata-uk', $message );
		}
	}

    /**
     * init_form_fields function.
     */
    public function init_form_fields() {
    	$this->form_fields = array(
			'enabled' => array(
				'title'       => __( 'Enable/Disable', 'woocommerce-gateway-firstdata-uk' ),
				'label'       => __( 'Enable FirstData UK', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
			),
			'title' => array(
				'title'       => __( 'Title', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'text',
				'description' => __( 'Payment method title that the customer will see on your website.', 'woocommerce-gateway-firstdata-uk' ),
				'default'     => __( 'FirstData UK', 'woocommerce-gateway-firstdata-uk' )
			),
			'store_id' => array(
				'title'       => __( 'Store ID', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'text',
				'description' => __( 'This is the ID of the store that was given to you by FirstData UK. For example: 13123456789', 'woocommerce-gateway-firstdata-uk' ),
				'default'     => ''
			),
			'shared_secret' => array(
				'title'       => __( 'Shared Secret', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'text',
				'description' => __( 'This is the shared secret provided to you by FirstData UK.', 'woocommerce-gateway-firstdata-uk' ),
				'default'     => ''
			),
			'test_mode' => array(
				'title'       => __( 'Test Mode', 'woocommerce-gateway-firstdata-uk' ),
				'label'       => __( 'Enable this option if you have a testing account only. Live payments will not be taken if enabled.', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
			),
			'debug' => array(
				'title'       => __( 'Debug Log', 'woocommerce-gateway-firstdata-uk' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable Logging', 'woocommerce-gateway-firstdata-uk' ),
				'default'     => 'no',
				'description' => sprintf( __( 'Log FirstData events, such as the response handler, inside <code>%s</code>', 'woocommerce-gateway-firstdata-uk' ), wc_get_log_file_path( 'firstdata-uk' ) )
			),
 	   );
    }

    /**
     * Output for the order received page.
     */
	public function receipt_page( $order ) {
		echo '<p>' . __( 'Thank you - your order is now pending payment. You should be automatically redirected to FirstData to make payment.', 'woocommerce-gateway-firstdata-uk' ) . '</p>';
		echo $this->generate_form( $order );
	}

    /**
     * Process the payment and return the result
     *
     * @param int $order_id
     * @return array
     */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true )
		);
	}

	/**
	 * Get Currency number
	 * @param  string $code
	 * @return int
	 */
	public function get_currency_number( $code ) {
		$currencies = array(
			'DKK' => '208', // Danish Kroner
			'EUR' => '978', // Euro
			'USD' => '840', // US Dollar $
			'GBP' => '826', // English Pound £
			'SEK' => '752', // Swedish Kroner
			'AUD' => '036', // Australian Dollar
			'CAD' => '124', // Canadian Dollar
			'ISK' => '352', // Icelandic Kroner
			'JPY' => '392', // Japanese Yen
			'NZD' => '554', // New Zealand Dollar
			'NOK' => '578', // Norwegian Kroner
			'CHF' => '756', // Swiss Franc
			'TRY' => '949', // Turkish Lire
			'BHD' => '048', // Bahrain Dinar
			'CZK' => '203', // Hzech Koruna
			'CNY' => '156', // Chinese R
			'HRK' => '191', // Croatian Kuna
			'HKD' => '344', // Hong Kong Dollar
			'HUF' => '348', // Hungarian Forint
			'INR' => '356', // Indian Rupee
			'ISL' => '376', // Israili New Shekel
			'KWD' => '414', // Kuwaiti Dinar
			'LTL' => '440', // Lithuanian Litas
			'MXN' => '484', // Mexican Peso
			'PLN' => '985', // Polish Zloty
			'RON' => '946', // Romanian New Leu
			'SAR' => '682', // Saudi Rihal
			'SGD' => '702', // Singapore Dollar
			'ZAR' => '710', // South African Rand
			'KRW' => '410', // South African Won
			'TRY' => '949', // Turkish Lira
			'AED' => '784', // UAE Dirham
		);

		if ( isset( $currencies[ $code ] ) ) {
			return $currencies[ $code ];
		}

		return 0;
	}

	/**
	 * Check If The Gateway Is Available For Use
	 * @return bool
	 */
	public function is_available() {
		if ( $this->enabled == "yes" && $this->get_currency_number( get_woocommerce_currency() ) ) {
			return true;
		}
	}

	/**
	 * Hashing function.
	 *
	 * @since 1.1.3
	 * @version 1.1.3
	 * @param string $string_to_hash
	 */
	public function hash( $string_to_hash ) {
		$hex_str = '';

		for ( $i = 0; $i < strlen( $string_to_hash ); $i++ ) {
			$hex_str .= dechex( ord( $string_to_hash[ $i ] ) );
		}

		return hash( 'sha256', $hex_str );
	}

    /**
	 * Generate the form to post to FirstData UK
     * @param mixed $order_id
     * @return string
     */
    public function generate_form( $order_id ) {
		$order 					= wc_get_order( $order_id );
		$firstdata_txndatetime 	= get_post_meta( $order_id, '_firstdata_txndatetime', TRUE );

		$this->log( sprintf( 'Generating form for order %d', $order_id ) );

		if ( isset( $firstdata_txndatetime ) && $firstdata_txndatetime != '' ) {
			$txndatetime 	= $firstdata_txndatetime;
		} else {
			@date_default_timezone_set( 'Europe/London' );
			$txndatetime 	= date( 'Y:m:d-H:i:s' );
			delete_post_meta( $order_id, '_firstdata_txndatetime' );
			update_post_meta( $order_id, '_firstdata_txndatetime', $txndatetime );
		}

		$pre_wc_30 = version_compare( WC_VERSION, '3.0', '<' );

		$args = array(
			'txntype'                    => 'sale',
			'timezone'                   => 'Europe/London',
			'txndatetime'                => $txndatetime,
			'storename'                  => $this->store_id,
			'hash_algorithm'             => 'SHA256',
			'mode'                       => 'payplus',
			'chargetotal'                => $order->get_total(),
			'currency'                   => $this->get_currency_number( get_woocommerce_currency() ),
			'bcompany'                   => $pre_wc_30 ? $order->billing_company : $order->get_billing_company(),
			'bname'                      => $pre_wc_30 ? $order->billing_first_name . ' ' . $order->billing_last_name : $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
			'baddr1'                     => substr( ( $pre_wc_30 ? $order->billing_address_1 : $order->get_billing_address_1() ), 0, 30 ),
			'baddr2'                     => substr( ( $pre_wc_30 ? $order->billing_address_2 : $order->get_billing_address_2() ), 0, 30 ),
			'bcity'                      => substr( ( $pre_wc_30 ? $order->billing_city : $order->get_billing_city() ), 0, 30 ),
			'bstate'                     => substr( ( $pre_wc_30 ? $order->billing_state : $order->get_billing_state() ), 0, 30 ),
			'bcountry'                   => $pre_wc_30 ? $order->billing_country : $order->get_billing_country(),
			'bzip'                       => $pre_wc_30 ? $order->billing_postcode : $order->get_billing_postcode(),
			'phone'                      => substr( ( $pre_wc_30 ? $order->billing_phone : $order->get_billing_phone() ), 0, 20 ),
			'fax'                        => '',
			'email'                      => substr( ( $pre_wc_30 ? $order->billing_email : $order->get_billing_email() ), 0, 45 ),
			'oid'                        => $pre_wc_30 ? $order->id : $order->get_id(),
			'invoicenumber'              => $order->get_order_number(),
			'transactionNotificationURL' => WC()->api_request_url( __CLASS__ ),
			'responseSuccessURL'         => $this->get_return_url( $order ),
			'responseFailURL'            => $this->get_return_url( $order )
		);

		// Generate hash
		$firstdata_hash = get_post_meta( $order_id, '_firstdata_hash', TRUE );

		if ( ! empty( $firstdata_hash ) ) {
			$args['hash'] = $firstdata_hash;
		} else {
			$str = $args['storename'] . $args['txndatetime'] . $args['chargetotal'] . $args['currency'] . html_entity_decode( $this->shared_secret );

			$args['hash'] = $this->hash( $str );
			delete_post_meta( $order_id, '_firstdata_hash' );
			update_post_meta( $order_id, '_firstdata_hash', $args['hash'] );
		}

		$this->log( sprintf( 'Form data for order %d: %s', $order_id, print_r( $args, true ) ) );

		wc_enqueue_js( '
				$.blockUI({
					message: "' . esc_js( __( 'Thank you for your order. We are now redirecting you to make payment.', 'woocommerce-gateway-firstdata-uk' ) ) . '",
					baseZ: 99999,
					overlayCSS:
						{
							background: "#fff",
							opacity: 0.6
						},
					css: {
		        			padding:        "20px",
		        			zindex:         "9999999",
		        			textAlign:      "center",
		        			color:          "#555",
		        			border:         "3px solid #aaa",
		        			backgroundColor:"#fff",
		        			cursor:         "wait",
		        			lineHeight:		"24px",
		    			}
			});
			jQuery("#submit_payment_form").click();
		' );

		foreach ( $args as $key => $value ) {
			$input_args[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
		}

		return '<form action="' . esc_url( $this->endpoint ) . '" method="post" id="payment_form" target="_top">
				' . implode( '', $input_args) . '
				<!-- Button Fallback -->
				<div class="payment_buttons">
					<input type="submit" class="button alt" id="submit_payment_form" value="' . __( 'Pay for order', 'woocommerce-gateway-firstdata-uk' ) . '" /> <a class="button cancel" href="' . esc_url( $order->get_cancel_order_url() ) . '">'.__( 'Cancel order &amp; restore cart', 'woocommerce-gateway-firstdata-uk' ).'</a>
				</div>
				<script type="text/javascript">
					jQuery(".payment_buttons").hide();
				</script>
			</form>';
	}

	/**
	 * Process the response from FirstData UK
	 */
	public function response_handler() {
		if ( empty( $_POST ) || empty( $_POST['oid'] ) ) {
			$this->log( sprintf( 'Response handler called without required POST data: %s', esc_html( print_r( $_POST, true ) ) ) );
			exit;
		}

		$approval_code = substr( wc_clean( $_POST['approval_code'] ), 0, 1 );
		$order_id      = absint( $_POST['oid'] );
		$order         = wc_get_order( $order_id );

		$this->log( sprintf( 'Response handler called for order %d. %s', $order_id, esc_html( print_r( $_POST, true ) ) ) );

		// Already paid?
		if ( 'processing' === $order->get_status() || 'completed' === $order->get_status() ) {
			$this->log( sprintf( 'Order %d is already paid.', $order_id ) );
			exit;
		}

		$str = number_format( $order->get_total(), 2, '.', '' ) . html_entity_decode( $this->shared_secret ) . $this->get_currency_number( get_woocommerce_currency() ) . get_post_meta( $order_id, '_firstdata_txndatetime', TRUE ) . $this->store_id . wc_clean( $_POST['approval_code'] );

		$hash = $this->hash( $str );

		// Store details from response
		if ( isset( $_POST['refnumber'] ) ) {
			update_post_meta( $order_id, 'refnumber', wc_clean( $_POST['refnumber'] ) );
		}

		if ( isset( $_POST['ccbin'] ) ) {
			update_post_meta( $order_id, 'ccbin', wc_clean( $_POST['ccbin'] ) );
		}

		if ( isset( $_POST['cccountry'] ) ) {
			update_post_meta( $order_id, 'cccountry', wc_clean( $_POST['cccountry'] ) );
		}

		if ( isset( $_POST['ccbrand'] ) ) {
			update_post_meta( $order_id, 'ccbrand', wc_clean( $_POST['ccbrand'] ) );
		}

		if ( isset( $_POST['status'] ) ) {
			update_post_meta( $order_id, 'status', wc_clean( $_POST['status'] ) );
		}

		// Handle status
		switch ( $approval_code ) {
			case 'Y' :
				if ( $hash !== $_POST['notification_hash'] ) {
					$order->add_order_note( sprintf( __( 'Error: FirstData UK Hash mismatch. Check your shared secret.<br />Store transaction time : %s<br />Store Hash : %s<br />Notification hash: %s<br />Approval code: %s', 'woocommerce-gateway-firstdata-uk' ), get_post_meta( $order_id, '_firstdata_txndatetime', TRUE ), $hash, wc_clean( $_POST['notification_hash'] ), wc_clean( $_POST['approval_code'] ) ) );

					// Mark as on-hold (we're awaiting the payment)
					$order->update_status( 'on-hold', __( 'FirstData UK transaction notification received, but the hash check failed. Please verify payment manually.', 'woocommerce-gateway-firstdata-uk' ) );

					// Reduce stock levels
					if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
						$order->reduce_order_stock();
					} else {
						wc_reduce_stock_levels( $order->get_id() );
					}
				} else {
					$order->add_order_note( sprintf( __( 'FirstData UK charge complete (Charge ID: %s)', 'woocommerce-gateway-firstdata-uk' ), wc_clean( $_POST['ipgTransactionId'] ) ) );
					$order->payment_complete( wc_clean( $_POST['ipgTransactionId'] ) );
				}
			break;
			case 'N' :
				$order->update_status( 'failed', __( 'FirstData UK payment failed.', 'woocommerce-gateway-firstdata-uk' ) );
			break;
			case '?' :
				// Mark as on-hold (we're awaiting the payment)
				$order->update_status( 'on-hold', __( 'FirstData UK transaction has been successfully initialised, but a final result is not yet available. Please verify payment manually.', 'woocommerce-gateway-firstdata-uk' ) );

				// Reduce stock levels
				if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
					$order->reduce_order_stock();
				} else {
					wc_reduce_stock_levels( $order->get_id() );
				}
			break;
		}

		// Remove stored transaction time and hash
		delete_post_meta( $order_id, '_firstdata_hash' );
		delete_post_meta( $order_id, '_firstdata_txndatetime' );

		exit;
	}
}
