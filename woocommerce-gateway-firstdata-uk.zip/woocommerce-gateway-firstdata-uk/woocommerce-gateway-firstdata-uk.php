<?php
/**
 * Plugin Name: WooCommerce FirstData UK Gateway
 * Plugin URI: https://woocommerce.com/products/first-data-merchant-solutions/
 * Description: FirstData (UK) gateway for WooCommerce. Uses the 'connect' solution.
 * Version: 1.1.3
 * Author: WooCommerce
 * Author URI: https://woocommerce.com/
 * 
 * Copyright: © 2009-2017 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * Woo: 260728:17f6fe73c7075b197c3f9ea3c28649bf
 */

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '17f6fe73c7075b197c3f9ea3c28649bf', '260728' );

/**
 * Check if WooCommerce is active
 */
if ( is_woocommerce_active() ) :

define( 'WC_GATEWAY_FIRSTDATA_UK_VERSION', '1.1.3' );

/**
 * WC_FirstData_UK
 */
class WC_FirstData_UK {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_links' ) );
		add_action( 'init', array( $this, 'i18n' ) );
		add_action( 'plugins_loaded', array( $this, 'init_gateway' ) );
		add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
	}

	/**
	 * Plugin page links
	 */
	public function plugin_links( $links ) {
		$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wc_gateway_firstdata_uk' ) . '">' . __( 'Settings', 'woocommerce-gateway-firstdata-uk' ) . '</a>',
			'<a href="http://support.woothemes.com/">' . __( 'Support', 'woocommerce-gateway-firstdata-uk' ) . '</a>',
			'<a href="https://docs.woocommerce.com/document/firstdata-uk/">' . __( 'Docs', 'woocommerce-gateway-firstdata-uk' ) . '</a>',
		);
		return array_merge( $plugin_links, $links );
	}

	/**
	 * Localisation
	 */
	public function i18n() {
		load_plugin_textdomain( 'woocommerce-gateway-firstdata-uk', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	 * Init gateway
	 */
	public function init_gateway() {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}
		include_once( 'includes/class-wc-gateway-firstdata-uk.php' );
	}

	/**
	* Add gateway to WC
	*
	* @param  array $methods
	* @return array of methods
	*/
	public function add_gateway( $methods ) {
		$methods[] = 'WC_Gateway_FirstData_UK';
		return $methods;
	}
}

new WC_FirstData_UK;

endif;
