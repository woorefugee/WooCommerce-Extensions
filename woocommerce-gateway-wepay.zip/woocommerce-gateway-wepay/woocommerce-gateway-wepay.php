<?php
/**
 * Plugin Name: WooCommerce WePay Gateway
 * Plugin URI: http://www.woocommerce.com/products/wepay/
 * Description: Accept payments via WePay on your WooCommerce store
 * Author: SkyVerge
 * Author URI: http://www.woocommerce.com/
 * Version: 1.6.0
 * Text Domain: woocommerce-gateway-wepay
 * Domain Path: /i18n/languages/
 *
 * Copyright: (c) 2013-2017, SkyVerge, Inc. (info@skyverge.com)
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-WePay
 * @author    SkyVerge
 * @category  Gateway
 * @copyright Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), 'cb534e6d36618aba3dcac2fdfb30ec5c', '187886' );

// WC active check
if ( ! is_woocommerce_active() ) {
	return;
}

// Required library class
if ( ! class_exists( 'SV_WC_Framework_Bootstrap' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'lib/skyverge/woocommerce/class-sv-wc-framework-bootstrap.php' );
}

SV_WC_Framework_Bootstrap::instance()->register_plugin( '4.6.0', __( 'WooCommerce WePay Gateway', 'woocommerce-gateway-wepay' ), __FILE__, 'init_woocommerce_gateway_wepay', array(
	'minimum_wc_version'   => '2.5.5',
	'minimum_wp_version'   => '4.1',
	'backwards_compatible' => '4.4',
) );

function init_woocommerce_gateway_wepay() {

/**
 * The main class for the WePay Gateway.  This class handles all the
 * non-gateway tasks such as verifying dependencies are met, loading the text
 * domain, etc.  It also loads the WePay Gateway class when needed now that the
 * gateway is only created on the checkout & settings pages / api hook.
 *
 * Prefixes used :
 *  + 'wc_wepay_' for option keys and actions/filters
 *  + '_wc_wepay_' for meta keys
 */
class WC_WePay extends SV_WC_Plugin {


	/** plugin version number */
	const VERSION = '1.6.0';

	/** @var WC_WePay single instance of this plugin */
	protected static $instance;

	/** plugin id */
	const PLUGIN_ID = 'wepay';

	/** plugin text domain, DEPRECATED since 1.4.0 */
	const TEXT_DOMAIN = 'woocommerce-gateway-wepay';

	/** gateway class name */
	const GATEWAY_CLASS_NAME = 'WC_Gateway_WePay';


	/**
	 * Initializes the plugin
	 *
	 * @since 1.0
	 */
	public function __construct() {

		parent::__construct(
			self::PLUGIN_ID,
			self::VERSION,
			array(
				'text_domain'  => 'woocommerce-gateway-wepay',
				'dependencies' => array( 'curl' ),
			)
		);

		// include required files
		add_action( 'sv_wc_framework_plugins_loaded', array( $this, 'includes' ) );
	}


	/**
	 * Include required files
	 *
	 * @since 1.0
	 */
	public function includes() {

		// load gateway class
		require_once( $this->get_plugin_path() . '/includes/class-wc-gateway-wepay.php' );

		// Add gateway to WC Payment Methods
		add_filter( 'woocommerce_payment_gateways', array( $this, 'load_gateway' ) );
	}


	/**
	 * Adds WePay to the list of available payment gateways
	 *
	 * @since 1.0
	 * @param array $gateways
	 * @return array $gateways
	 */
	public function load_gateway( $gateways ) {

		$gateways[] = self::GATEWAY_CLASS_NAME;

		return $gateways;
	}


	/**
	 * Adds an admin notice if the merchant account's API version is incompatible with this integration.
	 *
	 * @since 1.5.1
	 * @see SV_WC_Plugin::add_admin_notices()
	 */
	public function add_admin_notices() {

		// show any dependency notices
		parent::add_admin_notices();

		$gateways = WC()->payment_gateways()->payment_gateways();

		if ( ! isset( $gateways[ self::PLUGIN_ID ] ) ) {
			return;
		}

		$gateway = $gateways[ self::PLUGIN_ID ];

		if ( $gateway->is_configured() && ! $gateway->is_api_compatible() ) {

			$this->get_admin_notice_handler()->add_admin_notice( sprintf(
				/** translators: Placeholders: %1$s - the plugin name, %2$s - <a> tag, %3$s - </a> tag */
				__( '%1$s: Your merchant account API version is incompatible with this integration. Please %2$ssee the documentation%3$s for how to set the correct API version and enable this gateway.', 'woocommerce-gateway-wepay' ),
				'<strong>' . $this->get_plugin_name() . '</strong>',
				'<a href="' . esc_url( $this->get_documentation_url() ) . '#api-version-unmatched" target="_blank">',
				'</a>'
			), 'wc-wepay-api-notice', array(
				'dismissible'  => false,
				'notice_class' => 'error',
			) );
		}
	}


	/** Helper methods ******************************************************/


	/**
	 * Main WePay Instance, ensures only one instance is/can be loaded
	 *
	 * @since 1.2.0
	 * @see wc_wepay()
	 * @return WC_WePay
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	/**
	 * Gets the plugin documentation URL
	 *
	 * @since 1.3.0
	 * @see SV_WC_Plugin::get_documentation_url()
	 * @return string
	 */
	public function get_documentation_url() {
		return 'http://docs.woocommerce.com/document/woocommerce-wepay/';
	}


	/**
	 * Gets the plugin support URL
	 *
	 * @since 1.3.0
	 * @see SV_WC_Plugin::get_support_url()
	 * @return string
	 */
	public function get_support_url() {

		return 'https://woocommerce.com/my-account/tickets/';
	}


	/**
	 * Returns the plugin name, localized
	 *
	 * @since 1.1
	 * @see SV_WC_Plugin::get_plugin_name()
	 * @return string the plugin name
	 */
	public function get_plugin_name() {
		return __( 'WooCommerce WePay', 'woocommerce-gateway-wepay' );
	}


	/**
	 * Returns __FILE__
	 *
	 * @since 1.1
	 * @see SV_WC_Plugin::get_file()
	 * @return string the full path and filename of the plugin file
	 */
	protected function get_file() {
		return __FILE__;
	}


	/**
	 * Gets the gateway configuration URL
	 *
	 * @since 1.1
	 * @see SV_WC_Plugin::get_settings_url()
	 * @param string $_ unused
	 * @return string plugin settings URL
	 */
	public function get_settings_url( $_ = null ) {

		return admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $this->get_configuration_section() );
	}


	/**
	 * Returns true if on the gateway settings page
	 *
	 * @since 1.1
	 * @see SV_WC_Plugin::is_plugin_settings()
	 * @return boolean true if on the admin gateway settings page
	 */
	public function is_plugin_settings() {

		return isset( $_GET['page'] ) && 'wc-settings' == $_GET['page'] &&
		isset( $_GET['tab'] ) && 'checkout' == $_GET['tab'] &&
		isset( $_GET['section'] ) && $this->get_configuration_section() == $_GET['section'];
	}


	/**
	 * Get the gateway settings screen section ID.
	 *
	 * @since 1.5.0
	 * @return string
	 */
	public function get_configuration_section() {

		// WC 2.6+ uses the gateway ID instead of class name
		if ( SV_WC_Plugin_Compatibility::is_wc_version_lt_2_6() ) {
			$section = strtolower( self::GATEWAY_CLASS_NAME );
		} else {
			$section = 'wepay';
		}

		return $section;
	}


} // end WC_WePay


/**
 * Returns the One True Instance of WePay
 *
 * @since 1.2.0
 * @return WC_WePay
 */
function wc_wepay() {
	return WC_WePay::instance();
}

// fire it up!
wc_wepay();

} // init_woocommerce_gateway_wepay()
