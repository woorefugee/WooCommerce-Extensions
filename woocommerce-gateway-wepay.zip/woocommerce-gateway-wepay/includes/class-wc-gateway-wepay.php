<?php
/**
 * WooCommerce WePay
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce WePay to newer
 * versions in the future. If you wish to customize WooCommerce WePay for your
 * needs please refer to http://docs.woocommerce.com/document/wepay/ for more information.
 *
 * @package     WC-WePay/Gateway
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * WePay Gateway Class
 *
 * Handles all gateway-specific actions
 *
 * @since 1.0
 * @extends \WC_Payment_Gateway
 */
class WC_Gateway_WePay extends WC_Payment_Gateway {


	/** WePay API Version */
	const API_VERSION = '2016-08-10';

	/** @var string API environment */
	protected $environment;

	/** @var string production client ID */
	protected $production_client_id;

	/** @var string production client secret */
	protected $production_client_secret;

	/** @var string production access token */
	protected $production_access_token;

	/** @var string production account ID */
	protected $production_account_id;

	/** @var string staging client ID */
	protected $staging_client_id;

	/** @var string staging client secret */
	protected $staging_client_secret;

	/** @var string staging access token */
	protected $staging_access_token;

	/** @var string staging account ID */
	protected $staging_account_id;

	/** @var string the type transaction, e.g. GOODS */
	protected $transaction_type;

	/** @var string how to handle checkout, either iFrame (redirect to pay page) or regular (redirect to wepay) */
	protected $checkout_mode;

	/** @var string who to charge the payment processing fees to */
	protected $fee_payer;

	/** @var string debug mode type */
	protected $debug_mode;

	/** @var object WePay API instance */
	protected $api;


	/**
	 * Load payment gateway and related settings
	 *
	 * @since 1.0
	 * @return \WC_Gateway_WePay
	 */
	public function __construct() {

		$this->id                 = 'wepay';
		$this->method_title       = __( 'WePay', 'woocommerce-gateway-wepay' );
		$this->method_description = __( 'Allow customers to pay securely with their credit card and bank account via WePay.', 'woocommerce-gateway-wepay' );

		$this->supports = array( 'products' );

		// enable fields so payment method icons show up
		$this->has_fields = true;

		$this->icon = apply_filters( 'wc_gateway_wepay_icon', '' );

		$this->order_button_text = __( 'Continue', 'woocommerce-gateway-wepay' );

		// Load the form fields
		$this->init_form_fields();

		// Load the settings
		$this->init_settings();

		// Define user set variables
		foreach ( $this->settings as $setting_key => $setting ) {
			$this->$setting_key = $setting;
		}

		// IPN listener hook
		add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'process_ipn' ) );

		// iFrame checkout requires a pay page
		if ( $this->is_iframe_checkout() ) {
			add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'show_iframe_pay_page' ) );
		}

		// Save settings
		if ( is_admin() ) {
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}
	}


	/** Admin Methods ******************************************************/


	/**
	 * Initialize payment gateway settings fields
	 *
	 * @since 1.0
	 */
	public function init_form_fields() {

		$this->form_fields = array(

			'enabled' => array(
				'title'       => __( 'Enable / Disable', 'woocommerce-gateway-wepay' ),
				'label'       => __( 'Enable this gateway.', 'woocommerce-gateway-wepay' ),
				'type'        => 'checkbox',
				'default'     => 'no'
			),

			'title' => array(
				'title'       => __( 'Title', 'woocommerce-gateway-wepay' ),
				'type'        => 'text',
				'desc_tip'    => __( 'Payment method title that the customer will see during checkout.', 'woocommerce-gateway-wepay' ),
				'default'     => __( 'Credit Card / Bank Account', 'woocommerce-gateway-wepay' )
			),

			'description' => array(
				'title'       => __( 'Description', 'woocommerce-gateway-wepay' ),
				'type'        => 'textarea',
				'desc_tip'    => __( 'Payment method description that the customer will see during checkout.', 'woocommerce-gateway-wepay' ),
				'default'     => __( 'Pay securely using your credit card or bank account.', 'woocommerce-gateway-wepay' )
			),

			'environment' => array(
				'title'    => __( 'Environment', 'woocommerce-gateway-wepay' ),
				'type'     => 'select',
				'desc_tip' => __( 'The environment to post transactions to - use "Staging" when testing (which requires separate staging credentials) and "Production" when you are ready to accept live payments.', 'woocommerce-gateway-wepay' ),
				'default'  => 'production',
				'options' => array(
					'production' => __( 'Production', 'woocommerce-gateway-wepay' ),
					'staging'    => __( 'Staging', 'woocommerce-gateway-wepay' ),
				),
			),

			'production_client_id' => array(
				'title'    => __( 'Client ID', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The ID of your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'production_client_secret' => array(
				'title'    => __( 'Client Secret', 'woocommerce-gateway-wepay' ),
				'type'     => 'password',
				'desc_tip' => __( 'The secret value for your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'production_access_token' => array(
				'title'    => __( 'Access Token', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The access token for your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'production_account_id' => array(
				'title'    => __( 'Account ID', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The ID of the payment account where you collect money. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'staging_client_id' => array(
				'title'    => __( 'Staging Client ID', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The ID of your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'staging_client_secret' => array(
				'title'    => __( 'Staging Client Secret', 'woocommerce-gateway-wepay' ),
				'type'     => 'password',
				'desc_tip' => __( 'The secret value for your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'staging_access_token' => array(
				'title'    => __( 'Staging Access Token', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The access token for your API application. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'staging_account_id' => array(
				'title'    => __( 'Staging Account ID', 'woocommerce-gateway-wepay' ),
				'type'     => 'text',
				'desc_tip' => __( 'The ID of the payment account where you collect money. Log into your WePay account to get this.', 'woocommerce-gateway-wepay' ),
				'default'  => ''
			),

			'transaction_type' => array(
				'title'       => __( 'Transaction Type', 'woocommerce-gateway-wepay' ),
				'type'        => 'select',
				'desc_tip'    => __( 'Select the primary type of transaction that you process. If you\'re unsure, choose "Goods" or contact WePay for more information.', 'woocommerce-gateway-wepay' ),
				'default'     => 'GOODS',
				'options' => array(
					'goods'    => __( 'Goods', 'woocommerce-gateway-wepay' ),
					'service'  => __( 'Service', 'woocommerce-gateway-wepay' ),
					'personal' => __( 'Personal', 'woocommerce-gateway-wepay' ),
					'event'    => __( 'Event', 'woocommerce-gateway-wepay' ),
					'donation' => __( 'Donation', 'woocommerce-gateway-wepay' ),
				),
			),

			'checkout_mode' => array(
				'title'    => __( 'Checkout Mode', 'woocommerce-gateway-wepay' ),
				'type'     => 'select',
				'desc_tip' => __( 'Select the checkout mode for customers. With "Redirect", customers will enter their payment information the WePay website. With "iFrame", customers will enter their payment information on a popup window on your site.', 'woocommerce-gateway-wepay' ),
				'default'  => 'regular',
				'options'  => array(
					'regular' => __( 'Redirect', 'woocommerce-gateway-wepay' ),
					'iframe'  => __( 'iFrame', 'woocommerce-gateway-wepay' ),
				),
			),

			'fee_payer' => array(
				'title'    => __( 'Fee Payer', 'woocommerce-gateway-wepay' ),
				'type'     => 'select',
				'desc_tip' => __( 'Select who should pay the fee charged by WePay for processing the payment. Set to "Payer" to charge fees to the person paying (Payer will pay amount + fees, payee will receive amount). Set to "Payee" to charge fees to the person receiving money (Payer will pay amount, Payee will receive amount - fees). Defaults to "Payer".', 'woocommerce-gateway-wepay' ),
				'default'  => 'Payer',
				'options'  => array(
					'payer' => __( 'Payer', 'woocommerce-gateway-wepay' ),
					'payee' => __( 'Payee', 'woocommerce-gateway-wepay' ),
				),
			),

			'card_types' => array(
				'title'       => __( 'Accepted Card Logos', 'woocommerce-gateway-wepay' ),
				'type'        => 'multiselect',
				'desc_tip'    => __( 'Select which card types you accept to display the logos for on your checkout page.  This is purely cosmetic and optional, and will have no impact on the cards actually accepted by your account.', 'woocommerce-gateway-wepay' ),
				'default'     => array( 'VISA', 'MC', 'AMEX', 'DISC', 'ECHECK' ),
				'class'       => 'wc-enhanced-select',
				'css'         => 'width: 350px;',
				'options'     => apply_filters( 'wc_wepay_card_types',
					array(
						'VISA'   => 'Visa',
						'MC'     => 'MasterCard',
						'AMEX'   => 'American Express',
						'DISC'   => 'Discover',
						'ECHECK' => 'Bank Account',
					)
				)
			),

			'debug_mode' => array(
				'title'       => __( 'Debug Mode', 'woocommerce-gateway-wepay' ),
				'type'        => 'select',
				'desc_tip'    => __( 'Show Detailed Error Messages and API requests / responses on the checkout page and/or save them to the log for debugging purposes.', 'woocommerce-gateway-wepay' ),
				'default'     => 'off',
				'options' => array(
					'off'      => __( 'Off', 'woocommerce-gateway-wepay' ),
					'checkout' => __( 'Show on Checkout Page', 'woocommerce-gateway-wepay' ),
					'log'      => __( 'Save to Log', 'woocommerce-gateway-wepay' ),
					'both'     => __( 'Both', 'woocommerce-gateway-wepay' )
				),
			),

		);
	}


	/**
	 * Display settings page with some additional javascript for hiding staging credential fields
	 *
	 * @since 1.0
	 */
	public function admin_options() {

		parent::admin_options();

		wc_enqueue_js( '
			$( "select#woocommerce_wepay_environment" ).change( function() {
				var $stagingFields = $( "input[name^=woocommerce_wepay_staging_]" ).closest( "tr" );
				if ( "staging" === $( this ).val() ) {
					$stagingFields.show();
				} else {
					$stagingFields.hide();
				}
			} ).change();
		' );
	}


	/**
	 * Deletes the API version option when saving gateway settings so a fresh check can be performed.
	 *
	 * @since 1.5.1
	 */
	public function process_admin_options() {

		parent::process_admin_options();

		delete_option( 'wc_' . $this->id . '_merchant_api_version' );
	}


	/** Checkout/Processing Methods ******************************************************/


	/**
	 * Determines if the gateway settings are properly configured.
	 *
	 * @since 1.5.1
	 * @return bool
	 */
	public function is_configured() {

		if ( ! $this->get_client_id() || ! $this->get_client_secret() || ! $this->get_access_token() || ! $this->get_account_id() ) {
			return false;
		} else {
			return true;
		}
	}


	/**
	 * Checks for proper gateway configuration (required fields populated, etc)
	 * and that there are no missing dependencies
	 *
	 * @since 1.0
	 */
	public function is_available() {

		// is enabled check
		$is_available = parent::is_available();

		// proper configuration
		if ( ! $this->is_configured() ) {
			$is_available = false;
		}

		// all dependencies met
		if ( count( wc_wepay()->get_missing_dependencies() ) > 0 ) {
			$is_available = false;
		}

		if ( ! $this->is_api_compatible() ) {
			$is_available = false;
		}

		return apply_filters( 'wc_gateway_wepay_is_available', $is_available );
	}


	/**
	 * Determines if the merchant account's API version is compatible with this integration.
	 *
	 * @since 1.5.1
	 * @return bool
	 */
	public function is_api_compatible() {

		$api_version = get_option( 'wc_' . $this->id . '_merchant_api_version' );

		if ( ! $api_version ) {

			// default to this integration's known version
			$api_version = self::API_VERSION;

			// attempt to retrieve the API version set in the merchant's account
			try {

				$app_response = $this->get_api()->request( 'app', array(
					'client_id'     => $this->get_client_id(),
					'client_secret' => $this->get_client_secret(),
				) );

				if ( isset( $app_response->api_version ) ) {
					$api_version = $app_response->api_version;
				}

				update_option( 'wc_' . $this->id . '_merchant_api_version', $api_version );

			} catch ( WePayException $e ) {

				$this->add_debug_message( 'Could not retrieve API version. Using version ' . $api_version );
			}
		}

		return $api_version <= self::API_VERSION;
	}


	/**
	 * Add selected card icons to payment method label, defaults to Visa/MC/Amex/Discover
	 *
	 * @since 1.0
	 */
	public function get_icon() {

		$icon = '';

		if ( $this->icon ) :

			// use icon provided by filter
			$icon = '<img src="' . esc_url( WC_HTTPS::force_https_url( $this->icon ) ) . '" alt="' . esc_attr( $this->title ) . '" />';

		elseif ( ! empty( $this->card_types ) ) :

			// display icons for the selected card types
			foreach ( $this->card_types as $card_type ) {

				if ( is_readable( wc_wepay()->get_plugin_path() . '/assets/images/card-' . strtolower( $card_type ) . '.png' ) )
					$icon .= '<img src="' . esc_url( WC_HTTPS::force_https_url( wc_wepay()->get_plugin_url() ) . '/assets/images/card-' . strtolower( $card_type ) . '.png' ) . '" alt="' . esc_attr( strtolower( $card_type ) ) . '" />';
			}

		endif;

		return apply_filters( 'woocommerce_gateway_icon', $icon, $this->id );
	}


	/**
	 * Show the accepted payment type icons
	 *
	 * @since 1.0
	 */
	public function payment_fields() {

		parent::payment_fields();
		?><style type="text/css">#payment ul.payment_methods li label[for='payment_method_wepay'] img:nth-child(n+2) { margin-left:1px; }</style><?php
	}


	/**
	 * Process the payment by redirecting customer to WePay or the iFrame pay page
	 *
	 * @since 1.0
	 * @param int $order_id the order to process
	 * @throws Exception API or payment error
	 * @return array
	 */
	public function process_payment( $order_id ) {

		// setup order
		$order = wc_get_order( $order_id );

		$api_version = get_option( 'wc_' . $this->id . '_merchant_api_version' );

		try {

			$request_params = array(
				'account_id'        => $this->get_account_id(),
				'amount'            => SV_WC_Helper::number_format( $order->get_total() ),
				/* translators: Placeholders: %1$s - site name, %2$s - order number */
				'short_description' => SV_WC_Helper::str_truncate( sprintf( __( '%1$s - Order - %2$s', 'woocommerce-gateway-wepay' ), wp_specialchars_decode( get_bloginfo( 'name' ) ), $order->get_order_number() ), 255 ),
				'type'              => strtolower( $this->transaction_type ),
				'hosted_checkout'   => array(
					'redirect_uri' => $this->get_return_url( $order ),
					'mode'         => ( $this->is_iframe_checkout() ) ? 'iframe' : 'regular',
					'prefill_info' => array(
						'name'         => SV_WC_Helper::str_truncate( $order->get_formatted_billing_full_name(), 255 ),
						'email'        => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_email' ), 255 ),
						'phone_number' => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_phone' ), 15 ),
					),
				),
				'callback_uri'      => add_query_arg( array( 'wc-api' => get_class( $this ), 'order_id' => SV_WC_Order_Compatibility::get_prop( $order, 'id' ) ), home_url( '/' ) ),
				'fee' => array(
					'fee_payer' => strtolower( $this->fee_payer ),
				),
				'reference_id'      => SV_WC_Helper::str_truncate( (string) $order->get_order_number(), 255 ),
				'currency'          => SV_WC_Order_Compatibility::get_prop( $order, 'currency', 'view' ),
			);

			// adjust the request data for deprecated API versions
			// version 2016-07-13 is when the biggest parameter change was made
			if ( $api_version < '2016-07-13' ) {

				$prefill_info = array(
					'address'      => SV_WC_Helper::str_truncate( trim( SV_WC_Order_Compatibility::get_prop( $order, 'billing_address_1' ) . ' ' . SV_WC_Order_Compatibility::get_prop( $order, 'billing_address_2' ) ), 255 ),
					'city'         => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_city' ), 30 ),
					'state'        => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_state' ), 2, '' ),
					'zip'          => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_postcode' ), 10 ),
					'country'      => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_country' ), 2, '' ),
				);

				// 'zip' and 'state' params are for US addresses only, while 'postcode' and 'region' are for non-US addresses only
				// do a little dance to fix that so WePay doesn't complain with 'Invalid parameter' errors
				// Note that 'postcode' and 'region' have different length limitations
				if ( 'US' !== SV_WC_Order_Compatibility::get_prop( $order, 'billing_country' ) ) {

					$request_params['hosted_checkout']['prefill_info']['postcode'] = SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_postcode' ), 14 );
					unset( $request_params['hosted_checkout']['prefill_info']['zip'] );

					$request_params['hosted_checkout']['prefill_info']['region'] = SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_state' ), 30 );
					unset( $request_params['hosted_checkout']['prefill_info']['state'] );
				}

			// otherwise, use the latest parameter formatting
			} else {

				$prefill_info = array(
					'address' => array(
						'address1'    => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_address_1' ), 60 ),
						'address2'    => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_address_2' ), 60 ),
						'city'        => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_city' ), 30 ),
						'region'      => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_state' ), 3, '' ),
						'postal_code' => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_postcode' ), 14 ),
						'country'     => SV_WC_Helper::str_truncate( SV_WC_Order_Compatibility::get_prop( $order, 'billing_country' ), 2, '' ),
					)
				);
			}

			$request_params['hosted_checkout']['prefill_info'] = array_merge( $request_params['hosted_checkout']['prefill_info'], $prefill_info );

			// log the request
			if ( 'log' === $this->debug_mode || 'both' === $this->debug_mode ) {
				wc_wepay()->log( sprintf( 'Request: %s', print_r( $request_params, true ) ) );
			}

			// start the checkout
			$response = $this->get_api()->request( 'checkout/create', $request_params );

			// payment error
			if ( isset( $response->error ) && isset( $response->error_description ) ) {
				/* translators: Placeholders: %1$s - error code, %2$s - error description */
				throw new Exception( sprintf( __( 'Error: %1$s - %2$s', 'woocommerce-gateway-wepay' ), $response->error, $response->error_description ) );
			}

			// missing require response elements
			if ( ! isset( $response->checkout_id ) || ! isset( $response->hosted_checkout->checkout_uri ) ) {
				throw new Exception ( __( 'Response Checkout ID or Checkout URI missing', 'woocommerce-gateway-wepay' ) );
			}

			WC()->cart->empty_cart();

			// save checkout ID/URI and API environment to order
			add_post_meta( SV_WC_Order_Compatibility::get_prop( $order, 'id' ), '_wc_wepay_checkout_id',  $response->checkout_id );
			add_post_meta( SV_WC_Order_Compatibility::get_prop( $order, 'id' ), '_wc_wepay_checkout_uri', $response->hosted_checkout->checkout_uri );
			add_post_meta( SV_WC_Order_Compatibility::get_prop( $order, 'id' ), '_wc_wepay_environment',  ( $this->is_staging_environment() ) ? 'staging' : 'production' );

			// if iFrame checkout is enabled, redirect to checkout->pay page, otherwise redirect to WePay for completion
			return array(
				'result'   => 'success',
				'redirect' => ( $this->is_iframe_checkout() ) ? $order->get_checkout_payment_url( true ) : $response->hosted_checkout->checkout_uri,
			);

		} catch ( WePayException $e ) {

			// log API errors
			$this->add_debug_message( $e->getMessage() );

			// fail the order
			$this->mark_order_as_failed( $order, $e->getMessage() );

		} catch ( Exception $e ) {

			// payment failed, fail order
			$this->mark_order_as_failed( $order, $e->getMessage() );
		}
	}


	/**
	 * Displays the WePay payment iFrame on the pay page
	 *
	 * @since 1.0
	 * @param int $order_id the order to process
	 */
	public function show_iframe_pay_page( $order_id ) {

		// get checkout URI to pass to wepay javascript
		$checkout_uri = get_post_meta( $order_id, '_wc_wepay_checkout_uri', true );

		if ( $checkout_uri ) :
			?>
				<div id="wepay_payment_wrapper"></div>
				<style>
					@media ( max-width: 650px ) {
						#wepay_checkout_iframe {
							width: 300px !important;
							height: 600px !important;
						}
					}
				</style>
				<script type="text/javascript" src="<?php echo $this->is_staging_environment() ? 'https://stage.wepay.com/min/js/iframe.wepay.js' : 'https://www.wepay.com/min/js/iframe.wepay.js'; ?>"></script>
				<script type="text/javascript">WePay.iframe_checkout( "wepay_payment_wrapper", "<?php echo esc_js( $checkout_uri ); ?>", { vertical : <?php echo ( wp_is_mobile() ? 'true' : 'false' ); ?> } );</script>
			<?php
		else :

			// show error message
			?><div class="woocommerce-error"><?php esc_html_e( 'An error occurred, please try again or try an alternate form of payment.', 'woocommerce-gateway-wepay' ); ?></div><?php

			// mark order as failed
			$order = wc_get_order( $order_id );
			$this->mark_order_as_failed( $order, __( 'Missing iFrame checkout URI', 'woocommerce-gateway-wepay' ) );

		endif;
	}


	/**
	 * Process WePay IPN
	 *
	 * @link https://stage.wepay.com/developer/reference/ipn
	 * @since 1.0
	 */
	public function process_ipn() {

		// verify checkout ID is present and valid
		if ( ! isset( $_POST['checkout_id'] ) || empty( $_POST['checkout_id']) ) {

			$this->add_debug_message( __( 'IPN: Checkout ID missing or empty!', 'woocommerce-gateway-wepay' ) );
			die;
		}

		// verify order ID is present and valid
		if ( ! isset( $_GET['order_id'] ) || empty( $_GET['order_id'] ) ) {

			$this->add_debug_message( __( 'IPN: Order ID missing or empty!', 'woocommerce-gateway-wepay' ) );
			die;
		}

		// get checkout ID
		$checkout_id = absint( $_POST['checkout_id'] );

		// get order ID
		$order_id = absint( $_GET['order_id'] );

		// setup order
		$order = wc_get_order( $order_id );

		// verify checkout ID matches the checkout ID saved to the order
		if ( $checkout_id !== ( absint( get_post_meta( SV_WC_Order_Compatibility::get_prop( $order, 'id' ), '_wc_wepay_checkout_id', true ) ) ) ) {

			$this->mark_order_as_failed( $order, sprintf( __( 'IPN: Checkout ID does not match checkout ID saved to Order ID: %s', 'woocommerce-gateway-wepay' ), SV_WC_Order_Compatibility::get_prop( $order, 'id' ) ) );
			die;
		}

		// get payment status information via WePay API
		$payment = $this->get_api()->request( 'checkout', array( 'checkout_id' => $checkout_id ) );

		// verify amount
		if ( $order->get_total() != $payment->amount ) {

			$this->mark_order_as_failed( $order, __( 'Order amounts do not match', 'woocommerce-gateway-wepay' ) );
			die;
		}

		// verify order has not already been completed
		if ( ! $order->needs_payment() ) {

			$this->add_debug_message( sprintf( __( "Order %s is already complete, aborting.", 'woocommerce-gateway-wepay' ), $order->get_order_number() ) );
			die;
		}

		// verify payment state - see https://stage.wepay.com/developer/reference/object_states
		if ( in_array( $payment->state, array( 'authorized', 'reserved', 'captured', 'released', 'settled' ) ) ) {

			// Payment completed
			$order->add_order_note( sprintf( __( 'WePay Payment completed, checkout ID: %s', 'woocommerce-gateway-wepay' ), $payment->checkout_id ) );
			$order->payment_complete();

			// Store Details
			update_post_meta( (int) $order_id, '_we_pay_account_id', $payment->account_id );

		} elseif ( 'failed' == $payment->state ) {

			// payment failed
			$this->mark_order_as_failed( $order, sprintf( __( 'Checkout ID: %s', 'woocommerce-gateway-wepay' ), $payment->checkout_id ) );
		}

		// send success
		header( 'HTTP/1.1 200 OK' );
	}


	/** Helper Methods ******************************************************/


	/**
	 * Instantiates and configures the WePay API object
	 *
	 * @since 1.0
	 * @return \WePay API object
	 */
	protected function get_api() {

		if ( is_object( $this->api ) ) {
			return $this->api;
		}

		// load WePay SDK
		require_once( wc_wepay()->get_plugin_path() . '/lib/wepay.php' );

		try {

			// setup API environment and credentials
			if ( $this->is_staging_environment() ) {
				Wepay::useStaging( $this->get_client_id(), $this->get_client_secret() );
			} else {
				Wepay::useProduction( $this->get_client_id(), $this->get_client_secret() );
			}

			// setup API object
			return $this->api = new WePay( $this->get_access_token() );

		} catch ( WePayException $e ) {
			$this->add_debug_message( $e->getMessage(), 'error' );
			return null;
		}
	}


	/**
	 * Mark the given order as failed and set the order note
	 *
	 * @since 1.0
	 * @param \WC_Order $order the order
	 * @param string $error_message a message to display inside the "WePay Payment Failed" order note
	 */
	protected function mark_order_as_failed( $order, $error_message ) {

		$order_note = sprintf( __( 'WePay Payment Failed (%s)', 'woocommerce-gateway-wepay' ), $error_message );

		// Mark order as failed if not already set, otherwise, make sure we add the order note so we can detect when someone fails to check out multiple times
		if ( ! $order->has_status( 'failed' ) ) {
			$order->update_status( 'failed', $order_note );
		} else {
			$order->add_order_note( $order_note );
		}

		// show generic error message to customer
		wc_add_notice( __( 'An error occurred, please try again or try an alternate form of payment.', 'woocommerce-gateway-wepay' ), 'error' );
	}


	/**
	 * Adds debug messages to the page as a WC message/error, and / or to the WC Error log
	 *
	 * @since 1.0
	 * @param string $message message to add
	 * @param string $type how to add the message, options are: 'message' (styled as WC message), 'error' (styled as WC Error)
	 * @param bool $set_message sets any WC messages/errors provided so they appear on the next page load, useful for display messages on the thank you page
	 */
	protected function add_debug_message( $message, $type = 'message', $set_message = false ) {

		// do nothing when debug mode is off
		if ( 'off' == $this->debug_mode ) {
			return;
		}

		// add debug message to woocommerce->errors/messages if checkout or both is enabled
		if ( 'checkout' === $this->debug_mode || 'both' === $this->debug_mode ) {

			if ( 'message' === $type ) {

				if ( ! is_admin() ) {
					wc_add_notice( $message );
				}

			} else {

				if ( ! is_admin() ) {
					// defaults to error message
					wc_add_notice( $message, 'error' );
				}
			}
		}

		// add log message to WC logger if log/both is enabled
		if ( 'log' === $this->debug_mode || 'both' === $this->debug_mode ) {
			wc_wepay()->log( $message );
		}
	}


	/** Getters ******************************************************/


	/**
	 * Returns whether the checkout mode is iframe or not
	 *
	 * @since 1.0
	 * @return bool true if iframe checkout is enabled, false otherwise
	 */
	protected function is_iframe_checkout() {

		return 'iframe' === $this->checkout_mode;
	}


	/**
	 * Returns whether the API environment is staging or not
	 *
	 * @since 1.0
	 * @return bool true if the API environment is set to staging, false otherwise
	 */
	private function is_staging_environment() {

		return 'staging' === $this->environment;
	}


	/**
	 * Returns the client ID for the current API environment
	 *
	 * @since 1.0
	 * @return string the client ID
	 */
	private function get_client_id() {

		return ( $this->is_staging_environment() ) ? $this->staging_client_id : $this->production_client_id;
	}


	/**
	 * Returns the client secret for the current API environment
	 *
	 * @since 1.0
	 * @return string the client secret
	 */
	private function get_client_secret() {

		return ( $this->is_staging_environment() ) ? $this->staging_client_secret : $this->production_client_secret;
	}


	/**
	 * Returns the access token for the current API environment
	 *
	 * @since 1.0
	 * @return string the access token
	 */
	private function get_access_token() {

		return ( $this->is_staging_environment() ) ? $this->staging_access_token : $this->production_access_token;
	}


	/**
	 * Returns the account ID for the current API environment
	 *
	 * @since 1.0
	 * @return string the account ID
	 */
	private function get_account_id() {

		return ( $this->is_staging_environment() ) ? $this->staging_account_id : $this->production_account_id;
	}


}
