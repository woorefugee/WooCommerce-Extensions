<?php

if ( ! class_exists( 'USExport_Playground' ) ) {

	class USExport_Playground
	{
		const DEFAULT_URL = 'http://www.bis.doc.gov/export_consolidated_list/consolidated_party_list_final.txt';
		const SEPARATOR   = "\r\n";
		const SKIP_ROWS   = 2;

		private $url;
		private $separator;
		private $skipRows;

		function __construct(
			$url       = self::DEFAULT_URL,
			$separator = self::SEPARATOR,
			$skipRows  = self::SKIP_ROWS
		) {
			$this->url       = $url;
			$this->separator = $separator;
			$this->skipRows  = $skipRows;
		}

		public function getUrl() {
			return $this->url;
		}

		public function parse( $callback ) {

			if( ! ini_get('allow_url_fopen') )
				return $this->parse_using_wp( $this->getUrl(), $this->separator, $this->skipRows, $callback );

			$file = fopen( $this->getUrl(), 'r' );

			if ( ! $file ) {
				throw new USExport_Unable_To_Open_File_Exception("Cannot open the url [ $this->getUrl() ].");
				exit;
			}

			$buffer      = '';
			$skippedRows = 0;

			while ( ! feof( $file ) ) {
				$buffer .= fgets( $file, 1024 );
				$lines  = explode( $this->separator, $buffer );
				$buffer = array_pop( $lines );

				foreach ($lines as $line) {
					if ( $skippedRows < $this->skipRows )
						$skippedRows++;
					elseif ( ! empty( $line ) )
						call_user_func( $callback, $line );
				}
			}

			if ( ! empty( $buffer ) )
				call_user_func( $callback, $buffer );

			fclose( $file );
		}

		private function parse_using_wp( $url, $separator, $skip_rows, $callback ) {
			echo "parsing $url<br/>";
			$response     = wp_remote_get( $url, array(
				'timeout' => 600
			) );

			if( is_wp_error( $response ) ) {
				$error_message = $response->get_error_message();
				die( "Something went wrong: $error_message" );
			}

			$skipped_rows = 0;

			foreach ( explode( $separator, $response['body'] ) as $line ) {
				if ( $skipped_rows < $skip_rows ) {
					$skipped_rows++;
					continue;
				}

				echo "processing line [ $line ]<br/>";
				call_user_func( $callback, $line );
			}
		}
	}

}

?>
