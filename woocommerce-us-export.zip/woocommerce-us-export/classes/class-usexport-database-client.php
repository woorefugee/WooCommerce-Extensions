<?php
if ( ! class_exists( 'USExport_Database_Client' ) ) {

	class USExport_Database_Client
	{
		private $link;

		private $wpdb;

		function __construct() {
			global $wpdb;

			$this->wpdb = $wpdb;
		}

		public function execute( $sql ) {

			if ( 0 === strpos( strtoupper( $sql ), 'SELECT COUNT' ) )
				return $this->wpdb->get_var( $sql );

			elseif ( 0 === strpos( strtoupper( $sql ), 'SELECT ' ) )
				return $this->wpdb->get_results( $sql );

			return $this->wpdb->query( $sql );
			// return mysqli_query( $this->link, $sql );
		}

		public function escape( $value ) {
			return $this->wpdb->escape( $value );
			// return mysqli_real_escape_string( $this->link, $value );
		}
	}

}
?>
