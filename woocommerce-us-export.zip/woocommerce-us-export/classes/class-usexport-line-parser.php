<?php

if ( ! class_exists( 'USExport_Line_Parser' ) ) {

	class USExport_Line_Parser
	{
		private static $captions = array(
			'Source List',
			'Entity Number',
			'SDN Type',
			'Programs',
			'Name',
			'Title',
			'Address',
			'City',
			'State/Province',
			'Postal Code',
			'Country',
			'Federal Register Notice',
			'Effective Date',
			'Date Lifted/Waived',
			'Standard Order',
			'License Requirement',
			'License Policy',
			'Call Sign',
			'Vessel Type',
			'Gross Tonnage',
			'Gross Register Tonnage',
			'Vessel Flag',
			'Vessel Owner',
			'Remarks/Owner',
			'Address Number',
			'Address Remarks',
			'Alternate Number',
			'Alternate Type',
			'Alternate Name',
			'Alternate Remarks',
			'WebLink'
		);

		public function parse( $line ) {
			$fields = explode( "\t", $line );
			$row    = array();

			for ( $i = 0; $i < count( $fields ); $i++ )
				$row[self::$captions[$i]] = $fields[$i];
		}
	}

}

?>
