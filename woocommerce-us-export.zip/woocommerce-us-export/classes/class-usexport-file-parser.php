<?php
if ( ! class_exists( 'USExport_File_Parser' ) ) {

	class USExport_File_Parser
	{
		const SEPARATOR = "\r\n";
		const SKIP_ROWS = 2;

		private $url;
		private $separator;
		private $skipRows;
		private $limit;

		function __construct(
			$url,
			$separator = self::SEPARATOR,
			$skipRows = self::SKIP_ROWS,
			$limit = -1
		) {
			$this->url = $url;
			$this->separator = $separator;
			$this->skipRows = $skipRows;
			$this->limit = $limit;
		}

		public function getUrl() {
			return $this->url;
		}

		public function parse( $callback ) {
			$file = fopen($this->getUrl(), 'r');

			if ( ! $file ) {
				throw new USExport_Unable_To_Open_File_Exception(
					"Cannot open the url [ $this->getUrl() ]."
				);
				exit;
			}

			$buffer      = '';
			$skippedRows = 0;
			$rowIndex    = 0;

			while ( ! feof( $file ) ) {

				$buffer .= fgets( $file, 1024 );
				$lines  =  explode( $this->separator, $buffer );
				$buffer =  array_pop( $lines );

				foreach ( $lines as $line ) {

					if ( $skippedRows < $this->skipRows )
						$skippedRows++;

					elseif ( ! empty( $line ) ) {
						call_user_func( $callback, $line );
						$rowIndex++;
					}

				}

				if ( -1 < $this->limit && $rowIndex === $this->limit )
					break;

			}

			if ( ! empty( $buffer ) )
				call_user_func( $callback, $buffer );

			fclose( $file );
		}
	}

}

?>
