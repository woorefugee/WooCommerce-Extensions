<?php

if ( ! class_exists( 'USExport_Unable_To_Open_File_Exception' ) ) {

	class USExport_Unable_To_Open_File_Exception extends Exception
	{

	}

}

?>
