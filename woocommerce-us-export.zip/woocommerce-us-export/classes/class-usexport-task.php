<?php

if ( ! class_exists( 'USExport_Task' ) ) {

	class USExport_Task
	{
		private $client;

		function __construct($client) {
			$this->client = $client;
		}

		public function createTables() {
			$this->createCountryCodes();
			$this->createUSExport();
		}

		public function importData() {
			$this->importCountryCodes();
			$this->importUSExport();
		}

		public function createCountryCodes() {
			global $wpdb;

			$table_name = $wpdb->prefix . 'country_codes'; 

			// $sql = "DROP TABLE IF EXISTS $table_name;";
			// $this->client->execute($sql);

			$sql = "CREATE TABLE $table_name (
						id bigint NOT NULL AUTO_INCREMENT,
						country varchar(255) DEFAULT NULL,
						code char(2) DEFAULT NULL,
						transient bit(1) DEFAULT b'0',
						UNIQUE KEY id (id)
				   ) DEFAULT CHARSET=utf8;";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );

			// $this->client->execute($sql);
		}

		public function createUSExport() {
			global $wpdb;

			$table_name = $wpdb->prefix . "us_export"; 

			// refer to http://codex.wordpress.org/Creating_Tables_with_Plugins
			// $sql = "DROP TABLE IF EXISTS $table_name;";
			// $this->client->execute( $sql );

			$sql = "CREATE TABLE $table_name (
					id bigint NOT NULL AUTO_INCREMENT,
					source_list varchar(255) DEFAULT NULL,
					entity_number varchar(255) DEFAULT NULL,
					sdn_type varchar(255) DEFAULT NULL,
					programs varchar(255) DEFAULT NULL,
					name varchar(255) DEFAULT NULL,
					title varchar(255) DEFAULT NULL,
					address varchar(255) DEFAULT NULL,
					city varchar(255) DEFAULT NULL,
					state_province varchar(255) DEFAULT NULL,
					postal_code varchar(255) DEFAULT NULL,
					country varchar(255) DEFAULT NULL,
					federal_register_notice varchar(255) DEFAULT NULL,
					effective_date varchar(255) DEFAULT NULL,
					date_lifted_waived date DEFAULT NULL,
					standard_order varchar(255) DEFAULT NULL,
					license_requirement varchar(255) DEFAULT NULL,
					license_policy varchar(255) DEFAULT NULL,
					call_sign varchar(255) DEFAULT NULL,
					vessel_type varchar(255) DEFAULT NULL,
					gross_tonnage varchar(255) DEFAULT NULL,
					gross_register_tonnage varchar(255) DEFAULT NULL,
					vessel_flag varchar(255) DEFAULT NULL,
					vessel_owner varchar(255) DEFAULT NULL,
					remarks_owner varchar(255) DEFAULT NULL,
					address_number varchar(255) DEFAULT NULL,
					address_remarks varchar(255) DEFAULT NULL,
					alternate_number varchar(255) DEFAULT NULL,
					alternate_type varchar(255) DEFAULT NULL,
					alternate_name varchar(255) DEFAULT NULL,
					alternate_remarks varchar(255) DEFAULT NULL,
					weblink varchar(1024) DEFAULT NULL,
					country_code char(2) DEFAULT NULL,
					transient bit(1) DEFAULT b'0',
					UNIQUE KEY id (id)
				) DEFAULT CHARSET=utf8;";
			// $this->client->execute( $sql );

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}

		public function importCountryCodes() {

			$countryCode           = new USExport_Country_Code( $this->client );

			$countryCodePlayground = new USExport_Playground(
				USExport_Country_Code::URL,
				USExport_Country_Code::LINE_SEPARATOR,
				USExport_Country_Code::SKIP_ROWS
			);

			$countryCodeLineParser = new USExport_Generic_Sql_Line_Parser(
				$countryCode->get_table_name(),
				array( 'country', 'code' ),
				USExport_Country_Code::FIELD_SEPARATOR,
				$this->client
			);

			$countryCodeTruncate = new USExport_Truncate(
				$this->client,
				$countryCode->get_table_name()
			);
			$countryCodeTruncate->markTransient();

			$countryCodePlayground->parse(
				array( $countryCodeLineParser, 'parse' )
			);

			$countryCodeTruncate->deleteTransient();
		}

		public function importUSExport() {

			$countryCode        = new USExport_Country_Code( $this->client );
			$usExportLineParser = new USExport_Sql_Line_Parser(
				$countryCode,
				$this->client
			);

			$usExportTruncate = new USExport_Truncate(
				$this->client,
				$usExportLineParser->get_table_name()
			);
			$usExportTruncate->markTransient();

			$usExportPlayground = new USExport_Playground();
			$usExportPlayground->parse(
				array( $usExportLineParser, 'parse' )
			); 
			$usExportTruncate->deleteTransient();
		}
	}

}

?>
