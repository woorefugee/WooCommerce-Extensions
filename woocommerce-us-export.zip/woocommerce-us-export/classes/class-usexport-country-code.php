<?php
if ( ! class_exists( 'USExport_Country_Code' ) ) {

	class USExport_Country_Code
	{
		const URL             = 'http://www.iso.org/iso/home/standards/country_codes/country_names_and_code_elements_txt.htm';
		const LINE_SEPARATOR  = "\r\n";
		const SKIP_ROWS       = 1;
		const FIELD_SEPARATOR = ';';

		private $substitutions = array(
			'BURMA' => 'MYANMAR',
			'COTE D IVOIRE' => "CÔTE D'IVOIRE",
			'HONG KONG SPECIAL ADMINISTRATIVE REGION' => 'HONG KONG',
			'KOSOVO' => 'SERBIA',
			'NETHERLANDS ANTILLES' => 'AN',
			'PALESTINIAN' => 'PALESTINE, STATE OF',
			'WEST BANK' => 'PALESTINE, STATE OF',
			'RUSSA' => 'RUSSIA',
			'THE GAMBIA' => 'GAMBIA'
		);

		private $client;
		private $table_name;

		function __construct( $client ) {
			global $wpdb;
			
			$this->table_name  = $wpdb->prefix . 'country_codes';
			$this->client = $client;
		}

		public function get_table_name() {
			return $this->table_name;
		}

		public function getCountryCode( $name ) {
			if ( empty( $name ) )
				return '';

			$keywords = $this->getKeywords( $name );
			foreach ($keywords as $keyword) {
				$keyword = strtoupper( $keyword );
				if ( array_key_exists( $keyword, $this->substitutions ) )
					$keyword = $this->substitutions[$keyword];

				if ( 2 === strlen( $keyword ) )
					return $keyword;

				$code = $this->queryCountryCode( $keyword );
				if ( null !== $code )
					return $code;

			}

			return null;
		}

		private function queryCountryCode( $name ) {

			$escName = $this->client->escape( $name );
			$sql     = "SELECT code FROM " . $this->table_name
				       . " WHERE UPPER(country) LIKE UPPER('$escName%')"
				       . " LIMIT 1";

			$result  = $this->client->execute( $sql );

			$code = null;
			if ( 1 === count( $result ) )
			{
				// $row  = $result->fetch_array();
				// $code = $row["code"];
				$code = $result[0]->code;
			}

			// echo "code: $code<br/>";

			return $code;
		}

		private function getKeywords( $name ) {
			$keywords = explode( ', ', $name );
			array_splice( $keywords, 0, 0, $name );
			return $keywords;
		}
	}

}
?>
