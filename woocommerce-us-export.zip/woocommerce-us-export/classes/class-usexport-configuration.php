<?php
if ( ! class_exists( 'USExport_Configuration' ) ) {

	class USExport_Configuration
	{
		const OPTION_RANK     = 'woocommerce_us_export_rank';
		const OPTION_SUBJECT  = 'woocommerce_us_export_subject';
		const OPTION_TO       = 'woocommerce_us_export_to';
		const OPTION_BODY     = 'woocommerce_us_export_body';

		const DEFAULT_RANK    = 0.45;
		const DEFAULT_SUBJECT = 'An order has been put on hold - WooCommerce';

		private $defaultTo;
		private $defaultBody;

		function __construct()
		{
			$this->defaultTo   = get_option( 'admin_email' );
			$this->defaultBody = "The order [orderno] has been put on hold as"
				. " it might not comply with the US Export regulations"
				. " ([rank]).\n"
				. "\n"
				. "Please review the order at the following address:\n"
				. "[orderurl]\n"
				. "\n"
				. "PS: this e-mail comes from an unmonitored account.\n"
				. "\n"
				. "Best Regards,\n"
				. "WooCommerce";
		}

		public function get() {
			$rankThreshold  = self::DEFAULT_RANK;
			$defaultSubject = self::DEFAULT_SUBJECT;
			$defaultTo      = $this->defaultTo;
			$defaultBody    = $this->defaultBody;

			return array(
				'rankThreshold' => get_option(
					self::OPTION_RANK,
					$this->getDefault( self::OPTION_RANK )
				),
				'to'            => get_option(
					self::OPTION_TO,
					$this->getDefault( self::OPTION_TO )
				)
				,
				'subject'       => get_option(
					self::OPTION_SUBJECT,
					$this->getDefault( self::OPTION_SUBJECT )
				),
				'message'       => get_option(
					self::OPTION_BODY,
					$this->getDefault( self::OPTION_BODY )
				)
			);
		}

		public function getDefault( $name ) {
			switch ( $name ) {
				case self::OPTION_RANK:
					return self::DEFAULT_RANK;

				case self::OPTION_SUBJECT:
					return self::DEFAULT_SUBJECT;

				case self::OPTION_TO:
					return $this->defaultTo;

				case self::OPTION_BODY:
					return $this->defaultBody;

			}
		}
	}

}
?>
