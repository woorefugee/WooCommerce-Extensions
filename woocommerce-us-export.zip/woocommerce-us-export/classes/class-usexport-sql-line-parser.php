<?php

if ( ! class_exists( 'USExport_Sql_Line_Parser' ) ) {

	class USExport_Sql_Line_Parser
	{
		const COUNTRY_INDEX = 10;
		
		private static $sqlColumns = array(
			'source_list',
			'entity_number',
			'sdn_type',
			'programs',
			'name',
			'title' ,
			'address' ,
			'city' ,
			'state_province' ,
			'postal_code' ,
			'country' ,
			'federal_register_notice' ,
			'effective_date' ,
			'date_lifted_waived' ,
			'standard_order' ,
			'license_requirement' ,
			'license_policy' ,
			'call_sign' ,
			'vessel_type' ,
			'gross_tonnage' ,
			'gross_register_tonnage' ,
			'vessel_flag' ,
			'vessel_owner' ,
			'remarks_owner' ,
			'address_number' ,
			'address_remarks' ,
			'alternate_number' ,
			'alternate_type' ,
			'alternate_name' ,
			'alternate_remarks' ,
			'weblink'
		);

		private $countryCode;
		private $client;
		private $table_name;


		function __construct( $countryCode, $client = null )
		{
			global $wpdb;

			$this->table_name  = $wpdb->prefix . "us_export";

			$this->countryCode = $countryCode;
			$this->client      = $client;
		}

		public function get_table_name() {
			return $this->table_name;
		}

		public function parse( $line ) {

			$fields      = explode( "\t", $line );
			$fieldsCount = count( $fields );

			$sql       = 'INSERT INTO ' . $this->table_name . '(';
			$sqlValues = ' values(';

			for ( $i = 0; $i < $fieldsCount; $i++ ) {
				$sql   .= self::$sqlColumns[$i] . ( $i < ( $fieldsCount - 1 ) ? ',' : '' );
				$value = $fields[$i];

				if (
					'date_lifted_waived' === self::$sqlColumns[$i]
					&& ! empty( $value )
				) {
					try {
						$date = DateTime::createFromFormat( 'm/d/Y', $value );
						$value = (
							false === $date
							? '0000-00-00'
							: $date->format( 'Y-m-d' )
						);
					} catch ( Exception $e ) {
						echo $value . ' is invalid<br/>';
						$value = '0000-00-00';
					}
				}

				$sqlValues .= "'" . $this->sanitize( $value ) . "'" . ( $i < ( $fieldsCount - 1 ) ? ',' : '' );
			}

			$country   = $this->trimQuotes( $fields[self::COUNTRY_INDEX] );
			$code      = $this->countryCode->getCountryCode( $country );

			$sql       .= ', country_code, transient)';
			$sqlValues .= ", '" . $this->sanitize($code) . "', 0);";

			$sql       .= $sqlValues;

			if ( null !== $this->client )
				$this->client->execute($sql);

		}

		private function sanitize( $value ) {

			$value = $this->trimQuotes( $value );
			return str_replace( "'", "\\'", $value );
		}

		private function trimQuotes( $value ) {
			if ( 0 === strpos( $value, '"' ) )
				$value = substr( $value, 1 );

			if ( '"' === substr( $value, -1 ) )
				$value = substr( $value, 0, -1 );

			return $value;
		}
	}

}

?>
