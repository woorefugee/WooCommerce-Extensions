<?php

if ( ! class_exists( 'USExport_Matcher' ) ) {

	class USExport_Matcher
	{
		private $client;
		private $table_name;

		const MAX_SCORE = 19.0;

		private $fields = array(
			'country_code' => array(
				'sqlColumns' => array( 'country_code' ),
				'comparison' => 'exact',
				'rank'       => 1,
				'isName'     => false
			),
			'state'        => array(
				'sqlColumns' => array( 'state_province' ),
				'comparison' => 'exact',
				'rank'       => 1,
				'isName'     => false
			),
			'city'         => array(
				'sqlColumns' => array( 'city' ),
				'comparison' => 'startsWith',
				'rank'       => 1,
				'isName'     => false
			),
			'address'      => array(
				'sqlColumns' => array( 'address' ),
				'comparison' => 'contained',
				'rank'       => 4,
				'isName'     => false
			),
			'name_1'       => array(
				'sqlColumns' => array( 'name', 'alternate_name' ),
				'comparison' => 'spaceAsWildcards',
				'rank'       => 5,
				'isName'     => true
			),
			'name_2'       => array(
				'sqlColumns' => array( 'name', 'alternate_name' ),
				'comparison' => 'spaceAsWildcards',
				'rank'       => 5,
				'isName'     => true
			),
			'company'      => array(
				'sqlColumns' => array( 'name', 'alternate_name' ),
				'comparison' => 'startsWith',
				'rank'       => 5,
				'isName'     => false
			),
			'postal_code'  => array(
				'sqlColumns' => array( 'postal_code', 'city' ),
				'comparison' => 'contained',
				'rank'       => 2,
				'isName'     => false
			)
		);

		function __construct( $client ) {
			global $wpdb;

			$this->table_name = $wpdb->prefix . "us_export";
			$this->client     = $client;
		}

		public function match( $element ) {
			$rank        = 0.0;
			$fields      = $this->fields;
			$nameMatched = false;

			while ( null !== ( $field = key( $fields ) ) ) {

				if ( $fields[$field]['isName'] && $nameMatched ) {
					next($fields);
					continue;
				}

				if (
					$this->matchField(
						$field,
						$fields[$field]['sqlColumns'],
						$fields[$field]['comparison'],
						$element
					)
				) {
					// echo('[ field :: $field ][ value :: $element[$field] ][ match: yes ]\n');
					$rank = $rank + $fields[$field]['rank'];

					if ($fields[$field]['isName'])
						$nameMatched = true;

				}

				next( $fields );
			}

			return ( $rank / self::MAX_SCORE );
		}

		private function matchField( $field, $sqlColumns, $comparison, $element ) {

			if ( ! array_key_exists( $field, $element ) )
				return 0;

			$value = trim( $element[$field] );
			if ( empty( $value ) )
				return 0;

			$escValue = $this->client->escape( $value );

			if ( 'startsWith' === $comparison || 'contained' === $comparison )
				$escValue .= '%';

			if ( 'endsWith' === $comparison || 'contained' === $comparison )
				$escValue = '%' . $escValue;

			if ( 'spaceAsWildcards' === $comparison )
				$escValue = str_replace(' ', '%', $escValue);

			$sql = 'SELECT COUNT(*) FROM ' . $this->table_name
				. ' WHERE ('
				. "  (date_lifted_waived = '0000-00-00'"
				. ' OR now() < date_lifted_waived) AND ';

			$columnsCount = count( $sqlColumns );
			
			for ( $i = 0; $i < $columnsCount; $i++ ) {
				$sqlColumn = $sqlColumns[$i];
				$sql       .= (0 < $i ? ' OR ' : '')
					          . "UPPER($sqlColumn) LIKE UPPER('"
					          . $escValue . "')";
			}

			$sql .= ')';

			$count = $this->client->execute( $sql );

			// echo "sql: $sql<br/>count: $count<br/>";
			// $row    = $result->fetch_array();
			// $count  = $row[0];

			return ( 0 < $count );

		}
	}

}
?>
