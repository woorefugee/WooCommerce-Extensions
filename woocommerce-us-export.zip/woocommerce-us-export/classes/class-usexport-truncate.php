<?php

if ( ! class_exists( 'USExport_Truncate' ) ) {

	class USExport_Truncate
	{
		private $client;
		private $tableName;

		function __construct( $client, $tableName )
		{
			$this->client    = $client;
			$this->tableName = $tableName;
		}

		public function markTransient() {
			$sql = 'UPDATE ' . $this->tableName
				   . ' SET transient = 1';
			$this->client->execute( $sql );
		}

		public function deleteTransient() {
			$sql = 'DELETE FROM ' . $this->tableName
				   . ' WHERE transient = 1';
			$this->client->execute( $sql );
		}
	}

}

?>
