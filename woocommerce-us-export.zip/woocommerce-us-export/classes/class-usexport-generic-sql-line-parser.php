<?php
if ( ! class_exists( 'USExport_Generic_Sql_Line_Parser' ) ) {

	class USExport_Generic_Sql_Line_Parser
	{
		private $tableName;
		private $sqlColumns;
		private $separator;
		private $client;

		function __construct( $tableName, $sqlColumns, $separator, $client = null ) {
			$this->tableName  = $tableName;
			$this->sqlColumns = $sqlColumns;
			$this->separator  = $separator;
			$this->client     = $client;
		}

		public function parse( $line ) {
			$fields      = explode( $this->separator, $line );
			$fieldsCount = count( $fields );
			$row         = array();

			$sql         = 'INSERT INTO ' . $this->tableName . '(';
			$sqlValues   = ' values(';

			for ( $i = 0; $i < $fieldsCount; $i++ )
			{
				$sql       .= $this->sqlColumns[$i] . ($i < ($fieldsCount - 1) ? ',' : '');
				$sqlValues .= "'" . $this->sanitize($fields[$i]) . "'" . ($i < ($fieldsCount - 1) ? ',' : '');
			}

			$sql       .= ', transient)';
			$sqlValues .= ', 0);';

			$sql       .= $sqlValues;

			if ( null !== $this->client )
				$this->client->execute( $sql );

		}

		private function sanitize( $value ) {
			if ( 0 === strpos( $value, '"' ) )
				$value = substr( $value, 1 );

			if ( '"' === substr( $value, -1 ) )
				$value = substr( $value, 0, -1 );

			return str_replace( "'", "\\'", $value );
		}
	}

}

?>
