<?php

if ( ! class_exists( 'USExport_Notifier' ) ) {

	class USExport_Notifier
	{
		private $configuration;

		function __construct( $configuration ) {
			$this->configuration = $configuration;
		}

		public function notify( $order, $billingRank, $shippingRank ) {

			$to      = $this->configuration['to'];
			$subject = $this->configuration['subject'];
			$message = $this->configuration['message'];

			$message = str_replace(
				'[orderno]',
				$order->id,
				$message
			);

			$message = str_replace(
				'[rank]',
				$billingRank . ':' . $shippingRank,
				$message
			);

			$message = str_replace(
				'[orderurl]',
				admin_url("post.php?post=$order->id&action=edit"),
				$message
			);

			return wp_mail(
				$to,
				$subject,
				$message
			);
		}
	}

}

?>
