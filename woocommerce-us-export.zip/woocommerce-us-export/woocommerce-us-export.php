<?php
/*
Plugin Name: WooCommerce US Export
Plugin URI: http://www.insideout.io
Description: Match customer data against the US Export list
Version: 1.0.4
Author: InsideOut10
Author URI: http://www.insideout.io
License: (c) 2013-2014 InsideOut10
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) )
  require_once( 'woo-includes/woo-functions.php' );

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), '1ba6c70a7869a93d996b2cb31165998b', '216796' );

require_once 'classes/class-usexport-configuration.php';
require_once 'classes/class-usexport-country-code.php';
require_once 'classes/class-usexport-database-client.php';
require_once 'classes/class-usexport-file-parser.php';
require_once 'classes/class-usexport-generic-sql-line-parser.php';
require_once 'classes/class-usexport-line-parser.php';
require_once 'classes/class-usexport-matcher.php';
require_once 'classes/class-usexport-notifier.php';
require_once 'classes/class-usexport-playground.php';
require_once 'classes/class-usexport-sql-line-parser.php';
require_once 'classes/class-usexport-task.php';
require_once 'classes/class-usexport-truncate.php';
require_once 'classes/class-usexport-unable-to-open-file-exception.php';

require_once 'woocommerce-us-export-hooks.php';


add_action(
	'woocommerce_checkout_order_processed',
	'woocommerce_us_export_check_customer'
);

add_action(
	'before_woocommerce_pay',
	'woocommerce_us_export_check_customer'
);

function woocommerce_us_export_check_customer( $orderId ) {

	global $woocommerce;
	
	$skipOrderKeyCheck = false;

	if ( isset( $orderId ) )
	
		$skipOrderKeyCheck = true;
	
	else if ( isset($_GET['pay_for_order'] )
		&& isset( $_GET['order'] )
		&& isset( $_GET['order_id'] ) ) {

		// Pay for existing order
		$orderKey = urldecode( $_GET['order'] );
		$orderId = $_GET['order_id'];
	
	} else {
	
		$orderKey = ( isset( $_GET['key'] ) ? $_GET['key'] : null );
		$orderId  = ( isset( $_GET['order'] ) ? $_GET['order'] : null );

	}
	

	if ( $orderId > 0 ) {
		$order = new WC_Order( $orderId );

		if ( $order->order_key == $orderKey || $skipOrderKeyCheck ) {

			// $fields = &$order->order_custom_fields;
			$client  = new USExport_Database_Client();
			$matcher = new USExport_Matcher( $client );

			$data = array(
				'name_1'       => $order->billing_first_name . ' '
				                  . $order->billing_last_name,
				'name_2'       => $order->billing_last_name . ' '
							      . $order->billing_first_name,
				'company'      => $order->billing_company,
				'address'      => $order->billing_address_1,
				'city' 		   => $order->billing_city,
				'postal_code'  => $order->billing_postcode,
				'country_code' => $order->billing_country,
				'state'        => $order->billing_state
			);

			$billingRank = $matcher->match( $data );

			$data = array(
				'name_1'       => $order->shipping_first_name . ' '
					              . $order->shipping_last_name,
				'name_2'       => $order->shipping_last_name . ' '
					              . $order->shipping_first_name,
				'company'      => $order->shipping_company,
				'address'      => $order->shipping_address_1,
				'city'         => $order->shipping_city,
				'postal_code'  => $order->shipping_postcode,
				'country_code' => $order->shipping_country,
				'state'        => $order->shipping_state
			);

			$shippingRank       = $matcher->match( $data );

			$configuration      = new USExport_Configuration();
			$configurationArray = $configuration->get();
			$rankThreshold      = $configurationArray['rankThreshold'];

			if ( 
				$rankThreshold <= $shippingRank
				|| $rankThreshold <= $billingRank
			) {
				$order->add_order_note(
					'Some order data is incorrect and
					 needs manual review.'
				);
				$order->update_status(
					'on-hold',
					'Order needs manual processing.'
				);

				$woocommerce->add_error(
					'Some order data is incorrect'
					. ' and requires manual verification. Your order'
					. ' has'
					. ' been submitted to the support team, that will'
					. ' soon send you a follow-up.<br/><br/>'
					. ' Thanks for your patience.'
				);

				$notifier = new USExport_Notifier( $configurationArray );

				if ( 
					!$notifier->notify(
						$order,
						$billingRank,
						$shippingRank
					)
				) {
					$woocommerce->add_error( 'Cannot send notification.' );
				}

				$woocommerce->show_messages();
				// prevent the customer to retry immediately changing its data
				$woocommerce->cart->empty_cart();
				exit;
			}
		}
	}
}

function woocommerce_us_export_activation_notice()
{
	echo '<div class="updated">WooCommerce US Export will start'
         . ' importing the US Export data from the Internet...</div>';
}

function woocommerce_us_export_activate_plugin()
{
	$client = new USExport_Database_Client();
	$task   = new USExport_Task( $client );
	$task->createTables();

	wp_schedule_event( time(), 'daily', 'woocommerce_us_export_import_data' );

	add_action( 'admin_notices', 'woocommerce_us_export_activation_notice' );
}

function woocommerce_us_export_import_data_callback()
{
	$client = new USExport_Database_Client();
	$task   = new USExport_Task( $client );
	$task->importData();
}

function woocommerce_us_export_deactivate_plugin()
{
	wp_clear_scheduled_hook( 'woocommerce_us_export_import_data' );
}

register_activation_hook(
	__FILE__,
	'woocommerce_us_export_activate_plugin'
);
register_deactivation_hook(
	__FILE__,
	'woocommerce_us_export_deactivate_plugin'
);
add_action(
	'woocommerce_us_export_import_data',
	'woocommerce_us_export_import_data_callback'
);

add_action(
	'wp_ajax_us_export_import_data',
	'woocommerce_us_export_import_data_callback'
);

