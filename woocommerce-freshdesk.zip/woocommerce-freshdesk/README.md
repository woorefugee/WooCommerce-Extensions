woocommerce-freshdesk
=====================

A Freshdesk integration plugin for WooCommerce.

## Installation ##

* Upload plugin files to your plugins folder, or install using WordPress built-in Add New Plugin installer;
* Activate the plugin;
* Navigate to WooCommerce -> Integration -> Freshdesk;
* Fill the **Freshdesk URL** with your url, example `http://example.freshdesk.com/`;
* Get an API Key in your Freshdesk "User Profile" drop-down (top right corner of your helpdesk) -> Profile Settings -> Your API Key and fill the "API Key" plugin options field;
* To Enable the "Single Sign On" you must to go to Freshdesk Admin -> Security, enable the Single Sign On with Simple SSO;
 * Fill the "Remote login URL" with your "My Account" page link, example `http://yoursite.com/my-account/`.
 * Fill the "Remote logout URL" field with your customer logout endpoint/page, example `http://yoursite.com/my-account/customer-logout`.
 * Get your "Shared Secret" and fill the "SSO Shared Secret" plugin options field.	
