<?php
/**
 * WC_Shipping_New_Zealand_Post class.
 *
 * @extends WC_Shipping_Method
 */
class WC_Shipping_New_Zealand_Post extends WC_Shipping_Method {

	private $endpoints = array(
		'domestic'      => 'http://api.nzpost.co.nz/ratefinder/domestic/rating/v2',
		'international' => 'http://api.nzpost.co.nz/ratefinder/international.json'
	);
	private $services = array(

		// Domestic
		'parcel_post'               => 'ParcelPost',
		'parcel_post_fast'          => 'ParcelPost Fast',
		'parcel_post_tracked'       => 'ParcelPost Tracked',
		'parcel_post_tracked_zonal' => 'ParcelPost Tracked Zonal',
		'courier'                   => 'Courier',

		// New rates
		'STD' => 'Standard Parcel',
		'TRK' => 'Tracked Parcel',
		'COU' => 'Courier',
		'COS' => 'Courier & Signature',

		// International
		'TIEX'                => 'International Express Courier',
		'TIEC'                => 'International Economy Courier',
		'TIALP'               => 'International Air',
		'TIASPC'			  => 'International Air Small Parcel',

	);
	private $found_rates;
	private $rate_cache;

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		$this->id                 = 'new_zealand_post';
		$this->method_title       = __( 'New Zealand Post', 'woocommerce-shipping-new-zealand-post' );
		$this->method_description = __( 'The <strong>New Zealand Post</strong> extension obtains rates dynamically from the New Zealand Post API during cart/checkout.', 'woocommerce-shipping-new-zealand-post' );
		$this->init();
	}

    /**
     * init function.
     *
     * @access public
     * @return void
     */
    private function init() {
		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables
		$this->title           = isset( $this->settings['title'] ) ? $this->settings['title'] : $this->method_title;
		$this->availability    = isset( $this->settings['availability'] ) ? $this->settings['availability'] : 'all';
		$this->countries       = isset( $this->settings['countries'] ) ? $this->settings['countries'] : array();
		$this->origin          = isset( $this->settings['origin'] ) ? $this->settings['origin'] : '';
		$this->api_key         = empty( $this->settings['api_key'] ) ? '' : $this->settings['api_key'];
		$this->packing_method  = isset( $this->settings['packing_method'] ) ? $this->settings['packing_method'] : 'per_item';
		$this->boxes           = isset( $this->settings['boxes'] ) ? $this->settings['boxes'] : array();
		$this->custom_services = isset( $this->settings['services'] ) ? $this->settings['services'] : array();
		$this->offer_rates     = isset( $this->settings['offer_rates'] ) ? $this->settings['offer_rates'] : 'all';
		$this->debug           = isset( $this->settings['debug_mode'] ) ? $this->settings['debug_mode'] : 'no';
		$this->debug           = $this->debug == 'yes' ? true : false;
		$this->postage_type    = isset( $this->settings['postage_type'] ) ? $this->settings['postage_type'] : 'postage_only';

		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'clear_transients' ) );
	}

    /**
     * Output a message
     */
    public function debug( $message, $type = 'notice' ) {
    	if ( $this->debug ) {
    		wc_add_notice( $message, $type );
		}
    }

	/**
	 * environment_check function.
	 *
	 * @access public
	 * @return void
	 */
	private function environment_check() {
		$general_tab_link = admin_url( add_query_arg( array(
			'page'    => 'wc-settings',
			'tab'     => 'general',
		), 'admin.php' ) );

		if ( get_woocommerce_currency() != "NZD" ) {
			echo '<div class="error">
				<p>' . wp_kses( sprintf( __( 'New Zealand Post requires that the <a href="%s">currency</a> is set to NZ Dollars.', 'woocommerce-shipping-new-zealand-post' ), esc_url( $general_tab_link ) ), array( 'a' => array( 'href' => array() ) ) ) . '</p>
			</div>';
		} elseif ( WC()->countries->get_base_country() != "NZ" ) {
			echo '<div class="error">
				<p>' . wp_kses( sprintf( __( 'New Zealand Post requires that the <a href="%s">base country/region</a> is set to New Zealand.', 'woocommerce-shipping-new-zealand-post' ), esc_url( $general_tab_link ) ), array( 'a' => array( 'href' => array() ) ) ) . '</p>
			</div>';
		} elseif ( ! $this->origin && $this->enabled == 'yes' ) {
			echo '<div class="error">
				<p>' . __( 'New Zealand Post is enabled, but the origin postcode has not been set.', 'woocommerce-shipping-new-zealand-post' ) . '</p>
			</div>';
		}
	}

	/**
	 * admin_options function.
	 *
	 * @access public
	 * @return void
	 */
	public function admin_options() {
		// Check users environment supports this method
		$this->environment_check();

		// Show settings
		parent::admin_options();
	}

	/**
	 * generate_services_html function.
	 *
	 * @access public
	 * @return void
	 */
	function generate_services_html() {
		ob_start();
		?>
		<tr valign="top" id="service_options">
			<th scope="row" class="titledesc"><?php _e( 'Services', 'woocommerce-shipping-new-zealand-post' ); ?></th>
			<td class="forminp">
				<table class="new_zealand_post_services widefat">
					<thead>
						<th class="sort">&nbsp;</th>
						<th><?php _e( 'Service Code(s)', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th><?php _e( 'Name', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th><?php _e( 'Enabled', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						<th><?php echo sprintf( __( 'Price Adjustment (%s)', 'woocommerce-shipping-new-zealand-post' ), get_woocommerce_currency_symbol() ); ?></th>
						<th><?php _e( 'Price Adjustment (%)', 'woocommerce-shipping-new-zealand-post' ); ?></th>
					</thead>
					<tbody>
						<?php
							$sort = 0;
							$this->ordered_services = array();

							foreach ( $this->services as $code => $name ) {

								if ( isset( $this->custom_services[ $code ]['order'] ) ) {
									$sort = $this->custom_services[ $code ]['order'];
								}

								while ( isset( $this->ordered_services[ $sort ] ) )
									$sort++;

								$this->ordered_services[ $sort ] = array( $code, $name );

								$sort++;
							}

							ksort( $this->ordered_services );

							foreach ( $this->ordered_services as $value ) {
								$code = $value[0];
								$name = $value[1];
								?>
								<tr>
									<td class="sort"><input type="hidden" class="order" name="new_zealand_post_service[<?php echo $code; ?>][order]" value="<?php echo isset( $this->custom_services[ $code ]['order'] ) ? $this->custom_services[ $code ]['order'] : ''; ?>" /></td>
									<td><strong><?php echo $code; ?></strong></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo $code; ?>][name]" placeholder="<?php echo $name; ?> (<?php echo $this->title; ?>)" value="<?php echo isset( $this->custom_services[ $code ]['name'] ) ? $this->custom_services[ $code ]['name'] : ''; ?>" size="50" /></td>
									<td><input type="checkbox" name="new_zealand_post_service[<?php echo $code; ?>][enabled]" <?php checked( ( ! isset( $this->custom_services[ $code ]['enabled'] ) || ! empty( $this->custom_services[ $code ]['enabled'] ) ), true ); ?> /></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo $code; ?>][adjustment]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment'] ) ? $this->custom_services[ $code ]['adjustment'] : ''; ?>" size="4" /></td>
									<td><input type="text" name="new_zealand_post_service[<?php echo $code; ?>][adjustment_percent]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment_percent'] ) ? $this->custom_services[ $code ]['adjustment_percent'] : ''; ?>" size="4" /></td>
								</tr>
								<?php
							}
						?>
					</tbody>
				</table>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * generate_box_packing_html function.
	 *
	 * @access public
	 * @return void
	 */
	public function generate_box_packing_html() {
		ob_start();
		?>
		<tr valign="top" id="packing_options">
			<th scope="row" class="titledesc"><?php _e( 'Box Sizes', 'woocommerce-shipping-new-zealand-post' ); ?></th>
			<td class="forminp">
				<style type="text/css">
					.new_zealand_post_boxes td, .new_zealand_post_services td {
						vertical-align: middle;
						padding: 4px 7px;
					}
					.new_zealand_post_boxes th, .new_zealand_post_services th {
						padding: 9px 7px;
					}
					.new_zealand_post_boxes td input {
						margin-right: 4px;
					}
					.new_zealand_post_boxes .check-column {
						vertical-align: middle;
						text-align: left;
						padding: 0 7px;
					}
					.new_zealand_post_services th.sort {
						width: 16px;
					}
					.new_zealand_post_services td.sort {
						cursor: move;
						width: 16px;
						padding: 0 16px;
						cursor: move;
						background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAHUlEQVQYV2O8f//+fwY8gJGgAny6QXKETRgEVgAAXxAVsa5Xr3QAAAAASUVORK5CYII=) no-repeat center;
					}
				</style>
				<table class="new_zealand_post_boxes widefat">
					<thead>
						<tr>
							<th class="check-column"><input type="checkbox" /></th>
							<th><?php _e( 'Outer Length', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Outer Width', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Outer Height', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Inner Length', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Inner Width', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Inner Height', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Box Weight', 'woocommerce-shipping-new-zealand-post' ); ?></th>
							<th><?php _e( 'Max Weight', 'woocommerce-shipping-new-zealand-post' ); ?></th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th colspan="3">
								<a href="#" class="button plus insert"><?php _e( 'Add Box', 'woocommerce-shipping-new-zealand-post' ); ?></a>
								<a href="#" class="button minus remove"><?php _e( 'Remove selected box(es)', 'woocommerce-shipping-new-zealand-post' ); ?></a>
							</th>
							<th colspan="7">
								<small class="description"><?php _e( 'Items will be packed into these boxes depending based on item dimensions and volume. Outer dimensions will be passed to NZ Post, whereas inner dimensions will be used for packing. Items not fitting into boxes will be packed individually.', 'woocommerce-shipping-new-zealand-post' ); ?></small>
							</th>
						</tr>
					</tfoot>
					<tbody id="rates">
						<?php
							if ( $this->boxes ) {
								foreach ( $this->boxes as $key => $box ) {
									?>
									<tr>
										<td class="check-column"><input type="checkbox" /></td>
										<td><input type="text" size="5" name="boxes_outer_length[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['outer_length'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_outer_width[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['outer_width'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_outer_height[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['outer_height'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_length[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['inner_length'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_width[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['inner_width'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_inner_height[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['inner_height'] ); ?>" />mm</td>
										<td><input type="text" size="5" name="boxes_box_weight[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['box_weight'] ); ?>" />g</td>
										<td><input type="text" size="5" name="boxes_max_weight[<?php echo $key; ?>]" value="<?php echo esc_attr( $box['max_weight'] ); ?>" placeholder="20" />g</td>
									</tr>
									<?php
								}
							}
						?>
					</tbody>
				</table>
				<script type="text/javascript">

					jQuery(window).load(function(){

						jQuery('#woocommerce_new_zealand_post_packing_method').change(function(){

							if ( jQuery(this).val() == 'box_packing' )
								jQuery('#packing_options').show();
							else
								jQuery('#packing_options').hide();

							if ( jQuery(this).val() == 'weight' )
								jQuery('#woocommerce_new_zealand_post_max_weight').closest('tr').show();
							else
								jQuery('#woocommerce_new_zealand_post_max_weight').closest('tr').hide();

						}).change();

						jQuery('.new_zealand_post_boxes .insert').click( function() {
							var $tbody = jQuery('.new_zealand_post_boxes').find('tbody');
							var size = $tbody.find('tr').size();
							var code = '<tr class="new">\
									<td class="check-column"><input type="checkbox" /></td>\
									<td><input type="text" size="5" name="boxes_outer_length[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_outer_width[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_outer_height[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_length[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_width[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_inner_height[' + size + ']" />mm</td>\
									<td><input type="text" size="5" name="boxes_box_weight[' + size + ']" />g</td>\
									<td><input type="text" size="5" name="boxes_max_weight[' + size + ']" placeholder="20" />g</td>\
								</tr>';

							$tbody.append( code );

							return false;
						} );

						jQuery('.new_zealand_post_boxes .remove').click(function() {
							var $tbody = jQuery('.new_zealand_post_boxes').find('tbody');

							$tbody.find('.check-column input:checked').each(function() {
								jQuery(this).closest('tr').hide().find('input').val('');
							});

							return false;
						});

						// Ordering
						jQuery('.new_zealand_post_services tbody').sortable({
							items:'tr',
							cursor:'move',
							axis:'y',
							handle: '.sort',
							scrollSensitivity:40,
							forcePlaceholderSize: true,
							helper: 'clone',
							opacity: 0.65,
							placeholder: 'wc-metabox-sortable-placeholder',
							start:function(event,ui){
								ui.item.css('background-color','#f6f6f6');
							},
							stop:function(event,ui){
								ui.item.removeAttr('style');
								new_zealand_post_services_row_indexes();
							}
						});

						function new_zealand_post_services_row_indexes() {
							jQuery('.new_zealand_post_services tbody tr').each(function(index, el){
								jQuery('input.order', el).val( parseInt( jQuery(el).index('.new_zealand_post_services tr') ) );
							});
						};

					});

				</script>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * validate_box_packing_field function.
	 *
	 * @access public
	 * @param mixed $key
	 * @return void
	 */
	public function validate_box_packing_field( $key ) {
		if ( ! isset( $_POST['boxes_outer_length'] ) )
			return;

		$boxes_outer_length    = $_POST['boxes_outer_length'];
		$boxes_outer_width     = $_POST['boxes_outer_width'];
		$boxes_outer_height    = $_POST['boxes_outer_height'];
		$boxes_inner_length    = $_POST['boxes_inner_length'];
		$boxes_inner_width     = $_POST['boxes_inner_width'];
		$boxes_inner_height    = $_POST['boxes_inner_height'];
		$boxes_box_weight      = $_POST['boxes_box_weight'];
		$boxes_max_weight      = $_POST['boxes_max_weight'];

		$boxes = array();

		for ( $i = 0; $i < sizeof( $boxes_outer_length ); $i ++ ) {

			if ( $boxes_outer_length[ $i ] && $boxes_outer_width[ $i ] && $boxes_outer_height[ $i ] ) {

				$outer_dimensions = array_map( 'floatval', array( $boxes_outer_length[ $i ], $boxes_outer_height[ $i ], $boxes_outer_width[ $i ] ) );
				$inner_dimensions = array_map( 'floatval', array( $boxes_inner_length[ $i ], $boxes_inner_height[ $i ], $boxes_inner_width[ $i ] ) );

				sort( $outer_dimensions );
				sort( $inner_dimensions );

				$outer_length = $outer_dimensions[2];
				$outer_height = $outer_dimensions[0];
				$outer_width  = $outer_dimensions[1];

				$inner_length = $inner_dimensions[2];
				$inner_height = $inner_dimensions[0];
				$inner_width  = $inner_dimensions[1];

				if ( empty( $inner_length ) || $inner_length > $outer_length )
					$inner_length = $outer_length;

				if ( empty( $inner_height ) || $inner_height > $outer_height )
					$inner_height = $outer_height;

				if ( empty( $inner_width ) || $inner_width > $outer_width )
					$inner_width = $outer_width;

				$weight = floatval( $boxes_max_weight[ $i ] );

				$boxes[] = array(
					'outer_length' => $outer_length,
					'outer_width'  => $outer_width,
					'outer_height' => $outer_height,
					'inner_length' => $inner_length,
					'inner_width'  => $inner_width,
					'inner_height' => $inner_height,
					'box_weight'   => floatval( $boxes_box_weight[ $i ] ),
					'max_weight'   => $weight
				);
			}
		}

		return $boxes;
	}

	/**
	 * validate_services_field function.
	 *
	 * @access public
	 * @param mixed $key
	 * @return void
	 */
	public function validate_services_field( $key ) {
		$services         = array();
		$posted_services  = $_POST['new_zealand_post_service'];

		foreach ( $posted_services as $code => $settings ) {

			$services[ $code ] = array(
				'name'                  => woocommerce_clean( $settings['name'] ),
				'order'                 => woocommerce_clean( $settings['order'] ),
				'enabled'               => isset( $settings['enabled'] ) ? true : false,
				'adjustment'            => woocommerce_clean( $settings['adjustment'] ),
				'adjustment_percent'    => str_replace( '%', '', woocommerce_clean( $settings['adjustment_percent'] ) )
			);

		}

		return $services;
	}

	/**
	 * clear_transients function.
	 *
	 * @access public
	 * @return void
	 */
	public function clear_transients() {
		delete_transient( 'wc_nz_post_quotes' );
	}

    /**
     * init_form_fields function.
     *
     * @access public
     * @return void
     */
    public function init_form_fields() {
    	$this->form_fields  = array(
			'enabled'          => array(
				'title'           => __( 'Enable/Disable', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'checkbox',
				'label'           => __( 'Enable this shipping method', 'woocommerce-shipping-new-zealand-post' ),
				'default'         => 'no'
			),
			'title'            => array(
				'title'           => __( 'Method Title', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'description'     => __( 'This controls the title which the user sees during checkout.', 'woocommerce-shipping-new-zealand-post' ),
				'default'         => __( 'New Zealand Post', 'woocommerce-shipping-new-zealand-post' )
			),
			'origin'           => array(
				'title'           => __( 'Origin Postcode', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'description'     => __( 'Enter the postcode for the <strong>sender</strong>.', 'woocommerce-shipping-new-zealand-post' ),
				'default'         => ''
		    ),
		    'availability'  => array(
				'title'           => __( 'Method Availability', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => 'all',
				'class'           => 'availability',
				'options'         => array(
					'all'            => __( 'All Countries', 'woocommerce-shipping-new-zealand-post' ),
					'specific'       => __( 'Specific Countries', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
			'countries'        => array(
				'title'           => __( 'Specific Countries', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'multiselect',
				'class'           => 'chosen_select',
				'css'             => 'width: 450px;',
				'default'         => '',
				'options'         => WC()->countries->get_allowed_countries(),
			),
		    'api'           => array(
				'title'           => __( 'API Settings', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'title',
				'description'     => __( 'Your API access details are obtained from the NZ Post website after signing up.', 'woocommerce-shipping-new-zealand-post' ),
		    ),
		    'api_key'           => array(
				'title'           => __( 'API Key', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'text',
				'default'         => '',
				'placeholder'	  => ''
		    ),
			'debug_mode'  => array(
				'title'           => __( 'Debug Mode', 'woocommerce-shipping-new-zealand-post' ),
				'label'           => __( 'Enable debug mode', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'checkbox',
				'default'         => 'yes',
				'description'     => __( 'Enable debug mode to show debugging information on your cart/checkout.', 'woocommerce-shipping-new-zealand-post' )
			),
		    'rates'           => array(
				'title'           => __( 'Rates and Services', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'title',
				'description'     => __( 'The following settings determine the rates you offer your customers.', 'woocommerce-shipping-new-zealand-post' ),
		    ),
			'packing_method'  => array(
				'title'           => __( 'Parcel Packing Method', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => '',
				'class'           => 'packing_method',
				'options'         => array(
					'per_item'       => __( 'Default: Pack items individually', 'woocommerce-shipping-new-zealand-post' ),
					'box_packing'    => __( 'Recommended: Pack into boxes with weights and dimensions', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
			'boxes'  => array(
				'type'            => 'box_packing'
			),
			'offer_rates'   => array(
				'title'           => __( 'Offer Rates', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'description'     => '',
				'default'         => 'all',
				'options'         => array(
				    'all'         => __( 'Offer the customer all returned rates', 'woocommerce-shipping-new-zealand-post' ),
				    'cheapest'    => __( 'Offer the customer the cheapest rate only, anonymously', 'woocommerce-shipping-new-zealand-post' ),
				),
		    ),
			'services'  => array(
				'type'            => 'services'
			),
			'postage_type' => array(
				'title'           => __( 'Postage Type', 'woocommerce-shipping-new-zealand-post' ),
				'type'            => 'select',
				'default'         => 'postage_only',
				'options'         => array(
				'postage_only'     => __( 'Returns rate without packaging fee', 'woocommerce-shipping-new-zealand-post' ),
				'postage_included' => __( 'Returns rate with packaging fee', 'woocommerce-shipping-new-zealand-post' ),
				''                 => __( 'Any', 'woocommerce-shipping-new-zealand-post' ),
				),
			),
		);
    }

	/**
	 * Is the postcode rural?
	 * NZ Post recommended this logic to determine if an address is rural.
	 *
	 * @return boolean
	 */
	public function is_rural( $postcode ) {
		$rural  = false;
		$first  = substr( $postcode, 0, 1 );
		$second = substr( $postcode, 1, 1 );
		$third  = substr( $postcode, 2, 1 );

		if ( in_array( $first, array( 1, 6, 8 ) ) ) {
			if ( 9 === $second && in_array( $third, array( 7, 8, 9 ) ) ) {
				$rural = true;
			}
		} else {
			if ( in_array( $third, array( 7, 8, 9 ) ) ) {
				$rural = true;
			}
		}

		return $rural;
	}


    /**
     * calculate_shipping function.
     *
     * @access public
     * @param mixed $package
     * @return void
     */
    public function calculate_shipping( $package = array() ) {
    	$this->found_rates = array();
    	$this->rate_cache  = get_transient( 'wc_nz_post_quotes' );
    	$package_requests  = $this->get_package_requests( $package );
    	$endpoint          = $package['destination']['country'] == 'NZ' ? $this->endpoints['domestic'] : $this->endpoints['international'];

    	$this->debug( __( 'NZ Post debug mode is on - to hide these messages, turn debug mode off in the settings.', 'woocommerce-shipping-new-zealand-post' ) );

    	if ( $package_requests ) {

	    	foreach ( $package_requests as $key => $package_request ) {

	    		$request  = http_build_query( array_merge( $package_request, $this->get_request( $package ) ), '', '&' );
	    		$response = $this->get_response( $endpoint, $request );

				if ( isset( $response->products ) && is_array( $response->products ) ) {

					// Loop our known services
					foreach ( $this->services as $code => $name ) {

						$rate_code    = $code;
						$rate_id      = $this->id . ':' . $rate_code;
						$rate_name    = $name . ' (' . __( 'NZ Post', 'woocommerce-shipping-new-zealand-post' ) . ')';
						$product_cost = 0;
						$rate_cost    = null;

						if ( 'NZ' === $package['destination']['country'] ) {
							foreach ( $response->products as $product ) {

								if ( isset( $product->price_excluding_gst ) ) {
									$product_cost = $product->price_excluding_gst;
								}

								foreach ( $product->services as $service ) {
									if ( $service->service_type == $code && ( $service->price_excluding_gst < $rate_cost || is_null( $rate_cost ) ) ) {
										$rate_cost = $product_cost + $service->price_excluding_gst;

										if ( $service->addons ) {
											foreach ( $service->addons as $addon ) {
												if ( 'RURALD' === $addon->addon_type ) {
													if ( $addon->mandatory || $this->is_rural( $package['destination']['postcode'] ) ) {
														$rate_cost += $addon->price_excluding_gst;
													}
												}
											}
										}
									}
								}
							}
						} else {
							foreach ( $response->products as $service ) {
								if ( isset( $product->price_excluding_gst ) ) {
									$product_cost = $product->price_excluding_gst;
								}

								if ( $service->service_code == $code && ( $service->price < $rate_cost || is_null( $rate_cost ) ) ) {
									$rate_cost = $product_cost + $service->price;
								}
							}
						}

						if ( $rate_cost ) {
							$this->prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $package_request );
						}
					}

				}

			}

	    }

		// Set transient
		set_transient( 'wc_nz_post_quotes', $this->rate_cache, YEAR_IN_SECONDS );

		// Ensure rates were found for all packages
		if ( $this->found_rates ) {
			foreach ( $this->found_rates as $key => $value ) {
				if ( $value['packages'] < sizeof( $package_requests ) )
					unset( $this->found_rates[ $key ] );
			}
		}

		// Add rates
		if ( $this->found_rates ) {

			if ( $this->offer_rates == 'all' ) {

				uasort( $this->found_rates, array( $this, 'sort_rates' ) );

				foreach ( $this->found_rates as $key => $rate ) {
					$this->add_rate( $rate );
				}

			} else {

				$cheapest_rate = '';

				foreach ( $this->found_rates as $key => $rate ) {
					if ( ! $cheapest_rate || $cheapest_rate['cost'] > $rate['cost'] )
						$cheapest_rate = $rate;
				}

				$cheapest_rate['label'] = $this->title;

				$this->add_rate( $cheapest_rate );
			}
		}

    }

    /**
     * prepare_rate function.
     *
     * @access private
     * @param mixed $rate_code
     * @param mixed $rate_id
     * @param mixed $rate_name
     * @param mixed $rate_cost
     * @return void
     */
    private function prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $package_request = '' ) {

	    // Name adjustment
		if ( ! empty( $this->custom_services[ $rate_code ]['name'] ) )
			$rate_name = $this->custom_services[ $rate_code ]['name'];

		// Cost adjustment %
		if ( ! empty( $this->custom_services[ $rate_code ]['adjustment_percent'] ) )
			$rate_cost = $rate_cost + ( $rate_cost * ( floatval( $this->custom_services[ $rate_code ]['adjustment_percent'] ) / 100 ) );

		// Cost adjustment
		if ( ! empty( $this->custom_services[ $rate_code ]['adjustment'] ) )
			$rate_cost = $rate_cost + floatval( $this->custom_services[ $rate_code ]['adjustment'] );

		// Enabled check
		if ( isset( $this->custom_services[ $rate_code ] ) && empty( $this->custom_services[ $rate_code ]['enabled'] ) )
			return;

		// Merging
		if ( isset( $this->found_rates[ $rate_id ] ) ) {
			$rate_cost = $rate_cost + $this->found_rates[ $rate_id ]['cost'];
			$packages  = 1 + $this->found_rates[ $rate_id ]['packages'];
		} else {
			$packages = 1;
		}

		// Sort
		if ( isset( $this->custom_services[ $rate_code ]['order'] ) ) {
			$sort = $this->custom_services[ $rate_code ]['order'];
		} else {
			$sort = 999;
		}

		$this->found_rates[ $rate_id ] = array(
			'id'       => $rate_id,
			'label'    => $rate_name,
			'cost'     => $rate_cost,
			'sort'     => $sort,
			'packages' => $packages
		);
    }

    /**
     * get_response function.
     *
     * @access private
     * @param mixed $endpoint
     * @param mixed $request
     * @return void
     */
    private function get_response( $endpoint, $request ) {
	    if ( isset( $this->rate_cache[ md5( $request ) ] ) ) {

	    	$response = $this->rate_cache[ md5( $request ) ];

    	} else {

	    	$response = wp_remote_get( $endpoint . '?' . $request,
	    		array(
					'timeout'          => 70,
					'sslverify'        => 0
			    )
			);

			$response = json_decode( $response['body'] );

			// Store result in case the request is made again
			$this->rate_cache[ md5( $request ) ] = $response;
		}

		$this->debug( 'NZ Post REQUEST: <pre>' . print_r( htmlspecialchars( $request ), true ) . '</pre>' );
		$this->debug( 'NZ Post RESPONSE: <pre>' . print_r( $response, true ) . '</pre>' );

		return $response;
    }

    /**
     * sort_rates function.
     *
     * @access public
     * @param mixed $a
     * @param mixed $b
     * @return void
     */
    public function sort_rates( $a, $b ) {
		if ( $a['sort'] == $b['sort'] ) return 0;
		return ( $a['sort'] < $b['sort'] ) ? -1 : 1;
    }

    /**
     * get_request function.
     *
     * @access private
     * @param mixed $package
     * @return void
     */
    private function get_request( $package ) {

	    $request = array(
			'api_key'         => $this->api_key,
			'format'          => 'json',
			'source_postcode' => str_replace( ' ', '', strtoupper( $this->origin ) )
	    );

		switch ( $package['destination']['country'] ) {
			case "NZ" :
				$request['dest_postcode']  = str_replace( ' ', '', strtoupper( $package['destination']['postcode'] ) );
			break;
			default :
				$request['country_code'] = $package['destination']['country'];
			break;
		}

		return $request;
    }

    /**
     * get_request function.
     *
     * @access private
     * @return void
     */
    private function get_package_requests( $package ) {

	    $requests = array();

	    // Choose selected packing
    	switch ( $this->packing_method ) {
	    	case 'box_packing' :
	    		$requests = $this->box_shipping( $package );
	    	break;
	    	case 'per_item' :
	    	default :
	    		$requests = $this->per_item_shipping( $package );
	    	break;
    	}

    	return $requests;
    }

    /**
     * per_item_shipping function.
     *
     * @access private
     * @param mixed $package
     * @return void
     */
    private function per_item_shipping( $package ) {
	    $requests = array();

    	// Get weight of order
    	foreach ( $package['contents'] as $item_id => $values ) {

    		if ( ! $values['data']->needs_shipping() ) {
    			$this->debug( sprintf( __( 'Product #%d is virtual. Skipping.', 'woocommerce-shipping-new-zealand-post' ), $item_id ) );
    			continue;
    		}

    		if ( ! $values['data']->get_weight() || ! $values['data']->length || ! $values['data']->height || ! $values['data']->width ) {
	    		$this->debug( sprintf( __( 'Product #%d is missing weight/dimensions. Aborting.', 'woocommerce-shipping-new-zealand-post' ), $item_id ), 'error' );
	    		return;
    		}

    		$dimensions = array( woocommerce_get_dimension( $values['data']->length, 'mm' ), woocommerce_get_dimension( $values['data']->height, 'mm' ), woocommerce_get_dimension( $values['data']->width, 'mm' ) );

			sort( $dimensions );

			$parcel                          = array();

			if ( $package['destination']['country'] === 'NZ' ) {
				$parcel['weight_in_grams']       = woocommerce_get_weight( $values['data']->get_weight(), 'g' );
				$parcel['height_in_millimetres'] = $dimensions[0];
				$parcel['width_in_millimetres']  = $dimensions[1];
				$parcel['length_in_millimetres'] = $dimensions[2];
				$parcel['postage_type']          = $this->postage_type;
			} else {
				$parcel['weight']    = woocommerce_get_weight( $values['data']->get_weight(), 'kg' );
				$parcel['thickness'] = $dimensions[0];
				$parcel['height']    = $dimensions[1];
				$parcel['length']    = $dimensions[2];
			}
			$parcel['value']                 = $values['data']->get_price();

			for ( $i = 0; $i < $values['quantity']; $i ++ ) {
				$requests[] = $parcel;
			}
    	}

		return $requests;
    }

    /**
     * box_shipping function.
     *
     * @access private
     * @param mixed $package
     * @return void
     */
    private function box_shipping( $package ) {
	    $requests = array();

	  	if ( ! class_exists( 'WC_Boxpack' ) )
	  		include_once 'box-packer/class-wc-boxpack.php';

	    $boxpack = new WC_Boxpack();

	    // Define boxes
		foreach ( $this->boxes as $key => $box ) {

			$newbox = $boxpack->add_box( $box['outer_length'], $box['outer_width'], $box['outer_height'], $box['box_weight'] );

			$newbox->set_id( $key );
			$newbox->set_inner_dimensions( $box['inner_length'], $box['inner_width'], $box['inner_height'] );

			if ( $box['max_weight'] )
				$newbox->set_max_weight( $box['max_weight'] );

		}

		// Add items
		foreach ( $package['contents'] as $item_id => $values ) {

			if ( ! $values['data']->needs_shipping() ) {
    			$this->debug( sprintf( __( 'Product # is virtual. Skipping.', 'woocommerce-shipping-new-zealand-post' ), $item_id ) );
    			continue;
    		}

			if ( $values['data']->length && $values['data']->height && $values['data']->width && $values['data']->weight ) {

				$dimensions = array( $values['data']->length, $values['data']->height, $values['data']->width );

				for ( $i = 0; $i < $values['quantity']; $i ++ ) {
					$boxpack->add_item(
						woocommerce_get_dimension( $dimensions[2], 'mm' ),
						woocommerce_get_dimension( $dimensions[1], 'mm' ),
						woocommerce_get_dimension( $dimensions[0], 'mm' ),
						woocommerce_get_weight( $values['data']->get_weight(), 'g' ),
						$values['data']->get_price()
					);
				}

			} else {
				wc_add_notice( sprintf( __( 'Product # is missing dimensions. Aborting.', 'woocommerce-shipping-new-zealand-post' ), $item_id ), 'error' );
				return;
			}
		}

		// Pack it
		$boxpack->pack();

		// Get packages
		$packed_packages = $boxpack->get_packages();

		foreach ( $packed_packages as $packed_package ) {

			$dimensions = array( $packed_package->length, $packed_package->width, $packed_package->height );

			sort( $dimensions );

    		$parcel                          = array();
    		if ( $package['destination']['country'] === 'NZ' ) {
				$parcel['weight_in_grams']       = $packed_package->weight;
				$parcel['height_in_millimetres'] = $dimensions[0];
				$parcel['width_in_millimetres']  = $dimensions[1];
				$parcel['length_in_millimetres'] = $dimensions[2];
				$parcel['postage_type']          = $this->postage_type;
			} else {
				$parcel['weight']    = $packed_package->weight * 0.001;
				$parcel['thickness'] = $dimensions[0];
				$parcel['height']    = $dimensions[1];
				$parcel['length']    = $dimensions[2];
			}
			$parcel['value'] = $packed_package->value;

    		$requests[] = $parcel;
		}

		return $requests;
    }

}
