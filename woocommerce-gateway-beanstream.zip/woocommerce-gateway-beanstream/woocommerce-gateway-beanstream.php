<?php
/**
 * Plugin Name: WooCommerce Beanstream Gateway
 * Plugin URI: http://www.woocommerce.com/products/beanstream/
 * Description: Extends WooCommerce. Provides a <a href="http://www.beanstream.com">Beanstream</a> payment gateway for WooCommerce.
 * Author: SkyVerge
 * Author URI: http://www.woocommerce.com/
 * Version: 1.11.1
 * Text Domain: wc-gateway-beanstream
 * Domain Path: /i18n/languages/
 *
 * Copyright: (c) 2014-2017, SkyVerge, Inc.
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-Gateway-Beanstream
 * @author    SkyVerge
 * @category  Gateways
 * @copyright Copyright (c) 2014-2017, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * Required functions
 */
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

/**
 * Plugin updates
 */
woothemes_queue_update( plugin_basename( __FILE__ ), '6fd78be05192c1c6eb4353833f106bb7', '18708' );

add_action( 'plugins_loaded', 'woocommerce_gateway_beanstream_init', 0 );

function woocommerce_gateway_beanstream_init() {

	/**
	 * Load plugin text domain.
	 *
	 * @since  1.7.2
	 */
	function woocommerce_gateway_beanstream_load_translation() {

			load_plugin_textdomain( 'wc-gateway-beanstream', false, dirname( plugin_basename( __FILE__ ) ) . '/i18n/languages' );
	}
	add_action( 'init', 'woocommerce_gateway_beanstream_load_translation' );


	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	class WC_Gateway_Beanstream extends WC_Payment_Gateway {


		private $require_state = array( 'US', 'CA' );


		public function __construct() {

			$this->id                 = 'beanstream';
			$this->method_title       = __('Beanstream', 'wc-gateway-beanstream');
			$this->method_description = __('Beanstream allows customers to checkout using a credit card', 'wc-gateway-beanstream');
			$this->logo               = untrailingslashit( plugins_url( '/', __FILE__ ) ) . '/images/beanstream.gif';
			$this->icon               = untrailingslashit( plugins_url( '/', __FILE__ ) ) . '/images/CreditCardLogos.png';
			$this->has_fields         = true;
			$this->gatewayurl         = 'https://www.beanstream.com/scripts/process_transaction.asp';

			// Load the form fields.
			$this->init_form_fields();

			// Load the settings.
			$this->init_settings();

			// Define user set variables
			$this->enabled          = $this->settings['enabled'];
			$this->title            = $this->settings['title'];
			$this->description      = $this->settings['description'];

			/**
			 * Filter the merchant ID
			 *
			 * @since 1.6.2
			 * @param $merchantid The merchant ID
			 */
			$this->merchantid       = apply_filters( 'wc_gateway_beanstream_merchantid', $this->settings['merchantid'] );

			$this->hashkey          = isset( $this->settings['hashkey'] ) ? $this->settings['hashkey'] : '';
			$this->preauthonly      = $this->settings['preauthonly'];
			$this->debugon          = $this->settings['debugon'];
			$this->debugrecipient   = $this->settings['debugrecipient'];
			$this->cardtypes        = $this->settings['cardtypes'];
			$this->displaycardtypes = $this->settings['displaycardtypes'];

			// Actions

			add_action( 'woocommerce_receipt_beanstream', array( $this, 'receipt_page' ) );
			add_action( 'admin_notices', array( $this, 'beanstream_ssl_check' ) );
			add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}

		/**
		 * Check if SSL is enabled and notify the user
		 */
		function beanstream_ssl_check() {

			if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'no' && $this->enabled == 'yes' ) {

				echo '<div class="error"><p>';
					/* translators: Placeholders: %1$s - <a> tag, %2$s - </a> tag */
					echo sprintf( __( 'Beanstream Payment Gateway is enabled and the %1$sForce secure checkout%2$s option is disabled; your checkout is not secure! Please enable this feature and ensure your server has a valid SSL certificate installed.', 'wc-gateway-beanstream' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) . '">',
						'</a>'
					);
				echo '</p></div>';
			}
		}


		/**
		 * Initialize Gateway Settings Form Fields
		 */
		function init_form_fields() {

			$this->form_fields = array(

				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-beanstream' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable Beanstream Gateway', 'wc-gateway-beanstream' ),
					'default' => 'no'
				),

				'title' => array(
					'title'       => __( 'Title', 'wc-gateway-beanstream' ),
					'type'        => 'text',
					'description' => __( 'The title which the user sees during checkout.', 'wc-gateway-beanstream' ),
					'default'     => __( 'Credit Card (Beanstream)', 'wc-gateway-beanstream' )
				),

				'description' => array(
					'title'       => __( 'Description', 'wc-gateway-beanstream' ),
					'type'        => 'textarea',
					'description' => __( 'This controls the description which the user sees during checkout.', 'wc-gateway-beanstream' ),
					'default'     => __('Pay securely by credit card.', 'wc-gateway-beanstream')
				),

				'merchantid' => array(
					'title'       => __( 'Merchant ID', 'wc-gateway-beanstream' ),
					'type'        => 'text',
					'description' => __( 'Please enter your Merchant ID as provided by Beanstream.', 'wc-gateway-beanstream' ),
					'default'     => ''
				),

				'hashkey' => array(
					'title'       => __( 'Hash Key', 'wc-gateway-beanstream' ),
					'type'        => 'text',
					'description' => __( 'Please enter your Hash Key as set in Beanstream.', 'wc-gateway-beanstream' ),
					'default'     => ''
				),

				'preauthonly' => array(
					'title'       => __( 'Pre Authorization Only', 'wc-gateway-beanstream' ),
					'type'        => 'checkbox',
					'description' => __( 'Preauthorize transactions. Orders would need to be finalized in your Beanstream account dashboard.', 'wc-gateway-beanstream' ),
					'default'     => 'no'
				),

				'displaycardtypes' => array(
					'title'       => __( 'Card Type Dropdown', 'wc-gateway-beanstream' ),
					'label'       => __( 'Enable display of card type drop down', 'wc-gateway-beanstream' ),
					'type'        => 'checkbox',
					'description' => __( 'Display the Card Types drop down on the checkout page.', 'wc-gateway-beanstream' ),
					'default'     => 'no'
				),

				'cardtypes'	=> array(
					'title'       => __( 'Accepted Cards', 'wc-gateway-beanstream' ),
					'type'        => 'multiselect',
					'description' => __( 'Select which card types to accept.', 'wc-gateway-beanstream' ),
					'default'     => '',
					'options'     => array(
						'MasterCard'       => 'MasterCard',
						'Visa'             => 'Visa',
						'Discover'         => 'Discover',
						'American Express' => 'American Express'
					),
				),

				'debugon' => array(
					'title'       => __( 'Debugging', 'wc-gateway-beanstream' ),
					'label'       => __( 'Enable debug emails', 'wc-gateway-beanstream' ),
					'type'        => 'checkbox',
					'description' => __( 'Receive emails containing the data sent to and from Beanstream.', 'wc-gateway-beanstream' ),
					'default'     => 'no'
				),

				'debugrecipient' => array(
					'title'       => __( 'Debugging Email', 'wc-gateway-beanstream' ),
					'type'        => 'text',
					'description' => __( 'Who should receive the debugging emails.', 'wc-gateway-beanstream' ),
					'default'     => get_option( 'admin_email' )
				),

			);

			/**
			 * Beanstream Credit Card Form Fields Filter.
			 *
			 * Allow actors to filter the settings form fields for the credit
			 * card method, e.g. for multi-currency
			 *
			 * @since 1.7.2
			 * @param array $form_fields settings
			 * @param \WC_Gateway_Beanstream $this instance
			 */
			$this->form_fields = apply_filters( 'wc_payment_gateway_beanstream_credit_card_form_fields', $this->form_fields, $this );

		} // End init_form_fields()


		/**
		 * Admin Panel Options
		 * - Options for bits like 'title' and availability on a country-by-country basis
		 *
		 * @since 1.0.0
		 */
		public function admin_options() {
			?>
			<p><a href="http://www.beanstream.com/" target="_blank"><img src="<?php echo $this->logo;?>" /></a></p>
			<h3>Beanstream Payments</h3>
			<p><?php _e('Beanstream allows customers to checkout using a credit card by adding credit card fields on the checkout page and then sending the details to Beanstream for verification.', 'woothemes'); ?></p>
			<p><a href="https://www.beanstream.com/admin" target="_blank">Beanstream Payment Gateway</a></p>
			<table class="form-table">
			<?php
				// Generate the HTML For the settings form.
				$this->generate_settings_html();
			?>
			</table><!--/.form-table-->
			<?php
		} // End admin_options()


		/**
		 * There are no payment fields for beanstream, but we want to show the description if set.
		 **/
		function payment_fields() {
			?>
			<fieldset>

				<p class="form-row form-row-first">
					<label for="beanstream_ccnum"><?php echo __("Credit card number", 'wc-gateway-beanstream') ?> <span class="required">*</span></label>
					<input type="text" class="input-text" id="beanstream_ccnum" name="beanstream_ccnum" />
				</p>

				<?php if ( $this->displaycardtypes == 'yes' ) { ?>
				<p class="form-row form-row-last">
					<label for="card type"><?php echo __("Card type", 'wc-gateway-beanstream') ?> <span class="required">*</span></label>
					<select name="beanstream_card_type" id="beanstream_card_type" class="woocommerce-select">
						<?php foreach( $this->cardtypes as $type ) : ?>
							<option value="<?php echo esc_attr( $type ) ?>"><?php _e($type, 'woocommerce'); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<?php } ?>

				<div class="clear"></div>

				<p class="form-row form-row-first">
					<label for="beanstream_expmonth"><?php echo __( "Expiration date", 'wc-gateway-beanstream' ) ?> <span class="required">*</span></label>
					<select name="beanstream_expmonth" id="beanstream_expmonth" class="woocommerce-select woocommerce-cc-month">
						<option value=""><?php _e( 'Month', 'wc-gateway-beanstream' ) ?></option>
						<?php
							$months = array(
								'01' => __( 'January', 'wc-gateway-beanstream' ),
								'02' => __( 'February', 'wc-gateway-beanstream' ),
								'03' => __( 'March', 'wc-gateway-beanstream' ),
								'04' => __( 'April', 'wc-gateway-beanstream' ),
								'05' => __( 'May', 'wc-gateway-beanstream' ),
								'06' => __( 'June', 'wc-gateway-beanstream' ),
								'07' => __( 'July', 'wc-gateway-beanstream' ),
								'08' => __( 'August', 'wc-gateway-beanstream' ),
								'09' => __( 'September', 'wc-gateway-beanstream' ),
								'10' => __( 'October', 'wc-gateway-beanstream' ),
								'11' => __( 'November', 'wc-gateway-beanstream' ),
								'12' => __( 'December', 'wc-gateway-beanstream' ),
							);

							foreach ($months as $num => $name) {
								/* translators: Placeholders: %1$s - month number, %2$s - month name */
								printf( '<option value="%1$s">%2$s</option>', esc_attr( $num ), esc_attr( $name ) );
							}
						?>
					</select>
					<select name="beanstream_expyear" id="beanstream_expyear" class="woocommerce-select woocommerce-cc-year">
						<option value=""><?php _e('Year', 'woocommerce') ?></option>
						<?php
							for ( $i = date('y'); $i <= date('y') + 15; $i++ ) {
								printf( '<option value="%u">20%u</option>', $i, $i );
							}
						?>
					</select>
				</p>
				<p class="form-row form-row-last">
					<label for="beanstream_cvv"><?php _e("Card security code", 'woocommerce') ?> <span class="required">*</span></label>
					<input type="text" class="input-text" id="beanstream_cvv" name="beanstream_cvv" maxlength="4" style="width:45px" />
				</p>

				<div class="clear"></div>
				<p><?php echo $this->description ?></p>
			</fieldset>
			<?php
		}


		/**
		 * Process the payment and return the result
		 **/
		function process_payment( $order_id ) {

			$order = wc_get_order( $order_id );

			// ************************************************
			// Create request

			$trnType = ( $this->preauthonly == 'yes' ) ? 'PA' : 'P';

			if ( ! in_array( $this->get_order_prop( $order, 'billing_country' ), $this->require_state ) ) {
				$ordProvince = '--';
			} else {
				$ordProvince = $this->get_order_prop( $order, 'billing_state' );
			}

			if ( ! in_array( $this->get_order_prop( $order, 'shipping_country' ), $this->require_state ) ) {
				$shipProvince = '--';
			} else {
				$shipProvince = $this->get_order_prop( $order, 'shipping_state' );
			}


			$beanstream_request = array(
				'merchant_id'     => $this->merchantid,
				'requestType'     => 'BACKEND',
				'trnType'         => $trnType,
				'trnOrderNumber'  => ltrim( $order->get_order_number(), '#' ),
				'trnAmount'       => $order->get_total(),
				'trnCardOwner'    => $order->get_formatted_billing_full_name(),
				'trnCardNumber'   => $this->get_post( 'beanstream_ccnum' ),
				'trnExpMonth'     => $this->get_post( 'beanstream_expmonth' ),
				'trnExpYear'      => $this->get_post( 'beanstream_expyear' ),
				'trnCardCvd'      => $this->get_post( 'beanstream_cvv' ),
				'ordName'         => $order->get_formatted_billing_full_name(),
				'ordAddress1'     => $this->get_order_prop( $order, 'billing_address_1' ),
				'ordAddress2'     => $this->get_order_prop( $order, 'billing_address_2' ),
				'ordCity'         => $this->get_order_prop( $order, 'billing_city' ),
				'ordProvince'     => $ordProvince,
				'ordCountry'      => $this->get_order_prop( $order, 'billing_country' ),
				'ordPostalCode'   => $this->get_order_prop( $order, 'billing_postcode' ),
				'ordPhoneNumber'  => $this->get_order_prop( $order, 'billing_phone' ),
				'ordEmailAddress' => $this->get_order_prop( $order, 'billing_email' ),
				'shipName'        => ( trim( $order->get_formatted_shipping_full_name() ) ) ? $order->get_formatted_shipping_full_name() : $order->get_formatted_billing_full_name(),
				'shipAddress1'    => $this->get_order_prop( $order, 'shipping_address_1' ),
				'shipAddress2'    => $this->get_order_prop( $order, 'shipping_address_2' ),
				'shipCity'        => $this->get_order_prop( $order, 'shipping_city' ),
				'shipProvince'    => $shipProvince,
				'shipPostalCode'  => $this->get_order_prop( $order, 'shipping_postcode' ),
				'shipCountry'     => $this->get_order_prop( $order, 'shipping_country' ),
				'customerIP'      => $this->get_order_prop( $order, 'customer_ip_address' ),
			);

			/**
			 * Beanstream Credit Card Legacy Request Data Filter.
			 *
			 * Allow actors to change the request data for a Beantream API request,
			 * e.g. for multi-currency
			 *
			 * @since 1.7.2
			 * @param array $beanstream_request request data
			 * @param \WC_Order $order order
			 * @param \WC_Gateway_Beanstream $this instance
			 */
			$beanstream_request = apply_filters( 'wc_beanstream_credit_card_legacy_request_data', $beanstream_request, $order, $this );

			$beanstream_debug_request = array(
				'merchant_id'     => $this->merchantid,
				'requestType'     => 'BACKEND',
				'trnType'         => $trnType,
				'trnOrderNumber'  => ltrim( $order->get_order_number(), '#' ),
				'trnAmount'       => $order->get_total(),
				'trnCardOwner'    => $order->get_formatted_billing_full_name(),
				'ordName'         => $order->get_formatted_billing_full_name(),
				'ordAddress1'     => $this->get_order_prop( $order, 'billing_address_1' ),
				'ordAddress2'     => $this->get_order_prop( $order, 'billing_address_2' ),
				'ordCity'         => $this->get_order_prop( $order, 'billing_city' ),
				'ordProvince'     => $ordProvince,
				'ordCountry'      => $this->get_order_prop( $order, 'billing_country' ),
				'ordPostalCode'   => $this->get_order_prop( $order, 'billing_postcode' ),
				'ordPhoneNumber'  => $this->get_order_prop( $order, 'billing_phone' ),
				'ordEmailAddress' => $this->get_order_prop( $order, 'billing_email' ),
				'shipName'        => ( trim( $order->get_formatted_shipping_full_name() ) ) ? $order->get_formatted_shipping_full_name() : $order->get_formatted_billing_full_name(),
				'shipAddress1'    => $this->get_order_prop( $order, 'shipping_address_1' ),
				'shipAddress2'    => $this->get_order_prop( $order, 'shipping_address_2' ),
				'shipCity'        => $this->get_order_prop( $order, 'shipping_city' ),
				'shipProvince'    => $this->get_order_prop( $order, 'shipping_state' ),
				'shipPostalCode'  => $this->get_order_prop( $order, 'shipping_postcode' ),
				'shipCountry'     => $this->get_order_prop( $order, 'shipping_country' ),
				'customerIP'      => $this->get_order_prop( $order, 'customer_ip_address' ),
			);

			$this->send_debugging_email( "Beanstream Gateway Request: " . "\n\nSENDING REQUEST:" . print_r( $beanstream_debug_request, true ) );


			// ************************************************
			// Send request

				error_reporting( E_ALL ^ E_NOTICE ^ E_WARNING );

				$post = '';

				foreach ( $beanstream_request as $key => $val ) {
					$post .= urlencode($key) . "=" . urlencode($val) . "&";
				}

				// remove the last &
				$post = substr( $post, 0, -1 );

				/**
				 * Beanstream Credit Card Legacy Hash Key Data Filter.
				 *
				 * Allow actors to change the hash key for a Beantream API request,
				 * e.g. for multi-currency.
				 *
				 * @since 1.10.2-dev.1
				 * @param string $hash_key
				 * @param \WC_Order $order the order object
				 * @param \WC_Gateway_Beanstream $gateway the gateway instance
				 */
				$hash_key = apply_filters( 'wc_beanstream_credit_card_legacy_hashkey', $this->hashkey, $order, $this );

				if ( $hash_key ) {

					// hash params
					$hash_params = $post . $hash_key;
					$hash_value  = md5( $hash_params );

					// add hash value
					$post .= '&hashValue=' . $hash_value;
				}

				$response = wp_safe_remote_post( $this->gatewayurl, array(
					'method'    => 'POST',
					'body'      => $post,
					'timeout'   => 70,
					'sslverify' => true,
				) );

				if ( is_wp_error( $response ) ) throw new Exception( __( 'There was a problem connecting to the payment gateway.', 'wc-gateway-beanstream' ) );

				if ( empty( $response['body'] ) ) throw new Exception( __( 'Empty Beanstream response.', 'wc-gateway-beanstream' ) );

				// prep response
				$content = explode( '&', $response['body'] );
				$data = array();

				foreach ( $content as $key => $val ) {
					$temp             = explode( "=", $val );
					$data[ $temp[0] ] = urldecode( $temp[1] );
				}
				$this->send_debugging_email( "Beanstream Gateway Response: \n\nRESPONSE:\n"
											. print_r($response,true)
											. "\n\nDATA:\n". print_r($data,true) . "\nPOST:\n" . $post);

				if ( isset( $data['cardType'] ) ) {

					$card_types = array(
						'VI' => 'Visa',
						'MC' => 'MasterCard',
						'AM' => 'American Express',
						'NN' => 'Discover',
						'DI' => 'Diners',
						'JB' => 'JCB',
						'IO' => 'INTERAC Online',
						'ET' => 'Direct Debit/Direct Payments/ACH',
					);

					$card_type = isset( $card_types[ $data['cardType'] ] ) ? $card_types[ $data['cardType'] ] : '';

					update_post_meta( $order_id, '_wc_beanstream_card_type', $card_type );
				}

			// ************************************************
			// Retreive response

				if ( $data['trnApproved'] == 1 ) {
					// Successful payment

					$order->add_order_note( __('Beanstream payment completed', 'wc-gateway-beanstream') . ' (Response Code: ' . $data['authCode'] . '| Message Text: '. $data['messageText'] . ')' );

					$transaction_id = ( isset( $data['trnId'] ) ) ? $data['trnId'] : '';

					$order->payment_complete( $transaction_id );

					WC()->cart->empty_cart();

					// Empty awaiting payment session
					unset( WC()->session->order_awaiting_payment );

					// Return thank you redirect
					return array(
						'result'   => 'success',
						'redirect' => $this->get_return_url( $order )
					);

				} else {

					$this->send_debugging_email( "BEANSTREAM ERROR:\nResponse_code:" . $data['messageText'] . "\nresponse_reason_text:" . $data['messageText'] );

					$cancelNote = __('Beanstream payment failed', 'wc-gateway-beanstream') . ' (Response Code: ' . $data['messageText'] . '). ' . __('Payment was rejected due to an error', 'wc-gateway-beanstream') . ': "' . $data['messageText'] . '". ';

					$order->add_order_note( $cancelNote );

					$this->debug( __('Payment error', 'wc-gateway-beanstream') . ': ' . $data['messageText'] . '', 'error' );

				}

		}


		/**
		 * Validate payment form fields
		 */

		public function validate_fields() {

			$cardNumber          = $this->get_post('beanstream_ccnum');
			$cardCSC             = $this->get_post('beanstream_cvv');
			$cardExpirationMonth = $this->get_post('beanstream_expmonth');
			$cardExpirationYear  = '20' . $this->get_post('beanstream_expyear');

			//check security code
			if( ! ctype_digit( $cardCSC ) ) {
				$this->debug( __( 'Card security code is invalid (only digits are allowed)', 'wc-gateway-beanstream' ), 'error' );
				return false;
			}

			//check expiration data
			$currentYear = date('Y');

			if( ! ctype_digit( $cardExpirationMonth ) || ! ctype_digit( $cardExpirationYear ) ||
				 $cardExpirationMonth > 12 ||
				 $cardExpirationMonth < 1 ||
				 $cardExpirationYear < $currentYear ||
				 $cardExpirationYear > $currentYear + 20
			) {
				$this->debug( __('Card expiration date is invalid', 'wc-gateway-beanstream'), 'error');
				return false;
			}

			//check card number
			$cardNumber = str_replace( array(' ', '-'), '', $cardNumber );

			if( empty( $cardNumber ) || ! ctype_digit( $cardNumber ) ) {
				$this->debug( __('Card number is invalid', 'wc-gateway-beanstream'), 'error');
				return false;
			}

			return true;
		}


		/**
		 * receipt_page
		 **/
		function receipt_page( $order ) {

			echo '<p>'.__('Thank you for your order.', 'wc-gateway-beanstream').'</p>';

		}


		/**
		 * Gets an order property.
		 *
		 * This method exists for WC 3.0 compatibility.
		 *
		 * @since 1.11.0
		 * @param \WC_Order $order the order object
		 * @param string $prop the property to get
		 * @return mixed the property value
		 */
		private function get_order_prop( WC_Order $order, $prop ) {

			$wc_version = defined( 'WC_VERSION' ) && WC_VERSION ? WC_VERSION : null;

			if ( $wc_version && version_compare( $wc_version, '3.0', '>=' ) && is_callable( array( $order, "get_{$prop}" ) ) ) {

				$value = $order->{"get_{$prop}"}( 'edit' );

				if ( ! $value && 0 === strpos( $prop, 'shipping_' ) ) {

					$prop = str_replace( 'shipping_', 'billing_', $prop );

					if ( is_callable( array( $order, "get_{$prop}" ) ) ) {
						$value = $order->{"get_{$prop}"}( 'edit' );
					}
				}

			} else {

				$value = $order->$prop;
			}

			return $value;
		}


		/**
		 * Get post data if set
		 **/
		private function get_post( $name ) {

			if( isset( $_POST[ $name ] ) ) {
				return $_POST[ $name ];
			}

			return null;
		}

		/**
		 * Output a message or error
		 * @param  string $message
		 * @param  string $type
		 */
		public function debug( $message, $type = 'notice' ) {
			wc_add_notice( $message, $type );
		}

		/**
		 * Send debugging email
		 **/
		private function send_debugging_email( $debug ) {

			if ( $this->debugon != 'yes' ) return; // Debug must be enabled
			if ( ! $this->debugrecipient ) return; // Recipient needed

			// Send the email
			wp_mail( $this->debugrecipient, __( 'Beanstream Debug', 'wc-gateway-beanstream' ), $debug );

		}

	} // class WC_Gateway_Beanstream

	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_beanstream_plugin_links' );

	/**
	 * Plugin page links
	 */
	function wc_beanstream_plugin_links( $links ) {

		$wc_version = defined( 'WC_VERSION' ) && WC_VERSION ? WC_VERSION : null;

		if ( $wc_version && version_compare( $wc_version, '2.6', '>=' ) ) {
			$section_id = 'beanstream';
		} else {
			$section_id = 'wc_gateway_beanstream';
		}

		$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $section_id ) ) . '">' . __( 'Settings', 'wc-gateway-beanstream' ) . '</a>';
		$links[] = '<a href="https://woocommerce.com/my-account/tickets/">' . __( 'Support', 'wc-gateway-beanstream' ) . '</a>';
		$links[] = '<a href="http://docs.woocommerce.com/document/beanstream/">' . __( 'Docs', 'wc-gateway-beanstream' ) . '</a>';

		return $links;
	}


}

/**
 * Add the gateway to WooCommerce
 **/
function add_beanstream_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Beanstream'; return $methods;
}

add_filter( 'woocommerce_payment_gateways', 'add_beanstream_gateway' );
