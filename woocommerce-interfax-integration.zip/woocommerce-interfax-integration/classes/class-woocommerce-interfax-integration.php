<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class WooCommerce_InterFax_Integration {
	private $dir;
	private $file;
	private $assets_dir;
	private $assets_url;
	private $settings;
	private $interfax_class;
	private $username;
	private $password;
	private $store_fax_number;
	private $template_html;
	private $heading;
	private $send_store_fax;
	private $order;
	private $fax_number;

	public function __construct( $file ) {
		$this->dir = dirname( $file );
		$this->file = $file;
		$this->assets_dir = trailingslashit( $this->dir ) . 'assets';
		$this->assets_url = esc_url( trailingslashit( plugins_url( '/assets/', $file ) ) );

		// Add settings link to plugin page
		add_filter( 'plugin_action_links_' . plugin_basename( $this->file ), array( $this, 'add_settings_link' ) );

		// Get integration settings
		$this->settings = get_option( 'woocommerce_interfax_settings' );

		// Only handle actions if integration is enabled
		if( $this->settings['wcif_enable'] == 'yes' ) {
			$this->interfax_class = 'http://ws.interfax.net/dfs.asmx?wsdl';
			$this->username = $this->settings['wcif_username'];
			$this->password = $this->settings['wcif_password'];
			$this->store_fax_number = $this->settings['wcif_fax_number'];
			$this->template_html = 'emails/customer-completed-order.php';
			$this->heading = __( 'Your order is complete', 'woocommerce' );
			$this->send_store_fax = true;

			// Add fax number field to checkout
			add_filter( 'woocommerce_checkout_fields', array( $this, 'add_checkout_field' ) );

			// Send fax on selected order status (deault to 'completed' if no status is selected)
			if( isset( $this->settings['wcif_fax_status'] ) ) {
				$fax_status = $this->settings['wcif_fax_status'];
			} else {
				$fax_status = 'wc-completed';
			}
			$fax_status = 'wc-' === substr( $fax_status, 0, 3 ) ? substr( $fax_status, 3 ) : $fax_status;

			add_action( 'woocommerce_order_status_' . $fax_status, array( $this, 'trigger' ) );

			// Add order action to dashboard
			add_filter( 'woocommerce_order_actions', array( $this, 'add_order_action' ) );

			// Handle order actions
			add_action( 'woocommerce_order_action_send_customer_fax', array( $this, 'process_order_action_customer' ) );
			add_action( 'woocommerce_order_action_send_store_fax', array( $this, 'process_order_action_store' ) );

			// Add fax number field to user profile page in WP dashboard
			add_filter( 'woocommerce_customer_meta_fields', array( $this, 'add_user_meta_field' ) );

			// Add fax number field to edit billing address page
			add_filter( 'woocommerce_billing_fields', array( $this, 'add_address_field' ), 10, 2 );
		}

		// Handle localisation
		$this->load_plugin_textdomain();
		add_action( 'init', array( $this, 'load_localisation' ), 0 );

	}

	public function trigger( $order_id ) {
		if ( $order_id ) {
			$this->order = new WC_Order( $order_id );

			// Send fax to store owner
			if( $this->store_fax_number && strlen( $this->store_fax_number ) > 0 ) {
				$this->send_store_fax();
			}

			// Send fax to customer
			$this->fax_number = get_post_meta( $order_id, '_billing_fax', true );
			if( $this->fax_number && strlen( $this->fax_number ) > 0 ) {
				$this->send_customer_fax();
			}
		}
	}

	private function send_customer_fax() {
		$interfax_client = new SoapClient( $this->interfax_class );

		$params = new stdClass();

		$params->Username  = $this->username;
		$params->Password  = $this->password;
		$params->FaxNumber = $this->fax_number;
		$params->Data      = $this->get_fax_content();
		$params->FileType  = 'HTML';

		$result = $interfax_client->SendCharFax( $params );

		if( isset( $result->SendCharFaxResult ) && $result->SendCharFaxResult > 0 ) {
			return true;
		}

		return false;
	}

	private function send_store_fax() {
		$interfax_client = new SoapClient( $this->interfax_class );

		$params = new stdClass();

		$params->Username  = $this->username;
		$params->Password  = $this->password;
		$params->FaxNumber = $this->store_fax_number;
		$params->Data      = $this->get_fax_content();
		$params->FileType  = 'HTML';

		$result = $interfax_client->SendCharFax( $params );

		if( isset( $result->SendCharFaxResult ) && $result->SendCharFaxResult > 0 ) {
			return true;
		}

		return false;
	}

	public function get_fax_content() {
		global $woocommerce;

		if ( class_exists( 'WC_Emails' ) ) {
			WC_Emails::instance();
		}

		ob_start();

		$template_data = array(
			'order' 		=> $this->order,
			'email_heading' => $this->heading,
			'sent_to_admin' => false,
			'plain_text'    => false,
		);

		if( version_compare( $woocommerce->version, '2.1', '>=' ) ) {
			wc_get_template( $this->template_html, $template_data );
		} else {
			woocommerce_get_template( $this->template_html, $template_data );
		}

		return ob_get_clean();
	}

	public function add_checkout_field( $fields ) {

		$fields['billing']['billing_fax'] = array(
			'label' 			=> __( 'Fax Number (including country code)', 'wc_interfax' ),
			'placeholder' 		=> _x( 'e.g. +27861234567', 'placeholder', 'wc_interfax' ),
			'required' 			=> false,
			'class' 			=> array( 'form-row' ),
			'clear'				=> false
		);

		return $fields;

	}

	public function add_order_action( $actions ) {
		$actions['send_customer_fax'] = 'Send customer fax';
		$actions['send_store_fax']    = 'Send store fax';
		return $actions;
	}

	public function process_order_action_customer( $order ) {
		$this->fax_number = get_post_meta( $order->id, '_billing_fax', true );
		if( $this->fax_number && strlen( $this->fax_number ) > 0 ) {
			$this->order = $order;
			$this->send_customer_fax();
		}
	}

	public function process_order_action_store( $order ) {
		if( $this->store_fax_number && strlen( $this->store_fax_number ) > 0 ) {
			$this->order = $order;
			$this->send_store_fax();
		}
	}

	public function add_user_meta_field( $fields ) {

		$fields['billing']['fields']['billing_fax'] = array(
			'label' => __( 'Fax number', 'wc_interfax' ),
			'description' => ''
		);

		return $fields;

	}

	public function add_address_field( $fields, $country ) {

		$fields['billing_fax'] = array(
			'label' 		=> __( 'Fax Number (including country code)', 'wc_interfax' ),
			'placeholder' 	=> _x( 'e.g. +27861234567', 'placeholder', 'wc_interfax' ),
			'required' 		=> false,
			'class' 		=> array( 'form-row' ),
			'clear'			=> true
		);

		return $fields;
	}

	public function add_settings_link( $links ) {
		$settings_link = '<a href="admin.php?page=wc-settings&tab=integration&section=interfax">' . __( 'Configure', 'wc_interfax' ) . '</a>';
  		array_unshift( $links, $settings_link );
  		return $links;
	}

	public function load_localisation () {
		load_plugin_textdomain( 'wc_interfax' , false , dirname( plugin_basename( $this->file ) ) . '/lang/' );
	}

	public function load_plugin_textdomain () {
		$domain = 'wc_interfax';
	    $locale = apply_filters( 'plugin_locale' , get_locale() , $domain );

	    load_textdomain( $domain , WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo' );
	    load_plugin_textdomain( $domain , FALSE , dirname( plugin_basename( $this->file ) ) . '/lang/' );
	}

}
