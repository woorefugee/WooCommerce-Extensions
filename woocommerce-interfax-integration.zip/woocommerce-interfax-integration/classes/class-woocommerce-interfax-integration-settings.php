<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class WooCommerce_InterFax_Integration_Settings extends WC_Integration {

	var $plugin_id = 'woocommerce_';
	var $settings = array();
	var $form_fields = array();
	var $errors = array();
	var $sanitized_fields = array();
	var $id;
	var $method_title;
	var $method_description;

	public function __construct() {
        $this->id			      = 'interfax';
        $this->method_title       = __( 'InterFax', 'wc_interfax' );
        $this->method_description = __( '<a href="http://www.interfax.net/" target="_blank">InterFax</a> is an online fax service that allows you to send faxes straight from your computer. This integration will enable your store to send order details to yourself and your customers via fax.', 'wc_interfax' );

		// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Define user set variables
		$this->wcif_enable	   = $this->settings['wcif_enable'];
		$this->wcif_username   = $this->settings['wcif_username'];
		$this->wcif_password   = $this->settings['wcif_password'];
		$this->wcif_fax_number = $this->settings['wcif_fax_number'];
		$this->wcif_fax_status = ( isset( $this->settings['wcif_fax_status'] ) ) ? $this->settings['wcif_fax_status'] : 'wc-completed';

		// Actions
		add_action( 'woocommerce_update_options_integration_interfax', array( $this, 'process_admin_options') );
    }

    /**
     * Initialise Settings Form Fields
     */
    function init_form_fields() {

    	if( version_compare( WC()->version, 2.2, ">=" ) ) {
    		$status_options = wc_get_order_statuses();
    	} else {
	    	$order_statuses = get_terms( 'shop_order_status', array( 'hide_empty' => false ) );
	    	$status_options = array();
	    	foreach ( $order_statuses as $status ) {
		        $status_options[ $status->slug ] = $status->name;
		    }
		}

    	$this->form_fields = array(
    		'wcif_enable' => array(
				'title' 			=> __( 'Enable/Disable', 'wc_interfax' ),
				'label' 			=> __( 'Enable InterFax integration', 'wc_interfax' ),
				'type' 				=> 'checkbox',
				'checkboxgroup'		=> 'enable',
				'default' 			=> get_option( 'woocommerce_wcif_enable' ) ? get_option( 'woocommerce_wcif_enable' ) : 'no'  // Backwards compat
			),
    		'wcif_username' => array(
				'title' 			=> __( 'InterFax Username', 'wc_interfax' ),
				'description' 		=> __( 'Your InterFax username.', 'wc_interfax' ),
				'type' 				=> 'text',
		    	'default' 			=> '' // Backwards compat
			),
			'wcif_password' => array(
				'title' 			=> __( 'InterFax Password', 'wc_interfax' ),
				'description' 		=> __( 'Your InterFax password.', 'wc_interfax' ),
				'type' 				=> 'password',
		    	'default' 			=> '' // Backwards compat
			),
			'wcif_fax_number' => array(
				'title' 			=> __( 'Number to which every order\'s details must be faxed', 'wc_interfax' ),
				'description' 		=> __( 'Only fill in a number here if you want every order\'s details to be faxed to you (irrespective of whether the customer receives a fax or not). Number must include the full country code - e.g. +27861234567', 'wc_interfax' ),
				'type' 				=> 'text',
		    	'default' 			=> '' // Backwards compat
			),
			'wcif_fax_status' => array(
				'title' 			=> __( 'Order status at which the fax will be sent', 'wc_interfax' ),
				'description' 		=> __( 'The order fax will be sent when the order is changed to this status.', 'wc_interfax' ),
				'type' 				=> 'select',
				'options'			=> $status_options,
		    	'default' 			=> 'wc-completed' // Backwards compat
			)
		);

    } // End init_form_fields()

}