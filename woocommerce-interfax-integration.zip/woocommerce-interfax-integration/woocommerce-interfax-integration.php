<?php
/*
 * Plugin Name: WooCommerce InterFax Integration
 * Version: 1.1.3
 * Plugin URI: https://www.woothemes.com/products/interfax-integration/
 * Description: WooCommerce extension allowing you to send order details to yourself and your customers via fax.
 * Author: WooCommerce
 * Author URI: https://woocommerce.com/
 * Requires at least: 4.0
 * Tested up to: 4.2.2
 *
 * @package WordPress
 * @author WooThemes
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) )
	require_once( 'woo-includes/woo-functions.php' );

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), '2921cafca7d2e95bd8411830518f0802', '214358' );

// Check if WooCommerce is active
if ( ! is_woocommerce_active() )
	return;

require_once( 'classes/class-woocommerce-interfax-integration.php' );

global $wcifi;
$wcifi = new WooCommerce_InterFax_Integration( __FILE__ );

// Add InterFax integration
function add_interfax_integration( $integrations ) {
	require_once( 'classes/class-woocommerce-interfax-integration-settings.php' );
	$integrations[] = 'WooCommerce_InterFax_Integration_Settings';
	return $integrations;
}
add_filter( 'woocommerce_integrations', 'add_interfax_integration' );
