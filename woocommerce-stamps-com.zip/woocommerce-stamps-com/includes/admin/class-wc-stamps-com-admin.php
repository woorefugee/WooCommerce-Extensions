<?php
/**
 * WooCommerce Stamps.com Export
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Stamps.com Export to newer
 * versions in the future. If you wish to customize WooCommerce Stamps.com Export for your
 * needs please refer to http://docs.woocommerce.com/document/stamps-com-xml-file-export/ for more information.
 *
 * @package     WC-Stamps-Com/Admin
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013-2017, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

defined( 'ABSPATH' ) or exit;

/**
 * Stamps.com Admin Class
 *
 * Loads admin UX and functionality
 *
 * @since 2.0
 */
class WC_Stamps_Com_Admin {


	/** @var string sub-menu page hook suffix */
	public $page;

	/** @var array tab IDs / titles */
	public $tabs;

	/** @var \SV_WP_Admin_Message_Handler instance */
	public $message_handler;


	/**
	 * Setup admin class
	 *
	 * @since 2.0
	 */
	public function __construct() {

		$this->tabs = array(
			'export'   => __( 'Export', 'woocommerce-stamps-com' ),
			'settings' => __( 'Settings', 'woocommerce-stamps-com' ),
		);

		// Load datepicker on export page
		add_action( 'admin_enqueue_scripts', array( $this, 'load_datepicker' ) );

		// Load WC styles / scripts
		add_filter( 'woocommerce_screen_ids', array( $this, 'load_wc_scripts' ) );

		// process bulk export
		add_action( 'admin_init', array( $this, 'process_export' ) );

		// Add 'Stamps.com Export' link under WooCommerce menu
		add_action( 'admin_menu', array( $this, 'add_menu_link' ) );

		// Add 'Download Stamps.com XML' action on orders page
		add_action( 'woocommerce_admin_order_actions_end', array( $this, 'add_order_action' ) );

		// Add 'Download Stamps.com XML' order meta box order action
		add_action( 'woocommerce_order_actions', array( $this, 'add_order_meta_box_actions' ) );

		// Process 'Download Stamps.com XML' order meta box order action
		add_action( 'woocommerce_order_action_wc_stamps_com_download_xml', array( $this, 'process_order_meta_box_actions' ) );

		// Add bulk action to download stamps.com XML for multiple orders
		add_action( 'admin_footer-edit.php', array( $this, 'add_order_bulk_actions' ) );

		// Process bulk action to download stamps.com XML for multiple orders
		add_action( 'load-edit.php', array( $this, 'process_order_bulk_actions' ) );
	}


	/**
	 * Load datepicker on export page.
	 *
	 * @since 2.0.0
	 * @param $hook_suffix
	 */
	public function load_datepicker( $hook_suffix ) {
		global $wp_scripts;

		if ( 'edit.php' === $hook_suffix || 'post.php' === $hook_suffix ) {

			// admin CSS
			wp_enqueue_style( 'wc-stamps-com-admin', wc_stamps_com()->get_plugin_url() . '/assets/css/admin/wc-stamps-com-admin.min.css', array( 'dashicons' ), WC_Stamps_Com::VERSION );
		}

		// load datepicker CSS on export page
		if ( $this->page === $hook_suffix ) {

			// enqueue script
			wp_enqueue_script( 'jquery-ui-datepicker' );

			// get jQuery UI version
			$jquery_version = isset( $wp_scripts->registered['jquery-ui-core']->ver ) ? $wp_scripts->registered['jquery-ui-core']->ver : '1.9.2';

			// enqueue UI CSS
			wp_enqueue_style( 'jquery-ui-style', '//ajax.googleapis.com/ajax/libs/jqueryui/' . $jquery_version . '/themes/smoothness/jquery-ui.css' );
		}
	}


	/**
	 * Add settings/export screen ID to the list of pages for WC to load its scripts on.
	 *
	 * @since 2.0.0
	 * @param array $screen_ids
	 * @return array
	 */
	public function load_wc_scripts( $screen_ids ) {

		$screen_ids[] = SV_WC_Plugin_Compatibility::normalize_wc_screen_id( 'wc_stamps_com' );

		return $screen_ids;
	}


	/**
	 * Add 'Stamps.com Export' sub-menu link under 'WooCommerce' top level menu.
	 *
	 * @since 2.0.0
	 */
	public function add_menu_link() {

		$this->page = add_submenu_page(
			'woocommerce',
			__( 'Stamps.com Export', 'woocommerce-stamps-com' ),
			__( 'Stamps.com Export', 'woocommerce-stamps-com' ),
			'manage_woocommerce',
			'wc_stamps_com',
			array( $this, 'render_submenu_pages' )
		);
	}


	/**
	 * Render the sub-menu page for 'Stamps.com Export'.
	 *
	 * @since 2.1.0
	 */
	public function render_submenu_pages() {

		// permissions check
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$current_tab = empty( $_GET['tab'] ) ? 'export' : urldecode( $_GET['tab'] );

		// settings
		if ( ! empty( $_POST ) && 'settings' === $current_tab ) {

			// security check
			if ( ! wp_verify_nonce( $_POST['_wpnonce'], __FILE__ ) ) {

				wp_die( __( 'Action failed. Please refresh the page and retry.', 'woocommerce-stamps-com' ) );
			}

			// save settings
			woocommerce_update_options( $this->get_settings( 'settings' ) );

			$this->message_handler->add_message( __( 'Your settings have been saved.', 'woocommerce-stamps-com' ) );
		}

		?>
		<div class="wrap woocommerce">
			<form method="post" id="mainform" action="" enctype="multipart/form-data">
				<h2 class="nav-tab-wrapper woo-nav-tab-wrapper">
					<?php
					foreach ( $this->tabs as $tab_id => $tab_title ) :

						$class = ( $tab_id === $current_tab ) ? 'nav-tab nav-tab-active' : 'nav-tab';
						$url   = add_query_arg( 'tab', $tab_id, admin_url( 'admin.php?page=wc_stamps_com' ) );

						// this isn't quite proper escaping, but sanitize_html_class() will strip our space char in the class
						printf( '<a href="%1$s" class="%2$s">%3$s</a>', esc_url( $url ), esc_attr( $class ), esc_html( $tab_title ) );

					endforeach;
					?>
				</h2>
				<?php

				$this->message_handler->show_messages();

				if ( 'settings' === $current_tab ) {

					$this->render_settings_page();

				} else {

					$this->render_export_page();
				}

				?>
			</form>
		</div>
		<?php
	}


	/**
	 * Render the export page.
	 *
	 * @since 2.1.0
	 */
	private function render_export_page() {

		// permissions check
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// show export form
		woocommerce_admin_fields( $this->get_settings( 'export' ) );

		// helper input
		?><input type="hidden" name="wc_stamps_com_export" value="1" /><?php

		// datepicker js
		wc_enqueue_js( '
			// start date
			$( "#wc_stamps_com_export_start_date" ).datepicker( {
				dateFormat      : "yy-mm-dd",
				numberOfMonths  : 1,
				showButtonPanel : true,
				showOn          : "button",
				buttonImage     : "' . WC()->plugin_url(). '/assets/images/calendar.png",
				buttonImageOnly : true
			} );
			// end date
			$( "#wc_stamps_com_export_end_date" ).datepicker( {
				dateFormat      : "yy-mm-dd",
				numberOfMonths  : 1,
				showButtonPanel : true,
				showOn          : "button",
				buttonImage     : "' . WC()->plugin_url(). '/assets/images/calendar.png",
				buttonImageOnly : true
			} );
		' );

		wp_nonce_field( __FILE__ );
		submit_button( __( 'Export', 'woocommerce-stamps-com' ) );
	}


	/**
	 * Process order bulk export action.
	 * Note this is hooked into `admin_init` as WC interferes with sending headers() from a sub-menu page
	 *
	 * {BR 2017-02-19}: We should migrate this query to wc_get_orders() once orders migrate to a new data structure.
	 *
	 * @since 2.1.0
	 */
	public function process_export() {

		if ( ! isset( $_POST['wc_stamps_com_export'] ) ) {
			return;
		}

		// security check
		if ( ! wp_verify_nonce( $_POST['_wpnonce'], __FILE__ ) ) {

			wp_die( __( 'Action failed. Please refresh the page and retry.', 'woocommerce-stamps-com' ) );
		}

		$query_args = array(
			'fields'      => 'ids',
			'post_type'   => 'shop_order',
			'post_status' => empty( $_POST['wc_stamps_com_statuses'] ) ? 'any' : $_POST['wc_stamps_com_statuses'],
			'nopaging'    => true,
			'date_query'  => array(
				array(
					'column'    => 'post_date_gmt',
					'before'    => empty( $_POST['wc_stamps_com_export_end_date'] )   ? date( 'Y-m-d 23:59' ) : $_POST['wc_stamps_com_export_end_date'],
					'after'     => empty( $_POST['wc_stamps_com_export_start_date'] ) ? date( 'Y-m-d', 0 )    : $_POST['wc_stamps_com_export_start_date'],
					'inclusive' => true,
				),
			),
		);

		// get order IDs
		$query = new WP_Query( $query_args );

		if ( $query->post_count ) {

			$export = new WC_Stamps_Com_Exporter( $query->posts );

			$export->download();

		} else {

			$this->message_handler->add_message( __( 'No orders found to export', 'woocommerce-stamps-com' ) );
		}
	}


	/**
	 * Show the plugin settings page.
	 *
	 * @since 2.0.0
	 */
	private function render_settings_page() {

		// render settings fields
		woocommerce_admin_fields( $this->get_settings( 'settings' ) );

		wp_nonce_field( __FILE__ );
		submit_button( __( 'Save settings', 'woocommerce-stamps-com' ) );
	}


	/**
	 * Adds 'Download Stamps.com XML' order action to 'Order Actions' column.
	 * Processed via AJAX
	 *
	 * @since 2.0.0
	 * @param \WC_Order $order Order object
	 */
	public function add_order_action( $order ) {

		$action = 'download_stamps_com';
		$url = wp_nonce_url( admin_url( 'admin-ajax.php?action=wc_stamps_com_download_xml&order_id=' . SV_WC_Order_Compatibility::get_prop( $order, 'id' ) ), 'wc_stamps_com_download_xml' );
		$name = __( 'Download to Stamps.com XML', 'woocommerce-stamps-com' );

		printf( '<a class="button tips %1$s" href="%2$s" data-tip="%3$s">%4$s</a>', sanitize_html_class( $action ), esc_url( $url ), esc_attr( $name ), esc_html( $name ) );
	}


	/**
	 * Add 'Download Stamps.com XML' link to Order Actions dropdown.
	 *
	 * @since 2.0.0
	 * @param array $actions order actions array to display
	 * @return array
	 */
	public function add_order_meta_box_actions( $actions ) {

		// add download to XML action
		$actions['wc_stamps_com_download_xml'] = __( 'Download Stamps.com XML', 'woocommerce-stamps-com' );

		return $actions;
	}


	/**
	 * Process the 'Download Stamps.com XML' link in Order Actions dropdown.
	 *
	 * @since 2.0.0
	 * @param \WC_Order $order Order object
	 */
	public function process_order_meta_box_actions( $order ) {

		$export = new WC_Stamps_Com_Exporter( SV_WC_Order_Compatibility::get_prop( $order, 'id' ) );

		$export->download();
	}


	/**
	 * Add "Download Stamps.com XML" custom bulk action to the 'Orders' page bulk action drop-down.
	 *
	 * @since 2.0.0
	 */
	public function add_order_bulk_actions() {
		global $post_type, $post_status;

		if ( 'shop_order' === $post_type && 'trash' !== $post_status ) {
			?>
			<script type="text/javascript">
				jQuery( document ).ready(function ( $ ) {
					var $downloadXml = $( '<option>' ).val( 'download_xml' ).text( '<?php echo esc_js( __( 'Download Stamps.com XML', 'woocommerce-stamps-com' ) ); ?>' );
					$( 'select[name^="action"]' ).append( $downloadXml );
				});
			</script>
			<?php
		}
	}


	/**
	 * Processes the "Download Stamps.com XML" custom bulk action on the 'Orders' page bulk action drop-down.
	 *
	 * @since 2.0.0
	 */
	public function process_order_bulk_actions() {
		global $typenow;

		if ( 'shop_order' === $typenow ) {

			// get the action
			$wp_list_table = _get_list_table( 'WP_Posts_List_Table' );
			$action        = $wp_list_table->current_action();

			// return if not processing our actions
			if ( ! in_array( $action, array( 'download_xml' ) ) ) {
				return;
			}

			// security check
			check_admin_referer( 'bulk-posts' );

			// make sure order IDs are submitted
			if ( isset( $_REQUEST['post'] ) ) {
				$order_ids = array_map( 'absint', $_REQUEST['post'] );
			}

			// return if there are no orders to export
			if ( empty( $order_ids ) ) {
				return;
			}

			// give ourselves an unlimited timeout if possible
			@set_time_limit( 0 );

			if ( 'download_xml' === $action ) {

				// setup export class
				$export = new WC_Stamps_Com_Exporter( $order_ids );

				// download the orders
				$export->download();
			}
		}
	}


	/**
	 * Returns settings array for use by output/save functions.
	 *
	 * @since 2.0.0
	 * @param string $tab_id
	 * @return array
	 */
	public static function get_settings( $tab_id ) {

		// get available order statuses
		$order_statuses = wc_get_order_statuses();

		$settings = array(

			'settings' => array(

				array(
					'name' => __( 'General Settings', 'woocommerce-stamps-com' ),
					'type' => 'title',
				),

				array(
					'id'       => 'wc_stamps_com_export_file_name',
					'name'     => __( 'Export Filename', 'woocommerce-stamps-com' ),
					'desc_tip' => __( 'The XML filename for exported orders. Use %%timestamp%% to represent the date in the filename.', 'woocommerce-stamps-com' ),
					'default'  => 'woocommerce-orders.xml',
					'css'      => 'min-width: 300px;',
					'type'     => 'text',
				),

				array(
					'id'      => 'wc_stamps_com_attach_exports',
					'name'    => __( 'Attach order XML file to admin new order email', 'woocommerce-stamps-com' ),
					'desc'    => __( 'Enable this to attach the order XML file to the admin new order email notification.', 'woocommerce-stamps-com' ),
					'default' => 'no',
					'type'    => 'checkbox'
				),

				array( 'type' => 'sectionend' ),

				array(
					'name'        => __( 'Export Settings', 'woocommerce-stamps-com' ),
					'type'        => 'title',
					'description' => __( 'These settings will apply to all exports, either on the bulk export tab or on the Orders page.', 'woocommerce-stamps-com' ),
				),

				array(
					'id'      => 'wc_stamps_com_include_customs_info',
					'name'    => __( 'Include Customs Information', 'woocommerce-stamps-com' ),
					'desc'    => __( 'Enable this to include customs information in the exported XML.', 'woocommerce-stamps-com' ),
					'default' => 'no',
					'type'    => 'checkbox',
				),

				array( 'type' => 'sectionend' ),

			),

			'export' => array(

				array(
					'name' => __( 'Order Statuses', 'woocommerce-stamps-com' ),
					'type' => 'title',
				),

				array(
					'id'                => 'wc_stamps_com_statuses',
					'name'              => __( 'Order Statuses', 'woocommerce-stamps-com' ),
					'desc_tip'          => __( 'Orders with these statuses will be included in the export.', 'woocommerce-stamps-com' ),
					'type'              => 'multiselect',
					'options'           => $order_statuses,
					'default'           => '',
					'class'             => 'wc-enhanced-select',
					'css'               => 'min-width: 250px',
					'custom_attributes' => array(
						'data-placeholder' => __( 'Leave blank to include orders with any status.', 'woocommerce-stamps-com' ),
					),
				),

				array( 'type' => 'sectionend' ),

				array(
					'name' => __( 'Date Range', 'woocommerce-stamps-com' ),
					'type' => 'title',
					'desc' => __( 'Orders created during these dates will be included in the exported file.', 'woocommerce-stamps-com' )
				),

				array(
					'id'   => 'wc_stamps_com_export_start_date',
					'name' => __( 'Start Date', 'woocommerce-stamps-com' ),
					'desc' => __( 'Start date of orders to include in the exported file, in the format <code>YYYY-MM-DD.</code>', 'woocommerce-stamps-com' ),
					'type' => 'text',
				),

				array(
					'id'   => 'wc_stamps_com_export_end_date',
					'name' => __( 'End Date', 'woocommerce-stamps-com' ),
					'desc' => __( 'End date of orders to include in the exported file, in the format <code>YYYY-MM-DD.</code>', 'woocommerce-stamps-com' ),
					'type' => 'text',
				),

				array( 'type' => 'sectionend' ),
			)
		);

		return $settings[ $tab_id ];
	}


}
