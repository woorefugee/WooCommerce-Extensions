=== WooCommerce Stamps.com Export Suite ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.7.3
Requires WooCommerce at least: 2.5.5
Tested WooCommerce up to: 3.0.0

A full-featured XML Export Suite designed for Stamps.com

See http://docs.woocommerce.com/document/stamps-com-xml-file-export/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-stamps-com' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
